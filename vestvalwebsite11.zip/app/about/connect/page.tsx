import Header from "@/components/Header"
import Footer from "@/components/Footer"
import { Breadcrumbs } from "@/components/Breadcrumbs"
import Link from "next/link"

export const metadata = { title: "Connect With Us — Vestval", description: "Contact, social, and newsletter." }

export default function ConnectWithUs() {
  return (
    <main>
      <Header />
      <section className="pt-8">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <Breadcrumbs items={[{ name: "About", href: "/about" }, { name: "Connect With Us" }]} />
          <h1 className="text-3xl md:text-4xl font-bold mt-6 mb-4">Connect With Us</h1>
          <p className="text-gray-600">
            Get in touch via{" "}
            <Link className="text-blue-600 hover:underline" href="/contact">
              Contact
            </Link>{" "}
            or follow our{" "}
            <Link className="text-blue-600 hover:underline" href="/newsroom">
              Newsroom
            </Link>
            .
          </p>
        </div>
      </section>
      <Footer />
    </main>
  )
}
