import Header from "@/components/Header"
import Footer from "@/components/Footer"
import ScrollToTop from "@/components/ScrollToTop"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { MapPin, Users, Globe, ArrowRight, Building, Heart, Target } from "lucide-react"
import Link from "next/link"

export const metadata = {
  title: "About Us - Vestval | Global Advisory Excellence",
  description:
    "Learn about Vestval's mission, vision, values, and global presence. Founded in 2022, our team delivers transformational advisory services worldwide with integrity and innovation.",
}

export default function AboutPage() {
  return (
    <main className="min-h-screen">
      <Header />

      {/* Hero Section */}
      <section className="pt-24 pb-16 bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 text-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 animate-fade-in-up">About Vestval</h1>
            <p className="text-xl md:text-2xl mb-8 opacity-90 animate-fade-in-up" style={{ animationDelay: "0.2s" }}>
              Empowering ambitious growth through expert advisory services since 2022
            </p>
            <p className="text-lg text-gray-300 max-w-3xl mx-auto leading-relaxed mb-8">
              Vestval is a premier global advisory firm dedicated to empowering ambitious businesses with expert
              consulting and financial strategies. With a heritage rooted in innovation and integrity, we combine
              international insights with local expertise to deliver transformational outcomes that drive sustainable
              growth and competitive advantage in today's dynamic business landscape.
            </p>
          </div>
        </div>
      </section>

      {/* Navigation to About Sub-pages */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Discover Vestval</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Explore our comprehensive story, values, people, and global presence
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {[
              {
                title: "Our Purpose",
                description: "Understanding our mission, vision, and the driving force behind everything we do",
                icon: Target,
                href: "/about/purpose",
                color: "from-blue-500 to-blue-600",
              },
              {
                title: "Our Values",
                description: "The core principles and beliefs that guide our decisions and relationships",
                icon: Heart,
                href: "/about/values",
                color: "from-green-500 to-green-600",
              },
              {
                title: "Our People",
                description: "Meet the exceptional team of experts driving innovation and excellence",
                icon: Users,
                href: "/about/people",
                color: "from-purple-500 to-purple-600",
              },
              {
                title: "Locations",
                description: "Our global presence and regional offices serving clients worldwide",
                icon: MapPin,
                href: "/about/locations",
                color: "from-orange-500 to-orange-600",
              },
              {
                title: "Connect with Us",
                description: "Get in touch, follow our journey, and stay updated with our latest insights",
                icon: Globe,
                href: "/about/connect",
                color: "from-teal-500 to-teal-600",
              },
              {
                title: "Newsroom",
                description: "Latest news, press releases, insights, and thought leadership from Vestval",
                icon: Building,
                href: "/newsroom",
                color: "from-red-500 to-red-600",
              },
            ].map((item, index) => (
              <Card
                key={index}
                className="border-0 shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-3 group"
              >
                <CardContent className="p-8">
                  <div
                    className={`w-16 h-16 rounded-xl bg-gradient-to-r ${item.color} flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`}
                  >
                    <item.icon className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-3 group-hover:text-blue-600 transition-colors duration-300">
                    {item.title}
                  </h3>
                  <p className="text-gray-600 mb-6 leading-relaxed">{item.description}</p>
                  <Button
                    asChild
                    variant="outline"
                    className="w-full group-hover:bg-gradient-to-r group-hover:from-blue-600 group-hover:to-teal-500 group-hover:text-white group-hover:border-transparent transition-all duration-300 bg-transparent"
                  >
                    <Link href={item.href}>
                      Learn More
                      <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform duration-300" />
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Quick Overview */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">Our Story at a Glance</h2>

            <div className="grid md:grid-cols-2 gap-12">
              <div>
                <h3 className="text-2xl font-bold mb-4 text-gray-900">Founded on Excellence</h3>
                <p className="text-gray-600 leading-relaxed mb-6">
                  Established in 2022, Vestval emerged from a vision to bridge the gap between ambitious business goals
                  and expert advisory services. Our founders, seasoned professionals with decades of combined experience
                  across finance, technology, and corporate strategy, recognized the need for a new kind of advisory
                  firm—one that combines global expertise with local insights, innovative thinking with proven
                  methodologies.
                </p>
                <p className="text-gray-600 leading-relaxed">
                  As an advisory-only firm, we remain free from the regulatory complexities that often constrain
                  traditional financial institutions, allowing us to focus purely on delivering exceptional value to our
                  clients through customized strategies and unbiased recommendations.
                </p>
              </div>

              <div>
                <h3 className="text-2xl font-bold mb-4 text-gray-900">Global Impact</h3>
                <div className="space-y-4">
                  <div className="flex items-center">
                    <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-teal-500 rounded-full flex items-center justify-center mr-4">
                      <span className="text-white font-bold">300+</span>
                    </div>
                    <div>
                      <div className="font-semibold text-gray-900">Deals Completed</div>
                      <div className="text-sm text-gray-600">Across multiple sectors and geographies</div>
                    </div>
                  </div>

                  <div className="flex items-center">
                    <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-teal-500 rounded-full flex items-center justify-center mr-4">
                      <span className="text-white font-bold">$1B+</span>
                    </div>
                    <div>
                      <div className="font-semibold text-gray-900">Value Delivered</div>
                      <div className="text-sm text-gray-600">In transactions and strategic initiatives</div>
                    </div>
                  </div>

                  <div className="flex items-center">
                    <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-teal-500 rounded-full flex items-center justify-center mr-4">
                      <span className="text-white font-bold">30+</span>
                    </div>
                    <div>
                      <div className="font-semibold text-gray-900">Investment Sectors</div>
                      <div className="text-sm text-gray-600">Spanning diverse industries globally</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 text-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Transform Your Business?</h2>
          <p className="text-xl mb-8 opacity-90 max-w-2xl mx-auto">
            Connect with our expert team to discover how Vestval can drive your ambitious growth goals.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" className="bg-white text-gray-900 hover:bg-gray-100">
              <Link href="/contact">Contact Our Experts</Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="border-white text-white hover:bg-white hover:text-gray-900 bg-transparent"
            >
              <Link href="/services">Explore Our Services</Link>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
      <ScrollToTop />
    </main>
  )
}
