import Header from "@/components/Header"
import Footer from "@/components/Footer"
import ScrollToTop from "@/components/ScrollToTop"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Target, Globe, Award, ArrowLeft, ArrowRight } from "lucide-react"
import Link from "next/link"

export const metadata = {
  title: "Our Purpose - About Vestval | Mission, Vision & Strategic Direction",
  description:
    "Discover Vestval's mission to empower ambitious growth, our vision for global advisory excellence, and the strategic direction that guides our commitment to client success.",
}

export default function PurposePage() {
  return (
    <main className="min-h-screen">
      <Header />

      {/* Breadcrumb */}
      <section className="pt-24 pb-8 bg-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <nav className="flex items-center space-x-2 text-sm text-gray-600">
            <Link href="/" className="hover:text-blue-600">
              Home
            </Link>
            <span>/</span>
            <Link href="/about" className="hover:text-blue-600">
              About
            </Link>
            <span>/</span>
            <span className="text-gray-900">Our Purpose</span>
          </nav>
        </div>
      </section>

      {/* Hero Section */}
      <section className="pb-16 bg-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 text-gray-900">Our Purpose</h1>
            <p className="text-xl md:text-2xl mb-8 text-gray-600">
              The mission, vision, and strategic direction that drives everything we do
            </p>
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-6xl mx-auto">
            <Card className="border-0 shadow-xl overflow-hidden">
              <CardContent className="p-12">
                <div className="flex items-center mb-8">
                  <div className="w-16 h-16 bg-gradient-to-r from-blue-600 to-teal-500 rounded-xl flex items-center justify-center mr-6">
                    <Target className="h-8 w-8 text-white" />
                  </div>
                  <h2 className="text-3xl md:text-4xl font-bold text-gray-900">Our Mission</h2>
                </div>

                <div className="prose prose-lg max-w-none">
                  <p className="text-xl text-gray-700 leading-relaxed mb-6">
                    To be the most trusted partner for businesses aspiring to achieve sustainable, strategic growth
                    through expert advisory services grounded in integrity and innovation.
                  </p>

                  <p className="text-gray-600 leading-relaxed mb-6">
                    At Vestval, we believe that every business, regardless of size or sector, deserves access to
                    world-class advisory services. Our mission extends beyond traditional consulting to create lasting
                    partnerships that drive meaningful transformation. We empower organizations to navigate complex
                    challenges, unlock their full potential, and achieve ambitious growth goals through the strategic
                    application of technology and financial excellence.
                  </p>

                  <p className="text-gray-600 leading-relaxed mb-6">
                    We are committed to delivering outcomes that matter—not just recommendations, but actionable
                    strategies that create measurable value. Our approach combines deep industry expertise with
                    innovative thinking, ensuring that our clients are not just prepared for today's challenges, but
                    positioned to thrive in tomorrow's opportunities.
                  </p>

                  <div className="bg-blue-50 rounded-lg p-6 mt-8">
                    <h3 className="text-xl font-bold text-gray-900 mb-4">Mission Pillars</h3>
                    <ul className="space-y-3">
                      <li className="flex items-start">
                        <div className="w-2 h-2 bg-blue-600 rounded-full mr-3 mt-2 flex-shrink-0"></div>
                        <span className="text-gray-700">
                          <strong>Integrity First:</strong> Every recommendation is unbiased, every strategy is
                          transparent, and every relationship is built on trust
                        </span>
                      </li>
                      <li className="flex items-start">
                        <div className="w-2 h-2 bg-blue-600 rounded-full mr-3 mt-2 flex-shrink-0"></div>
                        <span className="text-gray-700">
                          <strong>Innovation-Driven:</strong> We leverage cutting-edge technology and methodologies to
                          deliver superior outcomes
                        </span>
                      </li>
                      <li className="flex items-start">
                        <div className="w-2 h-2 bg-blue-600 rounded-full mr-3 mt-2 flex-shrink-0"></div>
                        <span className="text-gray-700">
                          <strong>Results-Oriented:</strong> Success is measured by the tangible value we create for our
                          clients
                        </span>
                      </li>
                      <li className="flex items-start">
                        <div className="w-2 h-2 bg-blue-600 rounded-full mr-3 mt-2 flex-shrink-0"></div>
                        <span className="text-gray-700">
                          <strong>Partnership Mindset:</strong> We work alongside our clients as trusted advisors, not
                          just consultants
                        </span>
                      </li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Vision Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-6xl mx-auto">
            <Card className="border-0 shadow-xl overflow-hidden">
              <CardContent className="p-12">
                <div className="flex items-center mb-8">
                  <div className="w-16 h-16 bg-gradient-to-r from-green-600 to-teal-500 rounded-xl flex items-center justify-center mr-6">
                    <Globe className="h-8 w-8 text-white" />
                  </div>
                  <h2 className="text-3xl md:text-4xl font-bold text-gray-900">Our Vision</h2>
                </div>

                <div className="prose prose-lg max-w-none">
                  <p className="text-xl text-gray-700 leading-relaxed mb-6">
                    To build a world where businesses of every scale have access to the highest caliber of strategic
                    advice, enabling them to thrive in an increasingly complex global market.
                  </p>

                  <p className="text-gray-600 leading-relaxed mb-6">
                    We envision a future where geographical boundaries, company size, or industry sector do not limit
                    access to exceptional advisory services. Our vision is to democratize world-class consulting, making
                    it accessible to ambitious businesses worldwide while maintaining the highest standards of
                    excellence and expertise.
                  </p>

                  <p className="text-gray-600 leading-relaxed mb-6">
                    As the premier global advisory firm, we aim to be recognized not just for our expertise, but for our
                    ability to bridge innovation with execution. We see ourselves as catalysts of transformation,
                    helping businesses navigate the complexities of modern markets while building sustainable
                    competitive advantages that endure.
                  </p>

                  <div className="bg-green-50 rounded-lg p-6 mt-8">
                    <h3 className="text-xl font-bold text-gray-900 mb-4">Vision Elements</h3>
                    <div className="grid md:grid-cols-2 gap-6">
                      <div>
                        <h4 className="font-semibold text-gray-900 mb-2">Global Accessibility</h4>
                        <p className="text-gray-600 text-sm">Breaking down barriers to world-class advisory services</p>
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900 mb-2">Innovation Leadership</h4>
                        <p className="text-gray-600 text-sm">Pioneering new approaches to business transformation</p>
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900 mb-2">Sustainable Impact</h4>
                        <p className="text-gray-600 text-sm">
                          Creating lasting value that extends beyond individual engagements
                        </p>
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900 mb-2">Market Leadership</h4>
                        <p className="text-gray-600 text-sm">Setting the standard for advisory excellence globally</p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Strategic Direction */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-6xl mx-auto">
            <Card className="border-0 shadow-xl overflow-hidden">
              <CardContent className="p-12">
                <div className="flex items-center mb-8">
                  <div className="w-16 h-16 bg-gradient-to-r from-purple-600 to-pink-500 rounded-xl flex items-center justify-center mr-6">
                    <Award className="h-8 w-8 text-white" />
                  </div>
                  <h2 className="text-3xl md:text-4xl font-bold text-gray-900">Strategic Direction</h2>
                </div>

                <div className="prose prose-lg max-w-none">
                  <p className="text-xl text-gray-700 leading-relaxed mb-8">
                    Our strategic direction is built on three foundational pillars that guide our growth, service
                    delivery, and client relationships.
                  </p>

                  <div className="grid md:grid-cols-3 gap-8">
                    <div className="text-center">
                      <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-teal-500 rounded-full flex items-center justify-center mx-auto mb-4">
                        <span className="text-white font-bold text-lg">1</span>
                      </div>
                      <h3 className="text-xl font-bold text-gray-900 mb-3">Excellence in Execution</h3>
                      <p className="text-gray-600 text-sm leading-relaxed">
                        Delivering superior outcomes through rigorous methodologies, deep expertise, and unwavering
                        commitment to quality in every engagement.
                      </p>
                    </div>

                    <div className="text-center">
                      <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-teal-500 rounded-full flex items-center justify-center mx-auto mb-4">
                        <span className="text-white font-bold text-lg">2</span>
                      </div>
                      <h3 className="text-xl font-bold text-gray-900 mb-3">Innovation Integration</h3>
                      <p className="text-gray-600 text-sm leading-relaxed">
                        Continuously evolving our service offerings by integrating emerging technologies, methodologies,
                        and market insights into our advisory practice.
                      </p>
                    </div>

                    <div className="text-center">
                      <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-teal-500 rounded-full flex items-center justify-center mx-auto mb-4">
                        <span className="text-white font-bold text-lg">3</span>
                      </div>
                      <h3 className="text-xl font-bold text-gray-900 mb-3">Global Expansion</h3>
                      <p className="text-gray-600 text-sm leading-relaxed">
                        Strategically expanding our presence and capabilities to serve clients across diverse markets
                        while maintaining our commitment to local expertise.
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Navigation */}
      <section className="py-12 bg-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center max-w-4xl mx-auto">
            <Button asChild variant="outline" className="flex items-center bg-transparent">
              <Link href="/about">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to About
              </Link>
            </Button>
            <Button asChild className="bg-gradient-to-r from-blue-600 to-teal-500 text-white hover:opacity-90">
              <Link href="/about/values">
                Our Values
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
      <ScrollToTop />
    </main>
  )
}
