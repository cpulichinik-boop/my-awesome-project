import Header from "@/components/Header"
import Footer from "@/components/Footer"
import ScrollToTop from "@/components/ScrollToTop"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Heart, Shield, Lightbulb, Users, Globe, Award, ArrowLeft, ArrowRight } from "lucide-react"
import Link from "next/link"

export const metadata = {
  title: "Our Values - About Vestval | Core Principles & Beliefs",
  description:
    "Discover the core values that guide Vestval's decisions, relationships, and commitment to excellence in advisory services. Learn about our principles of integrity, innovation, and client success.",
}

export default function ValuesPage() {
  const values = [
    {
      icon: Shield,
      title: "Integrity & Trust",
      description:
        "We operate with unwavering ethical standards, ensuring transparency in all our dealings and building relationships based on trust and mutual respect.",
      details: [
        "Unbiased recommendations free from conflicts of interest",
        "Transparent communication in all client interactions",
        "Ethical business practices that exceed industry standards",
        "Confidentiality and discretion in all engagements",
      ],
      color: "from-blue-600 to-blue-700",
    },
    {
      icon: Lightbulb,
      title: "Innovation & Excellence",
      description:
        "We continuously push boundaries, embracing new technologies and methodologies to deliver superior outcomes and stay ahead of market trends.",
      details: [
        "Cutting-edge technology integration in our advisory services",
        "Continuous learning and professional development",
        "Innovative problem-solving approaches",
        "Excellence in execution and delivery",
      ],
      color: "from-yellow-500 to-orange-500",
    },
    {
      icon: Users,
      title: "Client-Centric Focus",
      description:
        "Our clients' success is our success. We tailor our approach to each client's unique needs, ensuring personalized solutions that drive real value.",
      details: [
        "Customized strategies aligned with client objectives",
        "Long-term partnership mindset beyond individual projects",
        "Responsive and accessible client service",
        "Measurable outcomes and value creation",
      ],
      color: "from-green-600 to-teal-600",
    },
    {
      icon: Globe,
      title: "Global Perspective",
      description:
        "We bring international insights and best practices to every engagement while respecting local market dynamics and cultural nuances.",
      details: [
        "Cross-border expertise and market knowledge",
        "Cultural sensitivity and local market understanding",
        "Global network of partners and resources",
        "International best practices adapted locally",
      ],
      color: "from-purple-600 to-indigo-600",
    },
    {
      icon: Heart,
      title: "Collaborative Spirit",
      description:
        "We believe in the power of collaboration, working closely with our clients and partners to achieve shared goals and mutual success.",
      details: [
        "Team-based approach to problem-solving",
        "Knowledge sharing and collective expertise",
        "Strong partnerships with industry leaders",
        "Inclusive and diverse team culture",
      ],
      color: "from-pink-600 to-red-600",
    },
    {
      icon: Award,
      title: "Sustainable Impact",
      description:
        "We are committed to creating lasting positive impact for our clients, their stakeholders, and the broader business community.",
      details: [
        "Long-term value creation over short-term gains",
        "Sustainable business practices and ESG considerations",
        "Positive impact on communities and stakeholders",
        "Responsible growth and development strategies",
      ],
      color: "from-emerald-600 to-green-700",
    },
  ]

  return (
    <main className="min-h-screen">
      <Header />

      {/* Breadcrumb */}
      <section className="pt-24 pb-8 bg-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <nav className="flex items-center space-x-2 text-sm text-gray-600">
            <Link href="/" className="hover:text-blue-600">
              Home
            </Link>
            <span>/</span>
            <Link href="/about" className="hover:text-blue-600">
              About
            </Link>
            <span>/</span>
            <span className="text-gray-900">Our Values</span>
          </nav>
        </div>
      </section>

      {/* Hero Section */}
      <section className="pb-16 bg-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 text-gray-900">Our Values</h1>
            <p className="text-xl md:text-2xl mb-8 text-gray-600">
              The core principles and beliefs that guide our decisions and relationships
            </p>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Our values are not just words on a page—they are the foundation of our culture, the compass for our
              decisions, and the promise we make to every client, partner, and team member.
            </p>
          </div>
        </div>
      </section>

      {/* Values Grid */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-8 max-w-6xl mx-auto">
            {values.map((value, index) => (
              <Card
                key={index}
                className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2"
              >
                <CardContent className="p-8">
                  <div className="flex items-start space-x-4">
                    <div
                      className={`w-16 h-16 rounded-xl bg-gradient-to-r ${value.color} flex items-center justify-center flex-shrink-0`}
                    >
                      <value.icon className="h-8 w-8 text-white" />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-2xl font-bold text-gray-900 mb-3">{value.title}</h3>
                      <p className="text-gray-600 leading-relaxed mb-6">{value.description}</p>
                      <ul className="space-y-2">
                        {value.details.map((detail, idx) => (
                          <li key={idx} className="flex items-start text-sm text-gray-600">
                            <div className="w-1.5 h-1.5 bg-gradient-to-r from-blue-600 to-teal-500 rounded-full mr-3 flex-shrink-0 mt-2"></div>
                            {detail}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Values in Action */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-8 text-gray-900">Values in Action</h2>
            <p className="text-lg text-gray-600 mb-12 leading-relaxed">
              Our values come to life through our daily actions, client interactions, and business decisions. They shape
              how we approach challenges, build relationships, and deliver results.
            </p>

            <div className="grid md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-to-r from-blue-600 to-teal-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-white font-bold text-2xl">300+</span>
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">Trusted Partnerships</h3>
                <p className="text-gray-600 text-sm">Built on integrity and mutual respect</p>
              </div>

              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-to-r from-blue-600 to-teal-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-white font-bold text-2xl">100%</span>
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">Client Satisfaction</h3>
                <p className="text-gray-600 text-sm">Through client-centric excellence</p>
              </div>

              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-to-r from-blue-600 to-teal-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-white font-bold text-2xl">30+</span>
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">Global Markets</h3>
                <p className="text-gray-600 text-sm">With local expertise and cultural sensitivity</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Navigation */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center max-w-4xl mx-auto">
            <Button asChild variant="outline" className="flex items-center bg-transparent">
              <Link href="/about/purpose">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Our Purpose
              </Link>
            </Button>
            <Button asChild className="bg-gradient-to-r from-blue-600 to-teal-500 text-white hover:opacity-90">
              <Link href="/about/people">
                Our People
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
      <ScrollToTop />
    </main>
  )
}
