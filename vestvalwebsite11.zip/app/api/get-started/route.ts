import { NextResponse } from "next/server"

function clamp(num: number, min: number, max: number) {
  return Math.min(Math.max(num, min), max)
}

// Generates a short case identifier like VS-20250930-ABCD
function generateCaseId() {
  const d = new Date()
  const date = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, "0")}${String(d.getDate()).padStart(2, "0")}`
  const rand = Math.random().toString(36).slice(2, 6).toUpperCase()
  return `VS-${date}-${rand}`
}

export async function POST(req: Request) {
  try {
    const form = await req.formData()

    // Honeypot
    if (typeof form.get("websiteHp") === "string" && (form.get("websiteHp") as string).trim() !== "") {
      return NextResponse.json({ ok: true }, { status: 200 })
    }

    const companyName = String(form.get("companyName") || "")
    const website = String(form.get("website") || "")
    const contactName = String(form.get("contactName") || "")
    const email = String(form.get("email") || "")
    const phone = String(form.get("phone") || "")
    const summary = String(form.get("summary") || "")
    const timeline = String(form.get("timeline") || "")
    const budgetRange = String(form.get("budgetRange") || "")

    const challenges = JSON.parse(String(form.get("challenges") || "[]")) as string[]
    const maturity = JSON.parse(String(form.get("maturity") || "[]")) as string[]

    const benefit = Number(form.get("estBenefit") || 0) || 0
    const cost = Number(form.get("estCost") || 0) || 0
    const rawRoi = cost > 0 ? ((benefit - cost) / cost) * 100 : 0
    const roiPct = clamp(rawRoi, -100, 1000)

    const file = form.get("file") as File | null

    if (!companyName || !contactName || !email) {
      return NextResponse.json({ error: "Missing required fields (companyName, contactName, email)." }, { status: 400 })
    }

    const caseId = generateCaseId()
    const subject = `Vestval Get Started - CASE ${caseId} - ${companyName}`

    // Prepare a provider-agnostic payload description
    const message = [
      `Case ID: ${caseId}`,
      `Company: ${companyName}`,
      website ? `Website: ${website}` : null,
      `Contact: ${contactName} (${email}${phone ? `, ${phone}` : ""})`,
      `Timeline: ${timeline || "n/a"}`,
      `Budget: ${budgetRange || "n/a"}`,
      `Challenges: ${challenges.length ? challenges.join(", ") : "n/a"}`,
      `Maturity: ${maturity.length ? maturity.join(", ") : "n/a"}`,
      "",
      "Summary:",
      summary || "n/a",
      "",
      `Estimates: Benefit=$${benefit.toLocaleString()} | Cost=$${cost.toLocaleString()} | ROI=${roiPct.toFixed(1)}% (bounded)`,
    ]
      .filter(Boolean)
      .join("\n")

    // Provider selection
    const web3formsKey = process.env.WEB3FORMS_ACCESS_KEY
    const formspreeId = process.env.FORMSPREE_FORM_ID
    // Note: Netlify Forms requires static form markup at deploy time. For dynamic Next/Vercel,
    // prefer Web3Forms or Formspree. If you must use Netlify Forms, deploy this page on Netlify
    // with proper form attributes or set up Netlify Forms submission API with auth.

    let forwarded = false
    let forwardRes: Response | null = null

    if (web3formsKey) {
      const fd = new FormData()
      fd.append("access_key", web3formsKey)
      fd.append("subject", subject)
      fd.append("from_name", contactName || companyName)
      fd.append("from_email", email)
      fd.append("company", companyName)
      fd.append("message", message)
      fd.append("case_id", caseId)

      // Add structured fields too for dashboard visibility
      fd.append("timeline", timeline)
      fd.append("budget_range", budgetRange)
      fd.append("challenges", challenges.join(", "))
      fd.append("maturity", maturity.join(", "))
      fd.append("website", website)
      fd.append("phone", phone)
      fd.append("roi_pct", roiPct.toFixed(1))
      fd.append("est_benefit", String(benefit))
      fd.append("est_cost", String(cost))

      if (file) {
        // Web3Forms supports file attachments via multipart form-data
        fd.append("file", file, file.name)
      }

      forwardRes = await fetch("https://api.web3forms.com/submit", {
        method: "POST",
        body: fd,
      })
      forwarded = forwardRes.ok
    } else if (formspreeId) {
      const endpoint = `https://formspree.io/f/${formspreeId}`
      const fd = new FormData()
      fd.append("_subject", subject)
      fd.append("companyName", companyName)
      fd.append("website", website)
      fd.append("contactName", contactName)
      fd.append("email", email)
      fd.append("phone", phone)
      fd.append("timeline", timeline)
      fd.append("budgetRange", budgetRange)
      fd.append("challenges", challenges.join(", "))
      fd.append("maturity", maturity.join(", "))
      fd.append("summary", summary)
      fd.append("roiPct", roiPct.toFixed(1))
      fd.append("estBenefit", String(benefit))
      fd.append("estCost", String(cost))
      fd.append("caseId", caseId)
      if (file) fd.append("attachment", file, file.name)

      forwardRes = await fetch(endpoint, { method: "POST", body: fd })
      forwarded = forwardRes.ok
    } else {
      // No provider configured
      return NextResponse.json(
        {
          error: "No form provider configured. Set WEB3FORMS_ACCESS_KEY or FORMSPREE_FORM_ID in your environment.",
        },
        { status: 500 },
      )
    }

    if (!forwarded) {
      const errText = await forwardRes?.text()
      return NextResponse.json({ error: "Provider submission failed", providerError: errText }, { status: 502 })
    }

    return NextResponse.json({ ok: true, caseId }, { status: 200 })
  } catch (e: any) {
    return NextResponse.json({ error: e?.message || "Unknown error" }, { status: 500 })
  }
}
