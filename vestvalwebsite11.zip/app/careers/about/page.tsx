import Header from "@/components/Header"
import Footer from "@/components/Footer"
import { Breadcrumbs } from "@/components/Breadcrumbs"

export const metadata = {
  title: "Careers at Vestval — About Careers",
  description: "Why build your career at Vestval: mission, values, and growth.",
}

export default function CareersAbout() {
  return (
    <main>
      <Header />
      <section className="pt-8">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <Breadcrumbs items={[{ name: "Careers", href: "/careers" }, { name: "About Vestval Careers" }]} />
          <h1 className="text-3xl md:text-4xl font-bold mt-6 mb-4">About Vestval Careers</h1>
          <p className="text-gray-600">Entrepreneurial culture, global impact, and continuous learning.</p>
        </div>
      </section>
      <Footer />
    </main>
  )
}
