"use client"

import { useState } from "react"
import Header from "@/components/Header"
import Footer from "@/components/Footer"
import { Breadcrumbs } from "@/components/Breadcrumbs"

export default function CareersApply() {
  const [submitted, setSubmitted] = useState(false)

  return (
    <main>
      <Header />
      <section className="pt-8">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-2xl">
          <Breadcrumbs items={[{ name: "Careers", href: "/careers" }, { name: "Apply" }]} />
          <h1 className="text-3xl md:text-4xl font-bold mt-6 mb-4">Apply</h1>
          <p className="text-gray-600 mb-6">Submit your application. We’ll route it to the right team.</p>

          <form
            name="careers-apply"
            method="POST"
            data-netlify="true"
            data-netlify-honeypot="bot-field"
            encType="multipart/form-data"
            action="/careers/apply/success"
            onSubmit={() => setSubmitted(true)}
            className="space-y-5"
          >
            {/* Netlify requires the hidden form-name input */}
            <input type="hidden" name="form-name" value="careers-apply" />
            {/* Honeypot anti-spam (Netlify) */}
            <input type="hidden" name="bot-field" />

            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                Full name
              </label>
              <input id="name" name="name" required className="mt-1 w-full rounded-md border px-3 py-2" />
            </div>

            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                Email
              </label>
              <input
                id="email"
                name="email"
                type="email"
                required
                className="mt-1 w-full rounded-md border px-3 py-2"
              />
            </div>

            <div>
              <label htmlFor="role" className="block text-sm font-medium text-gray-700">
                Role applying for
              </label>
              <input id="role" name="role" className="mt-1 w-full rounded-md border px-3 py-2" />
            </div>

            <div>
              <label htmlFor="resume" className="block text-sm font-medium text-gray-700">
                Resume (PDF, up to 8 MB)
              </label>
              <input id="resume" name="resume" type="file" accept="application/pdf" className="mt-1 w-full" />
            </div>

            <div>
              <label htmlFor="message" className="block text-sm font-medium text-gray-700">
                Message
              </label>
              <textarea id="message" name="message" rows={4} className="mt-1 w-full rounded-md border px-3 py-2" />
            </div>

            <button type="submit" className="inline-flex items-center rounded-md bg-blue-600 px-4 py-2 text-white">
              {submitted ? "Submitting..." : "Submit Application"}
            </button>

            <p className="text-xs text-gray-500">
              Submissions are stored in Netlify and routed to email. Quotas/limits apply per plan.
            </p>

            {/*
              Alternative backends (commented):
              - Formspree: set action="https://formspree.io/f/your-id" and remove data-netlify
              - Web3Forms: set action="https://api.web3forms.com/submit" and include access_key
            */}
          </form>
        </div>
      </section>
      <Footer />
    </main>
  )
}
