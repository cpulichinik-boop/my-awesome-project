"use client"

import { useMemo, useState } from "react"

type Job = { title: string; department: string; location: string; id: string }

const JOBS: Job[] = [
  { id: "1", title: "Consultant, Technology & Engineering", department: "Technology", location: "Mumbai" },
  { id: "2", title: "Senior Analyst, Finance (CFO Services)", department: "Finance", location: "Remote" },
  { id: "3", title: "Engagement Manager, Management Consulting", department: "Consulting", location: "Philadelphia" },
]

export function CareersJobsClient() {
  const [q, setQ] = useState("")
  const [dept, setDept] = useState("All")

  const departments = ["All", ...Array.from(new Set(JOBS.map((j) => j.department)))]
  const filtered = useMemo(
    () =>
      JOBS.filter(
        (j) =>
          (dept === "All" || j.department === dept) &&
          (j.title.toLowerCase().includes(q.toLowerCase()) || j.location.toLowerCase().includes(q.toLowerCase())),
      ),
    [q, dept],
  )

  return (
    <>
      <div className="flex flex-col md:flex-row gap-3 mb-6">
        <input
          aria-label="Search jobs"
          placeholder="Search jobs or locations"
          className="border rounded-md px-3 py-2 w-full md:w-1/2"
          value={q}
          onChange={(e) => setQ(e.target.value)}
        />
        <select
          aria-label="Filter by department"
          className="border rounded-md px-3 py-2 w-full md:w-60"
          value={dept}
          onChange={(e) => setDept(e.target.value)}
        >
          {departments.map((d) => (
            <option key={d}>{d}</option>
          ))}
        </select>
      </div>

      <ul className="space-y-3">
        {filtered.map((j) => (
          <li key={j.id} className="border rounded-lg p-4 flex flex-col md:flex-row md:items-center md:justify-between">
            <div>
              <div className="font-semibold">{j.title}</div>
              <div className="text-sm text-gray-600">
                {j.department} • {j.location}
              </div>
            </div>
            <a
              className="text-blue-600 hover:underline mt-2 md:mt-0"
              href={`mailto:careers@vestval.com?subject=Application: ${encodeURIComponent(j.title)}`}
            >
              Apply
            </a>
          </li>
        ))}
      </ul>
    </>
  )
}
