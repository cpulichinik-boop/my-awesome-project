import Header from "@/components/Header"
import Footer from "@/components/Footer"
import { Breadcrumbs } from "@/components/Breadcrumbs"
import { CareersJobsClient } from "./CareersJobsClient"

export const metadata = {
  title: "Job Search — Careers | Vestval",
  description: "Search and filter open roles at Vestval.",
}

export default function CareersJobs() {
  return (
    <main>
      <Header />
      <section className="pt-8">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <Breadcrumbs items={[{ name: "Careers", href: "/careers" }, { name: "Job Search" }]} />
          <h1 className="text-3xl md:text-4xl font-bold mt-6 mb-6">Job Search</h1>
          <CareersJobsClient />
          <div className="text-xs text-gray-500 mt-6">
            JobPosting JSON-LD will be rendered server-side per role. {/* TODO */}
          </div>
        </div>
      </section>
      <Footer />
    </main>
  )
}
