import Header from "@/components/Header"
import Footer from "@/components/Footer"
import ScrollToTop from "@/components/ScrollToTop"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { MapPin, Clock, Users, Award, Mail, ExternalLink } from "lucide-react"
import Link from "next/link"

export const metadata = {
  title: "Careers - Vestval | Join Our Global Advisory Team",
  description:
    "Join Vestval's growing team of global advisory professionals. Explore career opportunities in IT, Finance, M&A, and Management Consulting.",
}

const jobOpenings = [
  {
    title: "Senior Financial Analyst",
    department: "Finance & M&A Advisory",
    location: "Mumbai, India",
    type: "Full-time",
    experience: "5-8 years",
    description: "Lead financial modeling, valuation, and cross-border deal analysis for our growing M&A practice.",
    requirements: [
      "MBA in Finance or related field",
      "5+ years in investment banking or corporate finance",
      "Strong financial modeling and valuation skills",
      "Cross-border deal experience preferred",
      "Excellent communication and presentation skills",
    ],
    benefits: ["Competitive salary", "Performance bonuses", "Global exposure", "Learning & development"],
  },
  {
    title: "AI & Machine Learning Engineer",
    department: "IT & Digital Transformation",
    location: "Remote / Mumbai",
    type: "Full-time",
    experience: "3-6 years",
    description:
      "Develop and deploy AI models for financial insights and business intelligence across our advisory services.",
    requirements: [
      "MS/BTech in Computer Science or related field",
      "3+ years in AI/ML development",
      "Experience with Python, TensorFlow, PyTorch",
      "Knowledge of financial markets preferred",
      "Strong problem-solving abilities",
    ],
    benefits: ["Remote work options", "Cutting-edge projects", "Conference attendance", "Stock options"],
  },
  {
    title: "Leasing Strategy Consultant",
    department: "Leasing Advisory",
    location: "Pune, India",
    type: "Full-time",
    experience: "4-7 years",
    description: "Provide strategic leasing advisory and vendor relationship management for diverse industry clients.",
    requirements: [
      "MBA or equivalent in Finance/Operations",
      "4+ years in asset financing or leasing",
      "Strong analytical and negotiation skills",
      "Industry knowledge in manufacturing/infrastructure",
      "Client relationship management experience",
    ],
    benefits: ["Industry leadership role", "Client interaction", "Travel opportunities", "Professional growth"],
  },
  {
    title: "Management Consultant",
    department: "Management Consulting",
    location: "New York, USA",
    type: "Full-time",
    experience: "6-10 years",
    description: "Lead operational strategy and market entry projects for Fortune 500 clients across North America.",
    requirements: [
      "MBA from top-tier business school",
      "6+ years in management consulting",
      "Experience with Big 4 or tier-1 consulting firms",
      "Strong project management skills",
      "US work authorization required",
    ],
    benefits: ["Competitive compensation", "International projects", "Leadership development", "Flexible work"],
  },
  {
    title: "Business Development Manager",
    department: "Business Development",
    location: "London, UK",
    type: "Full-time",
    experience: "5-8 years",
    description: "Drive business growth and client acquisition across European markets for our advisory services.",
    requirements: [
      "Bachelor's degree in Business or related field",
      "5+ years in B2B sales or business development",
      "Experience in professional services",
      "Strong network in European markets",
      "Excellent presentation and negotiation skills",
    ],
    benefits: ["Commission structure", "European market exposure", "Networking events", "Career progression"],
  },
  {
    title: "Digital Marketing Specialist",
    department: "Marketing",
    location: "Mumbai, India",
    type: "Full-time",
    experience: "2-4 years",
    description:
      "Lead digital marketing initiatives to build Vestval's brand presence and thought leadership globally.",
    requirements: [
      "Bachelor's degree in Marketing or related field",
      "2+ years in digital marketing",
      "Experience with SEO, SEM, social media",
      "Content creation and analytics skills",
      "B2B marketing experience preferred",
    ],
    benefits: ["Creative freedom", "Global brand building", "Latest marketing tools", "Skill development"],
  },
]

const benefits = [
  {
    icon: <Award className="h-6 w-6" />,
    title: "Competitive Compensation",
    description: "Market-leading salaries with performance-based bonuses and equity participation",
  },
  {
    icon: <Users className="h-6 w-6" />,
    title: "Global Exposure",
    description: "Work with international clients and collaborate across our global office network",
  },
  {
    icon: <Clock className="h-6 w-6" />,
    title: "Flexible Work",
    description: "Hybrid work options and flexible schedules to support work-life balance",
  },
  {
    icon: <ExternalLink className="h-6 w-6" />,
    title: "Learning & Development",
    description: "Continuous learning opportunities, certifications, and conference attendance",
  },
]

export default function CareersPage() {
  return (
    <main className="min-h-screen">
      <Header />

      {/* Hero Section */}
      <section className="pt-24 pb-16 gradient-bg text-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 animate-fade-in-up">Join Vestval</h1>
            <p className="text-xl md:text-2xl mb-8 opacity-90 animate-fade-in-up" style={{ animationDelay: "0.2s" }}>
              Build a global advisory leader with us. Shape the future of business transformation.
            </p>
            <Button asChild size="lg" className="bg-white text-blue-600 hover:bg-gray-100">
              <a href="mailto:careers@vestval.com">Apply Now</a>
            </Button>
          </div>
        </div>
      </section>

      {/* Culture Section */}
      <section className="py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Why Work at Vestval?</h2>
            <p className="text-xl text-gray-600">
              Join a dynamic team committed to innovation, growth, and employee success. We foster an entrepreneurial
              spirit, collaborative environment, and focus on diversity and inclusion.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {benefits.map((benefit, index) => (
              <Card key={index} className="text-center hover-lift">
                <CardContent className="p-6">
                  <div className="w-12 h-12 gradient-bg rounded-full flex items-center justify-center mx-auto mb-4 text-white">
                    {benefit.icon}
                  </div>
                  <h3 className="text-lg font-bold mb-3">{benefit.title}</h3>
                  <p className="text-gray-600 text-sm">{benefit.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Job Openings */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Current Openings</h2>
            <p className="text-xl text-gray-600">
              Explore exciting opportunities across our global offices and departments
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
            {jobOpenings.map((job, index) => (
              <Card key={index} className="hover-lift">
                <CardHeader>
                  <div className="flex justify-between items-start mb-2">
                    <CardTitle className="text-xl">{job.title}</CardTitle>
                    <Badge variant="secondary">{job.type}</Badge>
                  </div>
                  <div className="flex flex-wrap gap-2 text-sm text-gray-600">
                    <div className="flex items-center">
                      <MapPin className="h-4 w-4 mr-1" />
                      {job.location}
                    </div>
                    <div className="flex items-center">
                      <Clock className="h-4 w-4 mr-1" />
                      {job.experience}
                    </div>
                  </div>
                  <Badge variant="outline" className="w-fit">
                    {job.department}
                  </Badge>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-4">{job.description}</p>

                  <div className="mb-4">
                    <h4 className="font-semibold mb-2">Requirements:</h4>
                    <ul className="text-sm text-gray-600 space-y-1">
                      {job.requirements.slice(0, 3).map((req, idx) => (
                        <li key={idx} className="flex items-start">
                          <span className="w-1.5 h-1.5 bg-blue-600 rounded-full mt-2 mr-2 flex-shrink-0"></span>
                          {req}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="mb-6">
                    <h4 className="font-semibold mb-2">Benefits:</h4>
                    <div className="flex flex-wrap gap-2">
                      {job.benefits.map((benefit, idx) => (
                        <Badge key={idx} variant="secondary" className="text-xs">
                          {benefit}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <Button asChild className="w-full gradient-bg text-white">
                    <a
                      href={`mailto:careers@vestval.com?subject=Application for ${job.title}&body=Dear Vestval Team,%0D%0A%0D%0AI am interested in applying for the ${job.title} position in ${job.location}. Please find my resume attached.%0D%0A%0D%0ABest regards`}
                    >
                      Apply for this Position
                    </a>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Application Process */}
      <section className="py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-8">Application Process</h2>
            <div className="grid md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="w-12 h-12 gradient-bg rounded-full flex items-center justify-center mx-auto mb-4 text-white font-bold">
                  1
                </div>
                <h3 className="text-lg font-bold mb-2">Submit Application</h3>
                <p className="text-gray-600 text-sm">Send your resume and cover letter to careers@vestval.com</p>
              </div>

              <div className="text-center">
                <div className="w-12 h-12 gradient-bg rounded-full flex items-center justify-center mx-auto mb-4 text-white font-bold">
                  2
                </div>
                <h3 className="text-lg font-bold mb-2">Interview Process</h3>
                <p className="text-gray-600 text-sm">
                  Initial screening followed by technical and cultural fit interviews
                </p>
              </div>

              <div className="text-center">
                <div className="w-12 h-12 gradient-bg rounded-full flex items-center justify-center mx-auto mb-4 text-white font-bold">
                  3
                </div>
                <h3 className="text-lg font-bold mb-2">Welcome Aboard</h3>
                <p className="text-gray-600 text-sm">Comprehensive onboarding and integration into our global team</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 gradient-bg text-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Don't See the Right Role?</h2>
          <p className="text-xl mb-8 opacity-90 max-w-2xl mx-auto">
            We're always looking for exceptional talent. Send us your resume and let us know how you can contribute to
            Vestval's growth.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" className="bg-white text-blue-600 hover:bg-gray-100">
              <a href="mailto:careers@vestval.com?subject=General Application&body=Dear Vestval Team,%0D%0A%0D%0AI am interested in exploring opportunities with Vestval. Please find my resume attached.%0D%0A%0D%0ABest regards">
                <Mail className="h-5 w-5 mr-2" />
                Send General Application
              </a>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="border-white text-white hover:bg-white hover:text-blue-600 bg-transparent"
            >
              <Link href="/contact">Contact HR Team</Link>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
      <ScrollToTop />
    </main>
  )
}
