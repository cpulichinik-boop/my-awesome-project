import Header from "@/components/Header"
import Footer from "@/components/Footer"
import { Breadcrumbs } from "@/components/Breadcrumbs"

export const metadata = {
  title: "What You Can Do Here — Career Paths | Vestval",
  description: "Paths across functions and locations to grow your career.",
}

export default function CareersPaths() {
  return (
    <main>
      <Header />
      <section className="pt-8">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <Breadcrumbs items={[{ name: "Careers", href: "/careers" }, { name: "What you can do here" }]} />
          <h1 className="text-3xl md:text-4xl font-bold mt-6 mb-4">What You Can Do Here</h1>
          <p className="text-gray-600">Opportunities in Consulting, Technology, Finance, Marketing, and more.</p>
        </div>
      </section>
      <Footer />
    </main>
  )
}
