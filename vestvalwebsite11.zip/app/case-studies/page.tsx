import Header from "@/components/Header"
import Footer from "@/components/Footer"
import ScrollToTop from "@/components/ScrollToTop"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowRight } from "lucide-react"
import Link from "next/link"

export const metadata = {
  title: "Case Studies - Vestval | Success Stories & Client Results",
  description:
    "Explore Vestval's successful client engagements across IT transformation, M&A advisory, leasing optimization, and strategic consulting.",
}

const caseStudies = [
  {
    title: "Cross-Border Technology Acquisition",
    industry: "Technology",
    service: "M&A Advisory",
    challenge:
      "A leading Indian software company sought to acquire a strategic technology firm in Europe to expand their AI capabilities and market presence.",
    solution:
      "Vestval provided comprehensive due diligence, valuation analysis, and integration planning using our AI-powered analytics platform. We managed cross-border regulatory compliance and cultural integration strategies.",
    results: [
      "Seamless acquisition completed within 8-month timeline",
      "15% operational synergy realized post-integration",
      "€50M deal value with 20% cost savings identified",
      "Successful integration of 200+ employees across 3 countries",
    ],
    metrics: {
      dealValue: "€50M",
      timeframe: "8 months",
      synergies: "15%",
      countries: "3",
    },
  },
  {
    title: "Manufacturing Equipment Leasing Optimization",
    industry: "Manufacturing",
    service: "Leasing Advisory",
    challenge:
      "A rapidly growing manufacturing company needed to expand production capacity while maintaining cash flow flexibility and avoiding large capital expenditures.",
    solution:
      "Our leasing advisory team developed a customized asset-light growth model, negotiated favorable vendor relationships, and structured flexible leasing arrangements across multiple equipment categories.",
    results: [
      "20% reduction in total financing costs",
      "Enhanced operational flexibility for expansion",
      "Improved cash flow management by $5M annually",
      "Established strategic vendor partnerships",
    ],
    metrics: {
      costSavings: "20%",
      cashFlow: "$5M",
      vendors: "12",
      equipment: "50+",
    },
  },
  {
    title: "Digital Transformation for Financial Services",
    industry: "Financial Services",
    service: "IT & Digital Transformation",
    challenge:
      "A traditional financial services firm needed to modernize their technology infrastructure, implement AI-driven analytics, and enhance customer experience to compete with fintech disruptors.",
    solution:
      "Vestval designed and implemented a comprehensive digital transformation strategy including cloud migration, AI-powered customer insights, mobile application development, and cybersecurity enhancement.",
    results: [
      "40% improvement in customer satisfaction scores",
      "60% reduction in processing time for key services",
      "30% increase in digital channel adoption",
      "Enhanced security posture with zero breaches",
    ],
    metrics: {
      satisfaction: "40%",
      efficiency: "60%",
      adoption: "30%",
      security: "100%",
    },
  },
  {
    title: "Capital Structure Optimization",
    industry: "Healthcare",
    service: "Capital Advisory",
    challenge:
      "A growing healthcare network required capital restructuring to fund expansion while optimizing their debt-to-equity ratio and reducing financing costs.",
    solution:
      "Our CFO advisory team conducted comprehensive financial analysis, restructured existing debt, identified new funding sources, and developed a strategic financial plan aligned with growth objectives.",
    results: [
      "25% reduction in overall cost of capital",
      "Successful raising of $30M in growth capital",
      "Improved debt-to-equity ratio from 3:1 to 2:1",
      "Enhanced financial flexibility for acquisitions",
    ],
    metrics: {
      costReduction: "25%",
      capitalRaised: "$30M",
      debtRatio: "2:1",
      timeline: "6 months",
    },
  },
  {
    title: "Market Entry Strategy for Indian Expansion",
    industry: "Consumer Goods",
    service: "Management Consulting",
    challenge:
      "A European consumer goods company wanted to enter the Indian market but faced regulatory complexities, cultural barriers, and intense local competition.",
    solution:
      "Vestval developed a comprehensive market entry strategy including regulatory compliance roadmap, local partnership identification, distribution channel optimization, and brand positioning for Indian consumers.",
    results: [
      "Successful market entry within 12 months",
      "Achieved 8% market share in target segment",
      "Established distribution network across 15 states",
      "Generated $25M revenue in first year",
    ],
    metrics: {
      marketShare: "8%",
      states: "15",
      revenue: "$25M",
      timeline: "12 months",
    },
  },
]

export default function CaseStudiesPage() {
  return (
    <main className="min-h-screen">
      <Header />

      {/* Hero Section */}
      <section className="pt-24 pb-16 gradient-bg text-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 animate-fade-in-up">Case Studies</h1>
            <p className="text-xl md:text-2xl mb-8 opacity-90 animate-fade-in-up" style={{ animationDelay: "0.2s" }}>
              Real results from our global advisory engagements across industries
            </p>
          </div>
        </div>
      </section>

      {/* Success Metrics */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Track Record</h2>
            <p className="text-xl text-gray-600">
              Our team members have collectively delivered exceptional results across global markets
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-4xl mx-auto">
            <div className="text-center">
              <div className="text-4xl font-bold gradient-text mb-2">300+</div>
              <p className="text-gray-600">M&A Deals Completed</p>
              <p className="text-sm text-gray-500 mt-1">by our team members</p>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold gradient-text mb-2">100+</div>
              <p className="text-gray-600">Businesses Evaluated</p>
              <p className="text-sm text-gray-500 mt-1">across diverse sectors</p>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold gradient-text mb-2">$1B+</div>
              <p className="text-gray-600">Value Delivered</p>
              <p className="text-sm text-gray-500 mt-1">through our advisory</p>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold gradient-text mb-2">30+</div>
              <p className="text-gray-600">Countries Served</p>
              <p className="text-sm text-gray-500 mt-1">global reach</p>
            </div>
          </div>
        </div>
      </section>

      {/* Case Studies */}
      <section className="py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="space-y-16">
            {caseStudies.map((study, index) => (
              <Card key={index} className="max-w-6xl mx-auto overflow-hidden hover-lift">
                <CardHeader className="bg-gradient-to-r from-blue-50 to-yellow-50">
                  <div className="flex flex-wrap items-center justify-between mb-4">
                    <CardTitle className="text-2xl md:text-3xl">{study.title}</CardTitle>
                    <div className="flex gap-2">
                      <Badge variant="secondary">{study.industry}</Badge>
                      <Badge className="gradient-bg text-white">{study.service}</Badge>
                    </div>
                  </div>
                </CardHeader>

                <CardContent className="p-8">
                  <div className="grid lg:grid-cols-3 gap-8">
                    <div className="lg:col-span-2 space-y-6">
                      <div>
                        <h3 className="text-lg font-bold mb-3 flex items-center">
                          <div className="w-2 h-2 bg-red-500 rounded-full mr-3"></div>
                          Challenge
                        </h3>
                        <p className="text-gray-600 leading-relaxed">{study.challenge}</p>
                      </div>

                      <div>
                        <h3 className="text-lg font-bold mb-3 flex items-center">
                          <div className="w-2 h-2 bg-blue-500 rounded-full mr-3"></div>
                          Solution
                        </h3>
                        <p className="text-gray-600 leading-relaxed">{study.solution}</p>
                      </div>

                      <div>
                        <h3 className="text-lg font-bold mb-3 flex items-center">
                          <div className="w-2 h-2 bg-green-500 rounded-full mr-3"></div>
                          Results
                        </h3>
                        <ul className="space-y-2">
                          {study.results.map((result, idx) => (
                            <li key={idx} className="flex items-start text-gray-600">
                              <ArrowRight className="h-4 w-4 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                              {result}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>

                    <div className="lg:col-span-1">
                      <div className="bg-gray-50 rounded-lg p-6">
                        <h3 className="text-lg font-bold mb-4">Key Metrics</h3>
                        <div className="space-y-4">
                          {Object.entries(study.metrics).map(([key, value], idx) => (
                            <div key={idx} className="flex justify-between items-center">
                              <span className="text-gray-600 capitalize">{key.replace(/([A-Z])/g, " $1").trim()}</span>
                              <span className="font-bold text-blue-600">{value}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 gradient-bg text-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Create Your Success Story?</h2>
          <p className="text-xl mb-8 opacity-90 max-w-2xl mx-auto">
            Let Vestval help you navigate complex challenges and achieve transformational results for your business.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" className="bg-white text-blue-600 hover:bg-gray-100">
              <Link href="/contact">Start Your Project</Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="border-white text-white hover:bg-white hover:text-blue-600 bg-transparent"
            >
              <Link href="/services">Explore Our Services</Link>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
      <ScrollToTop />
    </main>
  )
}
