import Header from "@/components/Header"
import Footer from "@/components/Footer"
import ScrollToTop from "@/components/ScrollToTop"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { MapPin, Phone, Mail, Clock, Globe } from "lucide-react"

export const metadata = {
  title: "Contact Us - Vestval | Get In Touch With Our Experts",
  description:
    "Contact Vestval's global advisory team. Offices in Mumbai, Philadelphia, and Manchester. Email: contact@vestval.com",
}

const offices = [
  {
    city: "Mumbai",
    country: "India",
    address: "North Ave, near MAKER MAXITY, Bandra Kurla Complex, Bandra East, Mumbai, Maharashtra 400051",
    phone: "+91 22 6789 0123",
    email: "mumbai@vestval.com",
    timezone: "IST (UTC+5:30)",
    hours: "9:00 AM - 6:00 PM",
    isHQ: true,
  },
  {
    city: "Philadelphia",
    country: "USA",
    address: "190 N Independence Mall W, Philadelphia, PA 19106, USA",
    phone: "+1 215 555 0123",
    email: "philadelphia@vestval.com",
    timezone: "EST (UTC-5)",
    hours: "9:00 AM - 5:00 PM",
  },
  {
    city: "Manchester",
    country: "UK",
    address: "CIS Tower, 6 Hanover St, Manchester M4 4BB, UK",
    phone: "+44 161 555 0123",
    email: "manchester@vestval.com",
    timezone: "GMT (UTC+0)",
    hours: "9:00 AM - 5:00 PM",
  },
]

export default function ContactPage() {
  return (
    <main className="min-h-screen">
      <Header />

      {/* Hero Section */}
      <section className="pt-24 pb-16 gradient-bg text-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 animate-fade-in-up">Contact Us</h1>
            <p className="text-xl md:text-2xl mb-8 opacity-90 animate-fade-in-up" style={{ animationDelay: "0.2s" }}>
              Ready to transform your business? Get in touch with our global advisory experts.
            </p>
          </div>
        </div>
      </section>

      {/* Contact Form & Info */}
      <section className="py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
            {/* Contact Form */}
            <Card className="hover-lift">
              <CardHeader>
                <CardTitle className="text-2xl">Send us a Message</CardTitle>
                <p className="text-gray-600">Fill out the form below and we'll get back to you within 24 hours.</p>
              </CardHeader>
              <CardContent>
                <form action="mailto:contact@vestval.com" method="post" encType="text/plain" className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="name">Full Name *</Label>
                      <Input id="name" name="name" required className="mt-1" placeholder="Your full name" />
                    </div>
                    <div>
                      <Label htmlFor="company">Company</Label>
                      <Input id="company" name="company" className="mt-1" placeholder="Your company name" />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="email">Email Address *</Label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        required
                        className="mt-1"
                        placeholder="your.email@company.com"
                      />
                    </div>
                    <div>
                      <Label htmlFor="phone">Phone Number</Label>
                      <Input id="phone" name="phone" type="tel" className="mt-1" placeholder="+1 (555) 123-4567" />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="service">Service Interest</Label>
                    <select
                      id="service"
                      name="service"
                      className="w-full mt-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="">Select a service</option>
                      <option value="IT & Digital Transformation">IT & Digital Transformation</option>
                      <option value="M&A Advisory">M&A Advisory</option>
                      <option value="Leasing Advisory">Leasing Advisory</option>
                      <option value="Capital Advisory & CFO Services">Capital Advisory & CFO Services</option>
                      <option value="Management Consulting">Management Consulting</option>
                      <option value="General Inquiry">General Inquiry</option>
                    </select>
                  </div>

                  <div>
                    <Label htmlFor="message">Message *</Label>
                    <Textarea
                      id="message"
                      name="message"
                      required
                      className="mt-1"
                      rows={5}
                      placeholder="Tell us about your project or inquiry..."
                    />
                  </div>

                  <Button type="submit" className="w-full gradient-bg text-white hover:opacity-90">
                    Send Message
                  </Button>
                </form>
              </CardContent>
            </Card>

            {/* Contact Information */}
            <div className="space-y-8">
              <div>
                <h2 className="text-2xl font-bold mb-6">Get in Touch</h2>
                <div className="space-y-4">
                  <div className="flex items-center">
                    <Mail className="h-5 w-5 text-blue-600 mr-3" />
                    <div>
                      <p className="font-medium">General Inquiries</p>
                      <a href="mailto:contact@vestval.com" className="text-blue-600 hover:underline">
                        contact@vestval.com
                      </a>
                    </div>
                  </div>

                  <div className="flex items-center">
                    <Phone className="h-5 w-5 text-blue-600 mr-3" />
                    <div>
                      <p className="font-medium">24/7 Emergency Consultation</p>
                      <p className="text-gray-600">Available for urgent matters</p>
                    </div>
                  </div>

                  <div className="flex items-center">
                    <Globe className="h-5 w-5 text-blue-600 mr-3" />
                    <div>
                      <p className="font-medium">Global Coverage</p>
                      <p className="text-gray-600">Serving clients across 30+ countries</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Quick Links */}
              <Card>
                <CardContent className="p-6">
                  <h3 className="text-lg font-bold mb-4">Quick Links</h3>
                  <div className="space-y-2">
                    <a href="mailto:careers@vestval.com" className="block text-blue-600 hover:underline">
                      Careers & Job Applications
                    </a>
                    <a href="mailto:media@vestval.com" className="block text-blue-600 hover:underline">
                      Media & Press Inquiries
                    </a>
                    <a href="mailto:partnerships@vestval.com" className="block text-blue-600 hover:underline">
                      Partnership Opportunities
                    </a>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Global Offices */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Global Offices</h2>
            <p className="text-xl text-gray-600">Connect with our teams across three continents</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {offices.map((office, index) => (
              <Card key={index} className="hover-lift">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-xl">
                      {office.city}, {office.country}
                    </CardTitle>
                    {office.isHQ && (
                      <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded-full">HQ</span>
                    )}
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-start">
                    <MapPin className="h-5 w-5 text-gray-400 mr-3 mt-0.5 flex-shrink-0" />
                    <p className="text-gray-600 text-sm">{office.address}</p>
                  </div>

                  <div className="flex items-center">
                    <Phone className="h-5 w-5 text-gray-400 mr-3" />
                    <a href={`tel:${office.phone}`} className="text-blue-600 hover:underline">
                      {office.phone}
                    </a>
                  </div>

                  <div className="flex items-center">
                    <Mail className="h-5 w-5 text-gray-400 mr-3" />
                    <a href={`mailto:${office.email}`} className="text-blue-600 hover:underline">
                      {office.email}
                    </a>
                  </div>

                  <div className="flex items-center">
                    <Clock className="h-5 w-5 text-gray-400 mr-3" />
                    <div>
                      <p className="text-gray-600 text-sm">{office.hours}</p>
                      <p className="text-gray-500 text-xs">{office.timezone}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <Footer />
      <ScrollToTop />
    </main>
  )
}
