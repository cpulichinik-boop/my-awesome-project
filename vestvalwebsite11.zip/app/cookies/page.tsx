import Header from "@/components/Header"
import Footer from "@/components/Footer"
import { Breadcrumbs } from "@/components/Breadcrumbs"

export const metadata = {
  title: "Cookie Policy - Vestval | Cookie Usage & Management",
  description: "Learn about how Vestval uses cookies and how you can manage your cookie preferences.",
}

export default function CookiePolicyPage() {
  return (
    <main>
      <Header />
      <section className="pt-8 pb-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-4xl">
          <Breadcrumbs items={[{ name: "Cookie Policy" }]} />
          <h1 className="text-3xl md:text-4xl font-bold mt-6 mb-8">Cookie Policy</h1>

          <div className="prose prose-gray max-w-none">
            <p className="text-lg text-gray-600 mb-8">Last updated: January 2025</p>

            <section className="mb-8">
              <h2 className="text-2xl font-bold mb-4">What Are Cookies</h2>
              <p className="mb-4">
                Cookies are small text files that are placed on your computer or mobile device when you visit a website.
                They are widely used to make websites work more efficiently and provide information to website owners.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold mb-4">How We Use Cookies</h2>
              <p className="mb-4">We use cookies for several purposes:</p>
              <ul className="list-disc pl-6 mb-4">
                <li>
                  <strong>Essential Cookies:</strong> Required for the website to function properly
                </li>
                <li>
                  <strong>Analytics Cookies:</strong> Help us understand how visitors use our website
                </li>
                <li>
                  <strong>Functional Cookies:</strong> Remember your preferences and settings
                </li>
                <li>
                  <strong>Marketing Cookies:</strong> Used to deliver relevant advertisements
                </li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold mb-4">Types of Cookies We Use</h2>

              <div className="mb-6">
                <h3 className="text-xl font-semibold mb-3">Essential Cookies</h3>
                <p className="mb-2">
                  These cookies are necessary for the website to function and cannot be switched off.
                </p>
                <ul className="list-disc pl-6">
                  <li>Session management</li>
                  <li>Security features</li>
                  <li>Load balancing</li>
                </ul>
              </div>

              <div className="mb-6">
                <h3 className="text-xl font-semibold mb-3">Analytics Cookies</h3>
                <p className="mb-2">These cookies help us understand how our website is being used.</p>
                <ul className="list-disc pl-6">
                  <li>Google Analytics</li>
                  <li>Page view tracking</li>
                  <li>User behavior analysis</li>
                </ul>
              </div>

              <div className="mb-6">
                <h3 className="text-xl font-semibold mb-3">Functional Cookies</h3>
                <p className="mb-2">These cookies enable enhanced functionality and personalization.</p>
                <ul className="list-disc pl-6">
                  <li>Language preferences</li>
                  <li>User interface customization</li>
                  <li>Form data retention</li>
                </ul>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold mb-4">Managing Your Cookies</h2>
              <p className="mb-4">
                You can control and manage cookies in various ways. Please note that removing or blocking cookies can
                impact your user experience and parts of our website may no longer be fully accessible.
              </p>

              <h3 className="text-xl font-semibold mb-3">Browser Settings</h3>
              <p className="mb-4">Most browsers allow you to:</p>
              <ul className="list-disc pl-6 mb-4">
                <li>View what cookies are stored and delete them individually</li>
                <li>Block third-party cookies</li>
                <li>Block cookies from particular sites</li>
                <li>Block all cookies from being set</li>
                <li>Delete all cookies when you close your browser</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold mb-4">Third-Party Cookies</h2>
              <p className="mb-4">We may use third-party services that place cookies on your device. These include:</p>
              <ul className="list-disc pl-6 mb-4">
                <li>
                  <strong>Google Analytics:</strong> For website analytics and performance monitoring
                </li>
                <li>
                  <strong>Social Media Platforms:</strong> For social sharing functionality
                </li>
                <li>
                  <strong>Marketing Platforms:</strong> For targeted advertising and remarketing
                </li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold mb-4">Updates to This Policy</h2>
              <p className="mb-4">
                We may update this Cookie Policy from time to time to reflect changes in our practices or for other
                operational, legal, or regulatory reasons.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold mb-4">Contact Us</h2>
              <p className="mb-4">If you have any questions about our use of cookies, please contact us at:</p>
              <div className="bg-gray-50 p-4 rounded-lg">
                <p>
                  <strong>Email:</strong> privacy@vestval.com
                </p>
                <p>
                  <strong>Address:</strong> Bandra Kurla Complex, Mumbai 400051, India
                </p>
              </div>
            </section>
          </div>
        </div>
      </section>
      <Footer />
    </main>
  )
}
