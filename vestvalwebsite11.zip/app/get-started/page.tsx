"use client"

import Header from "@/components/Header"
import Footer from "@/components/Footer"
import { Breadcrumbs } from "@/components/Breadcrumbs"
import GetStartedForm from "@/components/get-started-form"

export default function GetStarted() {
  return (
    <main>
      <Header />
      <section className="pt-8">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-3xl">
          <Breadcrumbs items={[{ name: "Get Started" }]} />
          <h1 className="text-3xl md:text-4xl font-bold mt-6 mb-6">Get Started</h1>

          <GetStartedForm />
        </div>
      </section>
      <Footer />
    </main>
  )
}
