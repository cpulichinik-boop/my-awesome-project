import Header from "@/components/Header"
import Footer from "@/components/Footer"
import Link from "next/link"

export default function GetStartedSuccess() {
  return (
    <main>
      <Header />
      <section className="pt-10">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-3xl font-bold mb-3">Thank you</h1>
          <p className="text-gray-600 mb-6">We received your request. We’ll follow up with a case identifier.</p>
          <Link href="/" className="text-blue-600 hover:underline">
            Return home
          </Link>
        </div>
      </section>
      <Footer />
    </main>
  )
}
