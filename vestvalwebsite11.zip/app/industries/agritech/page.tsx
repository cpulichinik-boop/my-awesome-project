import Header from "@/components/Header"
import Footer from "@/components/Footer"
import { Breadcrumbs } from "@/components/Breadcrumbs"

export const metadata = {
  title: "Agritech — Consulting Solutions | Vestval",
  description: "Digital platforms, supply optimization, and financing strategies for agritech.",
}

export default function Agritech() {
  return (
    <main>
      <Header />
      <section className="pt-8">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <Breadcrumbs />
          <h1 className="text-3xl md:text-4xl font-bold mt-6 mb-4">Agritech</h1>
          <p className="text-gray-600">
            Enable farmer networks and value chains with data-driven market access and efficiency.
          </p>
        </div>
      </section>
      <Footer />
    </main>
  )
}
