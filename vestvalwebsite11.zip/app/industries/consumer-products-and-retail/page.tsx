import Header from "@/components/Header"
import Footer from "@/components/Footer"
import { Breadcrumbs } from "@/components/Breadcrumbs"
import Link from "next/link"

export const metadata = {
  title: "Consumer Products & Retail — Industry Insights | Vestval",
  description: "Trends, challenges, and solutions for consumer products and retail.",
}

export default function CPRetail() {
  return (
    <main>
      <Header />
      <section className="pt-8">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <Breadcrumbs />
          <h1 className="text-3xl md:text-4xl font-bold mt-6 mb-4">Consumer Products & Retail</h1>
          <p className="text-gray-600 mb-6">Latest industry insights, operational levers, and growth strategies.</p>

          <div className="prose max-w-none">
            <h2 id="pain-points" className="scroll-mt-24">
              Pain Points
            </h2>
            <p>
              Margin erosion from promotions, volatile demand, and supply variability. Siloed data hinders assortment
              and pricing decisions; labor shortages impact store execution.
            </p>

            <h2 id="solutions" className="scroll-mt-24">
              Mapped Solutions
            </h2>
            <ul>
              <li>
                <strong>Demand sensing:</strong> AI-driven forecast blends with store telemetry for fresher signals.
              </li>
              <li>
                <strong>Store digitalization:</strong> tasking, guided selling, and workforce enablement to protect
                service levels.
              </li>
              <li>
                <strong>Working capital uplift:</strong> inventory rightsizing and payment discipline unlock cash.
              </li>
            </ul>

            <h2 id="mini-cases" className="scroll-mt-24">
              Mini Case Studies
            </h2>
            <p>
              <strong>Omnichannel ops:</strong> 18% pick efficiency gain and 12% OOS reduction through layout + process
              + data tweaks.
            </p>
            <p>
              <strong>Assortment optimization:</strong> localized clusters and price-pack architecture increased
              contribution margin 240 bps.
            </p>

            <h2 id="regulation" className="scroll-mt-24">
              Regulation Notes
            </h2>
            <p>
              Labeling, data privacy, and sustainability claims require robust controls; we align governance with
              marketing and operations.
            </p>

            <h2 id="cta" className="scroll-mt-24">
              Next Steps
            </h2>
            <p>
              Run a 6-week diagnostic across demand, store, and working capital levers, then execute a focused 90-day
              plan.
            </p>

            <p className="mt-6">
              Related: <Link href="/services">Services</Link> · <Link href="/insights/it/ai">AI Insights</Link> ·{" "}
              <Link href="/case-studies">Case Studies</Link>
            </p>

            <div className="mt-6">
              <Link
                href="/get-started"
                className="inline-flex items-center rounded-md bg-blue-600 px-5 py-2 text-white"
              >
                Request a discovery call
              </Link>
            </div>
          </div>
        </div>
      </section>
      <Footer />
    </main>
  )
}
