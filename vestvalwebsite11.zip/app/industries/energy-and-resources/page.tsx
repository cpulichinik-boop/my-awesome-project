import Header from "@/components/Header"
import Footer from "@/components/Footer"
import { Breadcrumbs } from "@/components/Breadcrumbs"
import Link from "next/link"

export const metadata = {
  title: "Energy & Resources — Industry Insights | Vestval",
  description: "Transition, resilience, and performance in energy & resources.",
}

export default function EnergyResources() {
  return (
    <main>
      <Header />
      <section className="pt-8">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <Breadcrumbs />
          <h1 className="text-3xl md:text-4xl font-bold mt-6 mb-4">Energy & Resources</h1>
          <p className="text-gray-600 mb-6">Decarbonization, security, and operational excellence define the decade.</p>
          <div className="prose max-w-none">
            <h2>Key Themes</h2>
            <ul>
              <li>Grid modernization and distributed assets</li>
              <li>Supply risk, reliability, and digital field ops</li>
              <li>ESG reporting and capital allocation</li>
            </ul>
            <p>
              Related: <Link href="/services">Services</Link> · <Link href="/insights">IT/Insights</Link> ·{" "}
              <Link href="/case-studies">Case Studies</Link>
            </p>
          </div>
        </div>
      </section>
      <Footer />
    </main>
  )
}
