import Header from "@/components/Header"
import Footer from "@/components/Footer"
import { Breadcrumbs } from "@/components/Breadcrumbs"
import Link from "next/link"

export const metadata = {
  title: "Financial Services — Industry Insights | Vestval",
  description: "Modernization, risk, and growth across banking, fintech, and capital markets.",
}

export default function FinancialServices() {
  return (
    <main>
      <Header />
      <section className="pt-8">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <Breadcrumbs />
          <h1 className="text-3xl md:text-4xl font-bold mt-6 mb-4">Financial Services</h1>
          <p className="text-gray-600 mb-6">Operating model change with cloud, data, and AI at the core.</p>

          <article className="prose max-w-none">
            <h2 id="pain-points" className="scroll-mt-24">
              Pain Points
            </h2>
            <p>
              Fragmented cores, manual controls, and regulatory pressure create cost and risk drag. Legacy integrations
              slow product releases and real-time reporting.
            </p>

            <h2 id="mapped-solutions" className="scroll-mt-24">
              Mapped Solutions
            </h2>
            <ul>
              <li>
                <strong>Compliance-by-design:</strong> embed policies as code, continuous control monitoring, and
                auditable pipelines.
              </li>
              <li>
                <strong>Straight-through processing:</strong> API-first event backbones and orchestration for
                onboarding, KYC/AML, and payments.
              </li>
              <li>
                <strong>Risk & finance data hub:</strong> governed data models that feed MI/BI and regulatory reports.
              </li>
            </ul>

            <h2 id="mini-cases" className="scroll-mt-24">
              Mini Case Studies
            </h2>
            <p>
              <strong>Payments modernization:</strong> Reduced settlement latency from T+1 to near real-time; 35%
              support ticket reduction via observability.
            </p>
            <p>
              <strong>KYC uplift:</strong> Explainable models and policy gates cut false positives 22% while passing
              model risk review.
            </p>

            <h2 id="regulation" className="scroll-mt-24">
              Regulation Notes
            </h2>
            <p>
              Programs align to supervisory expectations across data lineage, privacy, resiliency, and model governance.
              We coordinate with legal advisors for jurisdiction nuances.
            </p>

            <h2 id="next-steps" className="scroll-mt-24">
              Next Steps
            </h2>
            <p>Start with a 6–8 week baseline and a 90–120 day execution plan with weekly value checkpoints.</p>

            {/* Leasing Advisory Callout */}
            <div className="mt-8 rounded-lg border border-gray-200 bg-gray-50 p-4">
              <h3 className="text-xl font-semibold mb-2">Leasing Advisory for Financial Services</h3>
              <p className="text-gray-600 mb-3">
                Optimize technology and equipment spend with vendor-agnostic, multi-funder options across IT, branches,
                and operations.
              </p>
              <div className="flex flex-wrap items-center gap-3">
                <Link
                  href="/services/leasing"
                  className="inline-flex items-center rounded-md bg-blue-600 px-4 py-2 text-white"
                >
                  Explore Leasing Advisory
                </Link>
                <Link href="/services/leasing/process" className="text-blue-600 hover:underline">
                  How it works
                </Link>
                <Link href="/services/leasing/structures" className="text-blue-600 hover:underline">
                  Structures & pricing
                </Link>
                <Link href="/services/leasing/eligibility" className="text-blue-600 hover:underline">
                  Eligibility & documents
                </Link>
              </div>
            </div>

            {/* Related Links */}
            <p className="mt-6">
              Related: <Link href="/services">Services</Link> · <Link href="/services/leasing">Leasing Advisory</Link> ·{" "}
              <Link href="/insights/it/risk">Risk Insights</Link> ·{" "}
              <Link href="/partners/financial-institutions">Financial Institutions Partners</Link>
            </p>

            <div className="mt-6">
              <Link
                href="/get-started"
                className="inline-flex items-center rounded-md bg-blue-600 px-5 py-2 text-white"
              >
                Request a discovery call
              </Link>
            </div>
          </article>
        </div>
      </section>
      <Footer />
    </main>
  )
}
