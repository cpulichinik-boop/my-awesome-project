import Header from "@/components/Header"
import Footer from "@/components/Footer"
import { Breadcrumbs } from "@/components/Breadcrumbs"

export const metadata = {
  title: "Government & Public Sector — Insights | Vestval",
  description: "Digital public services, data governance, and operational excellence.",
}

export default function GovPublic() {
  return (
    <main>
      <Header />
      <section className="pt-8">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <Breadcrumbs />
          <h1 className="text-3xl md:text-4xl font-bold mt-6 mb-4">Government & Public Sector</h1>
          <p className="text-gray-600">Citizen-centric services powered by secure, compliant technology.</p>
        </div>
      </section>
      <Footer />
    </main>
  )
}
