import Header from "@/components/Header"
import Footer from "@/components/Footer"
import { Breadcrumbs } from "@/components/Breadcrumbs"

export const metadata = {
  title: "Manufacturing — Consulting Solutions | Vestval",
  description: "Operational excellence, automation, and cost optimization for manufacturers.",
}

export default function Manufacturing() {
  return (
    <main>
      <Header />
      <section className="pt-8">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <Breadcrumbs />
          <h1 className="text-3xl md:text-4xl font-bold mt-6 mb-4">Manufacturing</h1>
          <p className="text-gray-600">
            Scale production efficiently with automation, asset-light strategies, and resilience.
          </p>
        </div>
      </section>
      <Footer />
    </main>
  )
}
