import Header from "@/components/Header"
import Footer from "@/components/Footer"
import { Breadcrumbs } from "@/components/Breadcrumbs"
import Link from "next/link"

export const metadata = {
  title: "Industries - Vestval | Who We Serve",
  description: "Explore the industries Vestval serves with insights, solutions, and case studies.",
}

const industries = [
  { slug: "consumer-products-and-retail", name: "Consumer Products & Retail" },
  { slug: "energy-and-resources", name: "Energy & Resources" },
  { slug: "financial-services", name: "Financial Services" },
  { slug: "government-and-public-sector", name: "Government & Public Sector" },
  { slug: "healthcare", name: "Innovative Healthcare" },
  { slug: "private-equity", name: "Private Equity" },
  { slug: "technology-media-and-telecommunications", name: "Technology, Media & Telecommunications" },
  { slug: "manufacturing", name: "Manufacturing" },
  { slug: "logistics", name: "Logistics" },
  { slug: "agritech", name: "Agritech" },
  { slug: "data-centers", name: "Data Centers" },
]

export default function IndustriesHub() {
  return (
    <main>
      <Header />
      <section className="pt-8">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <Breadcrumbs items={[{ name: "Industries" }]} />
          <h1 className="text-3xl md:text-4xl font-bold mt-6 mb-4">Industries We Serve</h1>
          <p className="text-gray-600 mb-8">
            Content-rich pages for each sector, linking to services, insights, and case studies.
          </p>
          <ul className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {industries.map((i) => (
              <li key={i.slug} className="border rounded-lg p-5 hover:shadow-lg transition-shadow">
                <h2 className="text-lg font-semibold mb-2">
                  <Link href={`/industries/${i.slug}`}>{i.name}</Link>
                </h2>
                <p className="text-gray-600 text-sm">Latest industry insights, trends, and solutions.</p>
              </li>
            ))}
          </ul>
          {/* Additional sectors to add: manufacturing, logistics, agritech, data centers, and more. */}
        </div>
      </section>
      <Footer />
    </main>
  )
}
