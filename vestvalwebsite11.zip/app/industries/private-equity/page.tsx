import Header from "@/components/Header"
import Footer from "@/components/Footer"
import { Breadcrumbs } from "@/components/Breadcrumbs"

export const metadata = {
  title: "Private Equity — Investment, Strategy & Operations | Vestval",
  description: "Value creation across the deal lifecycle with focused operating playbooks.",
}

export default function PrivateEquity() {
  return (
    <main>
      <Header />
      <section className="pt-8">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <Breadcrumbs />
          <h1 className="text-3xl md:text-4xl font-bold mt-6 mb-4">Private Equity</h1>
          <p className="text-gray-600">Investment theses, carve-outs, integrations, and performance improvement.</p>
        </div>
      </section>
      <Footer />
    </main>
  )
}
