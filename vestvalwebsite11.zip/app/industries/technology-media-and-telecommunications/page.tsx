import Header from "@/components/Header"
import Footer from "@/components/Footer"
import { Breadcrumbs } from "@/components/Breadcrumbs"

export const metadata = {
  title: "Technology, Media & Telecommunications — Insights | Vestval",
  description: "Platform growth, monetization, and scalable operations.",
}

export default function TMT() {
  return (
    <main>
      <Header />
      <section className="pt-8">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <Breadcrumbs />
          <h1 className="text-3xl md:text-4xl font-bold mt-6 mb-4">Technology, Media & Telecommunications</h1>
          <p className="text-gray-600">Data-driven product and operating models for durable growth.</p>
        </div>
      </section>
      <Footer />
    </main>
  )
}
