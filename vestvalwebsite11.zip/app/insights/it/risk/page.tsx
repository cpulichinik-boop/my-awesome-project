import Header from "@/components/Header"
import Footer from "@/components/Footer"
import { Breadcrumbs } from "@/components/Breadcrumbs"
import Link from "next/link"

export const metadata = {
  title: "Risk Services, Compliance & Trends | Vestval",
  description: "Risk management for modern digital businesses.",
}

export default function RiskInsights() {
  return (
    <main>
      <Header />
      <section className="pt-8">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <Breadcrumbs />
          <div className="mt-6 rounded-md overflow-hidden">
            <img
              src="/risk-and-compliance-hero.jpg"
              alt="Risk and compliance hero image"
              className="w-full h-auto object-cover"
            />
          </div>
          <h1 className="text-3xl md:text-4xl font-bold mt-6 mb-4">Risk Services & Compliance</h1>
          <nav aria-label="On this page" className="text-sm text-gray-600">
            <ul className="flex flex-wrap gap-3">
              <li>
                <a href="#operating-model" className="hover:underline">
                  Operating Model
                </a>
              </li>
              <li>
                <a href="#key-controls" className="hover:underline">
                  Key Controls
                </a>
              </li>
              <li>
                <a href="#assurance" className="hover:underline">
                  Assurance
                </a>
              </li>
            </ul>
          </nav>
        </div>
      </section>

      <article className="py-10">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-4xl space-y-10">
          <section id="operating-model" className="space-y-3 animate-fade-in-up">
            <h2 className="text-2xl md:text-3xl font-semibold">Operating Model for AI Risk</h2>
            <p className="text-gray-700">A pragmatic 3-layer model: policy, platform, practice.</p>
            <ul className="list-disc pl-6 text-gray-700 leading-relaxed">
              <li>
                <strong>Policy:</strong> Use policies as code for prompts, data access, and model selection.
              </li>
              <li>
                <strong>Platform:</strong> Centralized logging, redaction, and classifiers across all AI apps.
              </li>
              <li>
                <strong>Practice:</strong> Product teams own risks with playbooks and automated checks.
              </li>
            </ul>
          </section>

          <section id="key-controls" className="space-y-3 animate-fade-in-up" style={{ animationDelay: "150ms" }}>
            <h2 className="text-2xl md:text-3xl font-semibold">Key Controls</h2>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="p-5 rounded-lg border bg-white hover-lift">
                <h3 className="font-semibold mb-2">Data & Privacy</h3>
                <ul className="list-disc pl-5 text-gray-700 text-sm space-y-1">
                  <li>PII minimization and masked contexts.</li>
                  <li>Tenant isolation and access logging.</li>
                  <li>Retention + deletion workflows.</li>
                </ul>
              </div>
              <div className="p-5 rounded-lg border bg-white hover-lift">
                <h3 className="font-semibold mb-2">Model & Prompt Security</h3>
                <ul className="list-disc pl-5 text-gray-700 text-sm space-y-1">
                  <li>Prompt injection defenses and allow-lists.</li>
                  <li>Toxicity and policy checks pre/post-gen.</li>
                  <li>Fail-safe timeouts and circuit breakers.</li>
                </ul>
              </div>
            </div>
          </section>

          <section id="assurance" className="space-y-3 animate-fade-in-up" style={{ animationDelay: "300ms" }}>
            <h2 className="text-2xl md:text-3xl font-semibold">Assurance & Auditability</h2>
            <p className="text-gray-700">
              End-to-end logs enable explainability and regulator-ready reporting. Pair evaluation datasets with drift
              dashboards and periodic control testing.
            </p>
            <p className="text-gray-700">
              Explore{" "}
              <Link className="text-blue-600 hover:underline" href="/insights/it/ai">
                AI Insights
              </Link>{" "}
              for architecture patterns and guardrails.
            </p>
          </section>

          <aside aria-label="Related links" className="pt-4 border-t">
            <h3 className="font-semibold mb-2">Related</h3>
            <ul className="list-disc pl-6 text-gray-700">
              <li>
                <Link className="text-blue-600 hover:underline" href="/insights/it/ai">
                  AI Insights
                </Link>
              </li>
              <li>
                <Link className="text-blue-600 hover:underline" href="/industries/financial-services">
                  Financial Services
                </Link>
              </li>
            </ul>
          </aside>
        </div>
      </article>
      <Footer />
    </main>
  )
}
