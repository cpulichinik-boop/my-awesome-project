import Header from "@/components/Header"
import Footer from "@/components/Footer"
import { Breadcrumbs } from "@/components/Breadcrumbs"
import Link from "next/link"

export const metadata = {
  title: "Sustainability & ESG Trends | Vestval",
  description: "Sustainability strategy, reporting, and value creation.",
}

export default function SustainabilityInsights() {
  return (
    <main>
      <Header />
      <section className="pt-8">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <Breadcrumbs />
          <div className="mt-6 rounded-md overflow-hidden">
            <img
              src="/sustainability-esg-hero.jpg"
              alt="Sustainability and ESG hero image"
              className="w-full h-auto object-cover"
            />
          </div>
          <h1 className="text-3xl md:text-4xl font-bold mt-6 mb-4">Sustainability & ESG</h1>
          <nav aria-label="On this page" className="text-sm text-gray-600">
            <ul className="flex flex-wrap gap-3">
              <li>
                <a href="#materiality" className="hover:underline">
                  Materiality
                </a>
              </li>
              <li>
                <a href="#growth" className="hover:underline">
                  ESG & Growth
                </a>
              </li>
              <li>
                <a href="#contact" className="hover:underline">
                  Talk to an ESG Advisor
                </a>
              </li>
            </ul>
          </nav>
        </div>
      </section>

      <article className="py-10">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-4xl space-y-10">
          <section id="materiality" className="space-y-3 animate-fade-in-up">
            <h2 className="text-2xl md:text-3xl font-semibold">Materiality to Execution</h2>
            <p className="text-gray-700">Focus on the few material topics that move valuation and resilience.</p>
            <ul className="list-disc pl-6 text-gray-700 leading-relaxed">
              <li>Data foundations for emissions and resource use.</li>
              <li>Supplier engagement and scope expansion plan.</li>
              <li>Disclosure aligned with evolving standards.</li>
            </ul>
          </section>

          <section id="growth" className="space-y-3 animate-fade-in-up" style={{ animationDelay: "150ms" }}>
            <h2 className="text-2xl md:text-3xl font-semibold">ESG and Growth</h2>
            <p className="text-gray-700">
              ESG investments that unlock margin and revenue: efficiency, product differentiation, and risk premium
              reduction.
            </p>
          </section>

          <section id="contact" className="space-y-4 animate-fade-in-up" style={{ animationDelay: "300ms" }}>
            <h2 className="text-2xl md:text-3xl font-semibold">Talk to an ESG Advisor</h2>
            <Link
              href="/contact"
              className="inline-flex items-center px-6 py-3 rounded-md gradient-bg text-white font-semibold hover:opacity-90 transition-opacity"
            >
              Contact Us
            </Link>
          </section>

          <aside aria-label="Related links" className="pt-4 border-t">
            <h3 className="font-semibold mb-2">Related</h3>
            <ul className="list-disc pl-6 text-gray-700">
              <li>
                <Link className="text-blue-600 hover:underline" href="/industries/energy-and-resources">
                  Energy & Resources
                </Link>
              </li>
              <li>
                <Link className="text-blue-600 hover:underline" href="/services/management-consulting">
                  Management Consulting
                </Link>
              </li>
            </ul>
          </aside>
        </div>
      </article>
      <Footer />
    </main>
  )
}
