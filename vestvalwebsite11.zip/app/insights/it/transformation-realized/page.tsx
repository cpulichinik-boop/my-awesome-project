import Header from "@/components/Header"
import Footer from "@/components/Footer"
import { Breadcrumbs } from "@/components/Breadcrumbs"

export const metadata = {
  title: "Transformation Realized — CEO/CFO-led Business Transformation | Vestval",
  description: "Long-form editorial linking to enabling services.",
}

export default function TransformationRealized() {
  return (
    <main>
      <Header />
      <section className="pt-8">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <Breadcrumbs />
          <div className="mt-6 rounded-md overflow-hidden">
            <img
              src="/transformation-series-hero.jpg"
              alt="Transformation Realized hero image"
              className="w-full h-auto object-cover"
            />
          </div>
          <h1 className="text-3xl md:text-4xl font-bold mt-6 mb-4">Transformation Realized Series</h1>
          <nav aria-label="On this page" className="text-sm text-gray-600">
            <ul className="flex flex-wrap gap-3">
              <li>
                <a href="#editorial" className="hover:underline">
                  Editorial
                </a>
              </li>
              <li>
                <a href="#enablers" className="hover:underline">
                  Enabling Services
                </a>
              </li>
            </ul>
          </nav>
          <p className="text-gray-600">CEO/CFO-led transformations with disciplined execution and measurable impact.</p>
        </div>
      </section>
      <Footer />
    </main>
  )
}
