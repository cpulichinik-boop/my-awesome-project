import Header from "@/components/Header"
import Footer from "@/components/Footer"
import { Breadcrumbs } from "@/components/Breadcrumbs"
import Link from "next/link"

export const metadata = {
  title: "People & Workforce — Services and Insights | Vestval",
  description: "Capability building, ways of working, and workforce tech.",
}

export default function WorkforceInsights() {
  return (
    <main>
      <Header />
      <section className="pt-8">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <Breadcrumbs />
          <div className="mt-6 rounded-md overflow-hidden">
            <img
              src="/workforce-enablement-hero.jpg"
              alt="People and Workforce hero image"
              className="w-full h-auto object-cover"
            />
          </div>
          <h1 className="text-3xl md:text-4xl font-bold mt-6 mb-4">People & Workforce</h1>
          <nav aria-label="On this page" className="text-sm text-gray-600">
            <ul className="flex flex-wrap gap-3">
              <li>
                <a href="#skills" className="hover:underline">
                  Skills & Adoption
                </a>
              </li>
              <li>
                <a href="#platforms" className="hover:underline">
                  Workforce Platforms
                </a>
              </li>
              <li>
                <a href="#speak" className="hover:underline">
                  Speak to an Expert
                </a>
              </li>
            </ul>
          </nav>
        </div>
      </section>

      <article className="py-10">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-4xl space-y-10">
          <section id="skills" className="space-y-3 animate-fade-in-up">
            <h2 className="text-2xl md:text-3xl font-semibold">Skills and Adoption</h2>
            <ul className="list-disc pl-6 text-gray-700 leading-relaxed">
              <li>Role-based enablement plans aligned to KPIs.</li>
              <li>Lightweight playbooks and in-product guidance.</li>
              <li>Communities of practice with weekly forums.</li>
            </ul>
          </section>

          <section id="platforms" className="space-y-3 animate-fade-in-up" style={{ animationDelay: "150ms" }}>
            <h2 className="text-2xl md:text-3xl font-semibold">Workforce Platforms</h2>
            <p className="text-gray-700">
              Consolidate overlapping tools, standardize workflows, and embed data + AI to remove friction.
            </p>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="p-5 rounded-lg border bg-white hover-lift">
                <h3 className="font-semibold mb-2">Collaboration</h3>
                <p className="text-sm text-gray-700">Templates, automations, and copilots in everyday work.</p>
              </div>
              <div className="p-5 rounded-lg border bg-white hover-lift">
                <h3 className="font-semibold mb-2">Performance</h3>
                <p className="text-sm text-gray-700">Telemetry on cycle times, quality, and satisfaction.</p>
              </div>
            </div>
          </section>

          <section id="speak" className="space-y-4 animate-fade-in-up" style={{ animationDelay: "300ms" }}>
            <h2 className="text-2xl md:text-3xl font-semibold">Speak to an Expert</h2>
            <Link
              href="/contact"
              className="inline-flex items-center px-6 py-3 rounded-md gradient-bg text-white font-semibold hover:opacity-90 transition-opacity"
            >
              Contact Us
            </Link>
          </section>

          <aside aria-label="Related links" className="pt-4 border-t">
            <h3 className="font-semibold mb-2">Related</h3>
            <ul className="list-disc pl-6 text-gray-700">
              <li>
                <Link className="text-blue-600 hover:underline" href="/services/management-consulting">
                  Management Consulting
                </Link>
              </li>
              <li>
                <Link className="text-blue-600 hover:underline" href="/insights/it/ai">
                  AI Insights
                </Link>
              </li>
            </ul>
          </aside>
        </div>
      </article>
      <Footer />
    </main>
  )
}
