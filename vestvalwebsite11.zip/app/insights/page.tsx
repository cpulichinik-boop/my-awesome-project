import Header from "@/components/Header"
import Footer from "@/components/Footer"
import { Breadcrumbs } from "@/components/Breadcrumbs"
import Link from "next/link"

export const metadata = {
  title: "Insights — Articles & Trends | Vestval",
  description: "Deep articles and trend analysis across AI, risk, workforce, and sustainability.",
}

const items = [
  {
    href: "/insights/it/ai",
    title: "Latest AI Insights: GenAI, agents, and trends",
    img: "/ai-insights.jpg",
    alt: "Hero thumbnail for AI insights",
  },
  {
    href: "/insights/it/workforce",
    title: "People & Workforce: Services and insights",
    img: "/workforce-insights.jpg",
    alt: "Hero thumbnail for workforce insights",
  },
  {
    href: "/insights/it/risk",
    title: "Risk Services: Compliance and trends",
    img: "/risk-compliance-insights.jpg",
    alt: "Hero thumbnail for risk and compliance insights",
  },
  {
    href: "/insights/it/sustainability",
    title: "Sustainability & ESG: Latest trends",
    img: "/sustainability-esg.jpg",
    alt: "Hero thumbnail for sustainability insights",
  },
  {
    href: "/insights/it/transformation-realized",
    title: "Transformation Realized series: CEO/CFO-led",
    img: "/transformation-series.jpg",
    alt: "Hero thumbnail for transformation realized series",
  },
]

export default function InsightsHub() {
  return (
    <main>
      <Header />
      <section className="pt-8">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <Breadcrumbs items={[{ name: "Insights" }]} />
          <h1 className="text-3xl md:text-4xl font-bold mt-6 mb-4">Insights</h1>
          <ul className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {items.map((i) => (
              <li
                key={i.href}
                className="group rounded-lg border bg-white overflow-hidden hover:shadow-sm transition-shadow"
              >
                <Link className="block" href={i.href}>
                  <img src={i.img || "/placeholder.svg"} alt={i.alt} className="w-full h-[180px] object-cover" />
                  <div className="p-4">
                    <h3 className="font-semibold text-gray-900 group-hover:underline">{i.title}</h3>
                  </div>
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </section>
      <Footer />
    </main>
  )
}
