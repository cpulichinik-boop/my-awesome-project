import Header from "@/components/Header"
import Footer from "@/components/Footer"
import { Breadcrumbs } from "@/components/Breadcrumbs"
import Link from "next/link"

export const metadata = {
  title: "Technology Consulting Services & Solutions | Vestval",
  description: "Offerings, methods, and outcomes for IT & Digital Transformation.",
}

export default function ITServices() {
  return (
    <main>
      <Header />
      <section className="pt-8">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <Breadcrumbs items={[{ name: "IT" }]} />
          <h1 className="text-3xl md:text-4xl font-bold mt-6 mb-4">Technology Consulting Services & Solutions</h1>
          <p className="text-gray-600 mb-6">
            Detailed offerings in cloud, data, AI, cybersecurity, and modernization to deliver measurable outcomes.
          </p>
          <p className="text-gray-600">
            See our latest <Link href="/insights">IT/Insights</Link> and related{" "}
            <Link href="/case-studies">Case Studies</Link>.
          </p>
        </div>
      </section>
      <Footer />
    </main>
  )
}
