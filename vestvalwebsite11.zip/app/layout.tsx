import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import { Suspense } from "react"
import "./globals.css"

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap", // Added font-display swap for better performance
})

export const metadata: Metadata = {
  title: {
    default: "Vestval - Global Advisory Excellence | Strategic Consulting & Financial Services",
    template: "%s | Vestval - Global Advisory Excellence",
  },
  description:
    "Transform your business with Vestval's world-class consulting in IT transformation, financial advisory, and strategic management. Trusted by 500+ global enterprises with $1B+ value created.",
  generator: "Vestval Group",
  keywords: [
    "strategic consulting",
    "IT transformation",
    "digital transformation",
    "financial advisory",
    "CFO services",
    "management consulting",
    "business growth",
    "M&A advisory",
    "capital raising",
    "global consulting firm",
    "enterprise solutions",
    "technology consulting",
    "business strategy",
    "operational excellence",
  ].join(", "),
  authors: [{ name: "Vestval Group", url: "https://vestval.com" }],
  creator: "Vestval Group",
  publisher: "Vestval Group",
  openGraph: {
    title: "Vestval - Global Advisory Excellence | Strategic Consulting & Financial Services",
    description:
      "Transform your business with world-class consulting. Trusted by 500+ enterprises with $1B+ value created.",
    type: "website",
    locale: "en_US",
    url: "https://vestval.com",
    siteName: "Vestval",
    images: [
      {
        url: "/og-image.jpg",
        width: 1200,
        height: 630,
        alt: "Vestval - Global Advisory Excellence",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Vestval - Global Advisory Excellence",
    description: "Transform your business with world-class consulting. Trusted by 500+ enterprises.",
    images: ["/og-image.jpg"],
    creator: "@vestval",
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  alternates: {
    canonical: "https://vestval.com",
  },
  verification: {
    google: "your-google-verification-code",
    yandex: "your-yandex-verification-code",
    yahoo: "your-yahoo-verification-code",
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={inter.variable}>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link rel="icon" href="/favicon.ico" sizes="any" />
        <link rel="icon" href="/icon.svg" type="image/svg+xml" />
        <link rel="apple-touch-icon" href="/apple-touch-icon.png" />
        <link rel="manifest" href="/manifest.json" />
        <meta name="theme-color" content="#1765ff" />
        <meta name="msapplication-TileColor" content="#1765ff" />
      </head>
      <body className={`font-sans antialiased`}>
        <Suspense fallback={null}>{children}</Suspense>
      </body>
    </html>
  )
}
