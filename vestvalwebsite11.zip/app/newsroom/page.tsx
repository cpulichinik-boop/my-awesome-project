import Header from "@/components/Header"
import Footer from "@/components/Footer"
import { Breadcrumbs } from "@/components/Breadcrumbs"
import Link from "next/link"

export const metadata = {
  title: "Newsroom - Vestval | News & Press",
  description: "Latest news, press releases, and company updates from Vestval.",
}

export default function NewsroomPage() {
  const posts = [
    {
      slug: "q3-outlook",
      title: "Q3 Outlook: Transforming Through Efficiency",
      excerpt: "Market signals and transformation themes shaping the quarter.",
    },
    {
      slug: "ai-ops",
      title: "AI Ops in Mid-Market",
      excerpt: "Practical AI operating models creating measurable value.",
    },
    {
      slug: "cfo-playbook",
      title: "CFO Value Creation Playbook",
      excerpt: "Improving cash, resilience, and growth with disciplined execution.",
    },
    {
      slug: "genai-brief",
      title: "GenAI Brief: Agents at Work",
      excerpt: "Where agentic workflows deliver ROI today.",
    },
    {
      slug: "esg-2025",
      title: "ESG 2025: From Reporting to Results",
      excerpt: "Turning sustainability mandates into performance gains.",
    },
    {
      slug: "risk-modernization",
      title: "Risk Modernization in BFSI",
      excerpt: "Compliance-by-design and continuous controls.",
    },
    {
      slug: "india-market-entry",
      title: "India Market Entry Guide",
      excerpt: "Regulatory, go-to-market, and hiring playbooks.",
    },
    {
      slug: "mna-integration",
      title: "M&A Integration: 100-Day Plan",
      excerpt: "Synergy capture and cultural alignment essentials.",
    },
    {
      slug: "capital-raising",
      title: "Capital Raising in Tight Markets",
      excerpt: "Structuring flexibility while protecting dilution.",
    },
    { slug: "cloud-costs", title: "Taming Cloud Costs", excerpt: "FinOps tactics for sustainable efficiency." },
    { slug: "cyber-defense", title: "Building Defense-in-Depth", excerpt: "Zero trust and resilience architectures." },
    { slug: "workforce-ai", title: "Workforce + AI: Upskill Now", excerpt: "Pragmatic reskilling paths for managers." },
    { slug: "smb-digital", title: "SMB Digital Core", excerpt: "From spreadsheets to systems in 90 days." },
    { slug: "supply-chain", title: "Resilient Supply Chains", excerpt: "Visibility, buffers, and nearshoring." },
    { slug: "datacenter-trends", title: "Data Center Trends 2025", excerpt: "Power, cooling, and edge buildouts." },
    { slug: "payments-rails", title: "Payments Rails Modernization", excerpt: "Real-time rails and interoperability." },
    {
      slug: "nbfc-insights",
      title: "NBFC Collaboration Models",
      excerpt: "How advisors partner with licensed lenders.",
    },
    { slug: "private-equity", title: "PE Portfolio Value Creation", excerpt: "Ops playbooks from diligence to exit." },
    { slug: "genai-risk", title: "GenAI Risk Management", excerpt: "Policy, controls, and monitoring." },
    {
      slug: "customer-experience",
      title: "Customer Experience by Design",
      excerpt: "Service blueprints and measurable NPS gains.",
    },
  ]

  return (
    <main>
      <Header />
      <section className="pt-8">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <Breadcrumbs items={[{ name: "Newsroom" }]} />
          <h1 className="text-3xl md:text-4xl font-bold mt-6 mb-4">Newsroom</h1>
          <p className="text-gray-600 mb-10">Company news, press releases, and thought leadership.</p>
          <div className="grid md:grid-cols-3 gap-6">
            {posts.map((p) => (
              <article key={p.slug} className="border rounded-lg p-6 hover:shadow-lg transition-shadow">
                <h2 className="text-xl font-semibold mb-2">
                  <Link href={`/newsroom/${p.slug}`}>{p.title}</Link>
                </h2>
                <p className="text-gray-600">{p.excerpt}</p>
                <div className="mt-4">
                  <Link className="text-blue-600 hover:underline" href={`/newsroom/${p.slug}`}>
                    Read more
                  </Link>
                </div>
              </article>
            ))}
          </div>
          <div className="mt-10 text-sm text-gray-500">JSON-LD Article schema to be added per post. {/* TODO */}</div>
        </div>
      </section>
      <Footer />
    </main>
  )
}
