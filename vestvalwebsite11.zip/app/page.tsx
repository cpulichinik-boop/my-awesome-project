import Header from "@/components/Header"
import Hero from "@/components/Hero"
import ValueProposition from "@/components/ValueProposition"
import About from "@/components/About"
import Services from "@/components/Services"
import InteractiveServiceSelector from "@/components/InteractiveServiceSelector"
import InteractiveStats from "@/components/InteractiveStats"
import ServiceComparison from "@/components/ServiceComparison"
import CaseStudies from "@/components/CaseStudies"
import TestimonialsCarousel from "@/components/TestimonialsCarousel"
import InteractiveTimeline from "@/components/InteractiveTimeline"
import TrustIndicators from "@/components/TrustIndicators"
import Blog from "@/components/Blog"
import InteractiveFAQ from "@/components/InteractiveFAQ"
import NewsletterSignup from "@/components/NewsletterSignup"
import GlobalNetwork from "@/components/GlobalNetwork"
import Contact from "@/components/Contact"
import Footer from "@/components/Footer"
import ScrollToTop from "@/components/ScrollToTop"
import Script from "next/script"

export default function Home() {
  return (
    <main className="min-h-screen">
      <Script id="ld-org" type="application/ld+json" strategy="afterInteractive">
        {JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Organization",
          name: "Vestval",
          alternateName: "Vestval Group",
          url: "https://vestval.com",
          logo: "https://vestval.com/vestval-logo.jpg",
          description:
            "Global advisory firm specializing in strategic consulting, IT transformation, and financial services.",
          foundingDate: "2010",
          address: {
            "@type": "PostalAddress",
            addressCountry: "Global",
          },
          contactPoint: {
            "@type": "ContactPoint",
            telephone: "+1-800-VESTVAL",
            contactType: "customer service",
            email: "contact@vestval.com",
          },
          sameAs: ["https://linkedin.com/company/vestval", "https://twitter.com/vestval"],
          areaServed: "Worldwide",
          serviceType: ["Strategic Consulting", "IT Transformation", "Financial Advisory", "Management Consulting"],
        })}
      </Script>

      <Script id="ld-business" type="application/ld+json" strategy="afterInteractive">
        {JSON.stringify({
          "@context": "https://schema.org",
          "@type": "ProfessionalService",
          name: "Vestval",
          image: "https://vestval.com/vestval-logo.jpg",
          "@id": "https://vestval.com",
          url: "https://vestval.com",
          telephone: "+1-800-VESTVAL",
          address: {
            "@type": "PostalAddress",
            addressCountry: "Global",
          },
          geo: {
            "@type": "GeoCoordinates",
            latitude: 40.7128,
            longitude: -74.006,
          },
          openingHoursSpecification: {
            "@type": "OpeningHoursSpecification",
            dayOfWeek: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
            opens: "09:00",
            closes: "18:00",
          },
          sameAs: ["https://linkedin.com/company/vestval", "https://twitter.com/vestval"],
        })}
      </Script>

      <Script id="ld-website" type="application/ld+json" strategy="afterInteractive">
        {JSON.stringify({
          "@context": "https://schema.org",
          "@type": "WebSite",
          name: "Vestval",
          url: "https://vestval.com",
          potentialAction: {
            "@type": "SearchAction",
            target: "https://vestval.com/search?q={query}",
            "query-input": "required name=query",
          },
        })}
      </Script>

      <Script id="ld-breadcrumb" type="application/ld+json" strategy="afterInteractive">
        {JSON.stringify({
          "@context": "https://schema.org",
          "@type": "BreadcrumbList",
          itemListElement: [
            {
              "@type": "ListItem",
              position: 1,
              name: "Home",
              item: "https://vestval.com",
            },
          ],
        })}
      </Script>

      <Header />
      <Hero />
      <ValueProposition />
      <About />
      <Services />
      <InteractiveServiceSelector />
      <InteractiveStats />
      <ServiceComparison />
      <CaseStudies />
      <TestimonialsCarousel />
      <InteractiveTimeline />
      <TrustIndicators />
      <Blog />
      <InteractiveFAQ />
      <NewsletterSignup />
      <GlobalNetwork />
      <Contact />
      <Footer />
      <ScrollToTop />
    </main>
  )
}
