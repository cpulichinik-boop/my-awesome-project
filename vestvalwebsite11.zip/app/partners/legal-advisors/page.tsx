import Link from "next/link"

export default function LegalAdvisorsPartnersPage() {
  return (
    <main className="mx-auto max-w-3xl px-4 py-10">
      <header className="mb-8">
        <h1 className="text-3xl font-semibold text-balance">Legal Advisors</h1>
        <p className="mt-2 text-muted-foreground">
          Collaboration with legal teams to translate regulatory requirements into pragmatic delivery.
        </p>
      </header>

      <section className="prose prose-neutral dark:prose-invert max-w-none">
        <h2 id="how-we-partner" className="scroll-mt-24">
          How we partner
        </h2>
        <p>
          We bring a shared understanding of regulatory frameworks and convert them into actionable controls,
          documentation, and change management.
        </p>

        <h2 id="representative-examples" className="scroll-mt-24">
          Representative examples
        </h2>
        <ul>
          <li>Data retention and cross-border controls embedded in platform strategy.</li>
          <li>Impact assessments and DPIAs aligned to program increments.</li>
          <li>Human-in-the-loop review for AI use-cases with auditable outcomes.</li>
        </ul>

        <h2 id="where-we-apply" className="scroll-mt-24">
          Where this applies
        </h2>
        <p>
          See relevant{" "}
          <Link href="/services" className="text-primary hover:underline">
            Services
          </Link>{" "}
          and{" "}
          <Link href="/industries" className="text-primary hover:underline">
            Industries
          </Link>
          .
        </p>
      </section>

      <section className="mt-8">
        <Link href="/get-started" className="inline-flex items-center gap-2 rounded-md bg-primary px-4 py-2 text-white">
          Get started
        </Link>
      </section>
    </main>
  )
}
