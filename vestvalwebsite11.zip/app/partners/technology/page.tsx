import Link from "next/link"

export default function TechnologyPartnersPage() {
  return (
    <main className="mx-auto max-w-3xl px-4 py-10">
      <header className="mb-8">
        <h1 className="text-3xl font-semibold text-balance">Technology Partners</h1>
        <p className="mt-2 text-muted-foreground">
          Strategic collaborations with cloud, data, and AI platforms to accelerate outcomes with proven architectures.
        </p>
      </header>

      <section className="prose prose-neutral dark:prose-invert max-w-none">
        <h2 id="how-we-partner" className="scroll-mt-24">
          How we partner
        </h2>
        <p>
          We co-design reference architectures, enable teams, and de-risk delivery by aligning platform capabilities
          with your priorities and constraints. Our approach emphasizes security, scalability, and total cost of
          ownership.
        </p>

        <h2 id="representative-examples" className="scroll-mt-24">
          Representative examples
        </h2>
        <ul>
          <li>Modern data stack on cloud warehouse with governed self-serve analytics.</li>
          <li>Event-driven integration patterns with observability and SLOs.</li>
          <li>AI-assisted workflows with human-in-the-loop review and guardrails.</li>
        </ul>

        <h2 id="where-we-apply" className="scroll-mt-24">
          Where this applies
        </h2>
        <p>
          See related services in{" "}
          <Link href="/services" className="text-primary hover:underline">
            Services
          </Link>{" "}
          and industry context in{" "}
          <Link href="/industries" className="text-primary hover:underline">
            Industries
          </Link>
          .
        </p>
      </section>

      <section className="mt-8">
        <Link href="/get-started" className="inline-flex items-center gap-2 rounded-md bg-primary px-4 py-2 text-white">
          Get started
        </Link>
      </section>
    </main>
  )
}
