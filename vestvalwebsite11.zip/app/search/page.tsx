"use client"

import { useMemo, useState } from "react"
import Header from "@/components/Header"
import Footer from "@/components/Footer"
import Link from "next/link"

type Item = { title: string; href: string; tags?: string[] }

const INDEX: Item[] = [
  // Services
  {
    title: "IT & Digital Transformation",
    href: "/services/it-digital-transformation",
    tags: ["it", "digital", "cloud", "security"],
  },
  {
    title: "Finance & Capital Advisory",
    href: "/services/finance-capital-advisory",
    tags: ["finance", "cfo", "capital"],
  },
  {
    title: "Management Consulting",
    href: "/services/management-consulting",
    tags: ["strategy", "operations", "governance"],
  },
  // Industries (sample)
  { title: "Consumer & Retail", href: "/industries/consumer-products-and-retail", tags: ["consumer", "retail"] },
  { title: "Energy & Resources", href: "/industries/energy-and-resources", tags: ["energy", "resources"] },
  { title: "Financial Services", href: "/industries/financial-services", tags: ["banking", "insurance"] },
  {
    title: "Government & Public Sector",
    href: "/industries/government-and-public-sector",
    tags: ["government", "public"],
  },
  { title: "Healthcare", href: "/industries/healthcare", tags: ["healthcare"] },
  { title: "Private Equity", href: "/industries/private-equity", tags: ["pe", "private equity"] },
  {
    title: "Technology, Media & Telecom",
    href: "/industries/technology-media-and-telecommunications",
    tags: ["tmt", "technology"],
  },
  // Case Studies
  { title: "Case Studies", href: "/case-studies", tags: ["results", "outcomes", "proof"] },
  // Leasing
  { title: "Leasing Advisory Overview", href: "/services/leasing", tags: ["leasing", "advisory"] },
  {
    title: "Leasing Eligibility & Documentation",
    href: "/services/leasing/eligibility",
    tags: ["leasing", "eligibility"],
  },
  // Careers
  { title: "Careers at Vestval", href: "/careers/about", tags: ["careers", "jobs"] },
  { title: "How to Join Us", href: "/careers/how-to-join", tags: ["careers", "apply"] },
  { title: "Job Search", href: "/careers/jobs", tags: ["careers", "jobs", "open roles"] },
  // About
  { title: "About Vestval", href: "/about", tags: ["about", "company"] },
  { title: "Our Values", href: "/about/values", tags: ["values"] },
  { title: "Our Purpose", href: "/about/purpose", tags: ["purpose"] },
  { title: "Our People", href: "/about/people", tags: ["people"] },
  // Insights/Newsroom hubs
  { title: "Insights", href: "/insights", tags: ["insights", "articles"] },
  { title: "Newsroom", href: "/newsroom", tags: ["newsroom", "press"] },
  // Contact
  { title: "Contact", href: "/contact", tags: ["contact", "email", "phone"] },
]

export default function SearchPage() {
  const [q, setQ] = useState("")
  const results = useMemo(() => {
    const query = q.trim().toLowerCase()
    if (!query) return INDEX
    return INDEX.filter((item) => {
      return (
        item.title.toLowerCase().includes(query) ||
        item.href.toLowerCase().includes(query) ||
        (item.tags ?? []).some((t) => t.includes(query))
      )
    })
  }, [q])

  return (
    <main className="min-h-screen">
      <Header />
      <section className="pt-24 pb-12 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Search</h1>
          <p className="text-gray-600 mb-6">Find services, industries, insights, careers, and more.</p>
          <div className="mb-8">
            <input
              type="search"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search by keyword (e.g., CFO, cloud, risk, careers)"
              className="w-full md:w-2/3 rounded-md border border-gray-300 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
              aria-label="Search site"
            />
          </div>

          <ul className="space-y-3">
            {results.map((item) => (
              <li
                key={item.href}
                className="border border-gray-200 rounded-md p-4 hover:border-blue-300 hover:bg-blue-50 transition-colors"
              >
                <Link href={item.href} className="text-blue-700 hover:text-blue-800 font-medium underline">
                  {item.title}
                </Link>
                {item.tags && <div className="mt-1 text-xs text-gray-500">Tags: {item.tags.join(", ")}</div>}
              </li>
            ))}
          </ul>
        </div>
      </section>
      <Footer />
    </main>
  )
}
