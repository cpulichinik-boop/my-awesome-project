import Header from "@/components/Header"
import Footer from "@/components/Footer"
import Link from "next/link"

export const metadata = {
  title: "Finance & Capital Advisory | Vestval",
  description:
    "CFO services, debt structuring, capital raising, and financial planning designed to boost valuation and growth.",
}

export default function FinanceCapitalAdvisory() {
  return (
    <main className="min-h-screen">
      <Header />
      <section className="pt-16 pb-10 bg-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-4xl">
          <h1 className="text-3xl md:text-5xl font-bold text-gray-900 mb-4">Finance & Capital Advisory</h1>
          <p className="text-gray-600 text-lg mb-8">
            From capital structure to investor readiness, our CFO-led team aligns financial strategy with operating
            reality—optimizing cash, resilience, and growth.
          </p>
          <ul className="list-disc pl-6 space-y-2 text-gray-700">
            <li>Debt Structuring & Capital Raising across scenarios</li>
            <li>Strategic Financial Planning, reporting excellence</li>
            <li>Investor relations and board-ready narratives</li>
            <li>Global networks across banks, NBFCs, and private capital</li>
          </ul>
          <div className="mt-8 flex gap-4">
            <Link className="px-6 py-3 rounded-lg bg-blue-600 text-white" href="/contact">
              Contact Us
            </Link>
            <Link className="px-6 py-3 rounded-lg border border-gray-300" href="/partners/financial-institutions">
              Financial Institution Partners
            </Link>
          </div>
        </div>
      </section>
      <Footer />
    </main>
  )
}
