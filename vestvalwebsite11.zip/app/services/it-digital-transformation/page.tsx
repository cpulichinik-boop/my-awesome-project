import Header from "@/components/Header"
import Footer from "@/components/Footer"
import Link from "next/link"

export const metadata = {
  title: "IT & Digital Transformation | Vestval",
  description:
    "Cloud, AI, cybersecurity, and modern engineering to streamline operations, enhance CX, and innovate at scale.",
}

export default function ITDigitalTransformation() {
  return (
    <main className="min-h-screen">
      <Header />
      <section className="pt-16 pb-10 bg-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-4xl">
          <h1 className="text-3xl md:text-5xl font-bold text-gray-900 mb-4">IT & Digital Transformation</h1>
          <p className="text-gray-600 text-lg mb-8">
            We deliver measurable outcomes with cloud modernization, data & AI, cybersecurity, and product engineering—
            governed by proven delivery and FinOps discipline.
          </p>
          <ul className="list-disc pl-6 space-y-2 text-gray-700">
            <li>Mobile & Web App Development with UX/CX excellence</li>
            <li>Cloud Infrastructure & Platform Engineering (secure, scalable, compliant)</li>
            <li>AI, Agents & Automation for core workflows and decisioning</li>
            <li>Quality Assurance, Security Testing, and DevSecOps</li>
          </ul>
          <div className="mt-8 flex gap-4">
            <Link className="px-6 py-3 rounded-lg bg-blue-600 text-white" href="/contact">
              Contact Us
            </Link>
            <Link className="px-6 py-3 rounded-lg border border-gray-300" href="/partners/technology">
              View Technology Partners
            </Link>
          </div>
        </div>
      </section>
      <Footer />
    </main>
  )
}
