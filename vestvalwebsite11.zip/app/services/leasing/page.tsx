import Header from "@/components/Header"
import Footer from "@/components/Footer"
import { Breadcrumbs } from "@/components/Breadcrumbs"
import Link from "next/link"

export const metadata = {
  title: "Leasing Advisory — Overview & Value Proposition | Vestval",
  description: "Advisory-only, vendor-agnostic, multi-funder leasing strategy.",
}

const links = [
  { href: "/services/leasing/eligibility", label: "Eligibility & Documents" },
  { href: "/services/leasing/process", label: "How It Works" },
  { href: "/services/leasing/structures", label: "Lease Structures & Pricing" },
  { href: "/services/leasing/vendor-strategy", label: "Vendor Strategy & Lifecycle" },
  { href: "/services/leasing/equipment-categories", label: "Equipment Categories & Use Cases" },
  { href: "/services/leasing/end-of-term", label: "End-of-Term & ESG Partners" },
  { href: "/services/leasing/faqs", label: "FAQs for Procurement/Finance" },
]

export default function LeasingOverview() {
  return (
    <main>
      <Header />
      <section className="pt-8">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <Breadcrumbs items={[{ name: "Services", href: "/services" }, { name: "Leasing" }]} />
          <h1 className="text-3xl md:text-4xl font-bold mt-6 mb-4">Leasing Advisory — Overview</h1>
          <p className="text-gray-600 mb-6">
            Advisory-only, vendor-agnostic guidance to optimize asset-light growth.{" "}
            {/* TODO: Ingest provided text.txt for full content */}
          </p>
          <ul className="list-disc pl-6 space-y-2">
            {links.map((l) => (
              <li key={l.href}>
                <Link className="text-blue-600 hover:underline" href={l.href}>
                  {l.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </section>
      <Footer />
    </main>
  )
}
