import Header from "@/components/Header"

export const metadata = {
  title: "Management Consulting | Vestval",
  description:
    "Strategy, operating model, market entry, and performance improvement to unlock durable competitive advantage.",
}

export default function ManagementConsulting() {
  return (
    <main className="min-h-screen">
      <Header />
      <section className="pt-16 pb-10 bg-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-4xl">
          <h1 className="text-3xl md:text-5xl font-bold text-gray-900 mb-4">Management Consulting</h1>
          <p className="text-gray-600 text-lg mb-8">
            Strategy, operating model, market entry, and performance improvement to unlock durable competitive
            advantage.
          </p>
        </div>
      </section>
    </main>
  )
}
