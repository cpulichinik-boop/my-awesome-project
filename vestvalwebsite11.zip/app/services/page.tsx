import Header from "@/components/Header"
import Footer from "@/components/Footer"
import ScrollToTop from "@/components/ScrollToTop"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Smartphone,
  Brain,
  Cloud,
  Shield,
  TrendingUp,
  FileText,
  Handshake,
  BarChart3,
  Settings,
  DollarSign,
  Users,
  Globe,
} from "lucide-react"
import Link from "next/link"

export const metadata = {
  title: "Services - Vestval | IT, M&A, Leasing & Capital Advisory",
  description:
    "Comprehensive advisory services in IT & Digital Transformation, M&A, Leasing Strategy, Capital Advisory & CFO Services, and Management Consulting.",
}

const services = [
  {
    title: "IT & Digital Transformation",
    icon: <Smartphone className="h-8 w-8" />,
    description:
      "Harness the power of technology to streamline operations, enhance customer experience, and innovate at scale.",
    services: [
      {
        name: "Mobile & Web Application Development",
        description: "UX/UI design, MVP consulting, dedicated developer teams",
        icon: <Smartphone className="h-6 w-6" />,
      },
      {
        name: "Artificial Intelligence & Automation Solutions",
        description: "Machine learning, robotics, data-driven innovation",
        icon: <Brain className="h-6 w-6" />,
      },
      {
        name: "Cloud Infrastructure & Security",
        description: "Scalable, resilient, compliant environments",
        icon: <Cloud className="h-6 w-6" />,
      },
      {
        name: "Quality Assurance & Security Testing",
        description: "End-to-end reliability assurance",
        icon: <Shield className="h-6 w-6" />,
      },
    ],
  },
  {
    title: "Mergers & Acquisitions Advisory",
    icon: <TrendingUp className="h-8 w-8" />,
    description:
      "Navigate the complexities of buying, selling, and integrating businesses with our comprehensive suite of M&A services.",
    services: [
      {
        name: "Strategy & Planning",
        description: "Valuation & Due Diligence, Deal Origination & Negotiation",
        icon: <FileText className="h-6 w-6" />,
      },
      {
        name: "Cross-border Transaction Support",
        description: "Integration and cultural alignment strategies",
        icon: <Globe className="h-6 w-6" />,
      },
      {
        name: "AI-Powered Analytics",
        description: "Synergy capture technology and data intelligence",
        icon: <BarChart3 className="h-6 w-6" />,
      },
      {
        name: "Post-merger Integration",
        description: "Operational alignment and cultural integration",
        icon: <Handshake className="h-6 w-6" />,
      },
    ],
  },
  {
    title: "Leasing Advisory",
    icon: <Settings className="h-8 w-8" />,
    description:
      "Optimize your asset financing strategies with our advisory-led leasing solutions without NBFC constraints.",
    services: [
      {
        name: "Equipment Leasing Strategy",
        description: "Consultation-only, non-NBFC advisory approach",
        icon: <Settings className="h-6 w-6" />,
      },
      {
        name: "Vendor & Funder Relationship Management",
        description: "Optimize financing and operational efficiency",
        icon: <Users className="h-6 w-6" />,
      },
      {
        name: "Customized Asset-Light Growth Models",
        description: "Tailored solutions for diverse industries",
        icon: <TrendingUp className="h-6 w-6" />,
      },
    ],
  },
  {
    title: "Capital Advisory & CFO Services",
    icon: <DollarSign className="h-8 w-8" />,
    description:
      "Our experienced CFO advisory team offers strategic financial planning services designed to boost your valuation and growth potential.",
    services: [
      {
        name: "Debt Structuring & Capital Raising",
        description: "Strategic capital optimization and fundraising",
        icon: <DollarSign className="h-6 w-6" />,
      },
      {
        name: "Strategic Financial Planning",
        description: "CFO-led reporting excellence and planning",
        icon: <BarChart3 className="h-6 w-6" />,
      },
      {
        name: "Global Financial Networks",
        description: "Access to industry-specific experts worldwide",
        icon: <Globe className="h-6 w-6" />,
      },
    ],
  },
  {
    title: "Management Consulting",
    icon: <Users className="h-8 w-8" />,
    description:
      "Transform your business with actionable strategies that improve performance, mitigate risk, and enable market expansion.",
    services: [
      {
        name: "Business Growth Strategy",
        description: "Operational excellence and performance improvement",
        icon: <TrendingUp className="h-6 w-6" />,
      },
      {
        name: "Market Entry & Risk Advisory",
        description: "India and global market expansion strategies",
        icon: <Globe className="h-6 w-6" />,
      },
      {
        name: "Governance & Compliance",
        description: "Performance improvement consulting",
        icon: <Shield className="h-6 w-6" />,
      },
    ],
  },
]

export default function ServicesPage() {
  return (
    <main className="min-h-screen">
      <Header />

      {/* Hero Section */}
      <section className="pt-24 pb-16 gradient-bg text-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 animate-fade-in-up">Our Services</h1>
            <p className="text-xl md:text-2xl mb-8 opacity-90 animate-fade-in-up" style={{ animationDelay: "0.2s" }}>
              Comprehensive advisory excellence across IT, Finance, M&A, and Strategic Management
            </p>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="space-y-16">
            {services.map((service, index) => (
              <div key={index} className="max-w-6xl mx-auto">
                <div className="text-center mb-12">
                  <div className="w-16 h-16 gradient-bg rounded-full flex items-center justify-center mx-auto mb-4 text-white">
                    {service.icon}
                  </div>
                  <h2 className="text-3xl md:text-4xl font-bold mb-4">{service.title}</h2>
                  <p className="text-xl text-gray-600 max-w-3xl mx-auto">{service.description}</p>
                </div>

                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {service.services.map((subService, idx) => (
                    <Card key={idx} className="hover-lift">
                      <CardHeader>
                        <div className="flex items-center space-x-3">
                          <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center text-blue-600">
                            {subService.icon}
                          </div>
                          <CardTitle className="text-lg">{subService.name}</CardTitle>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <p className="text-gray-600">{subService.description}</p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-8">Why Choose Vestval?</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              <div className="text-center">
                <div className="w-16 h-16 gradient-bg rounded-full flex items-center justify-center mx-auto mb-4">
                  <DollarSign className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-lg font-bold mb-2">CFO-Led Value Creation</h3>
                <p className="text-gray-600 text-sm">Strategic financial leadership driving measurable outcomes</p>
              </div>

              <div className="text-center">
                <div className="w-16 h-16 gradient-bg rounded-full flex items-center justify-center mx-auto mb-4">
                  <Settings className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-lg font-bold mb-2">Tailored Financial Solutions</h3>
                <p className="text-gray-600 text-sm">Customized strategies aligned with your unique needs</p>
              </div>

              <div className="text-center">
                <div className="w-16 h-16 gradient-bg rounded-full flex items-center justify-center mx-auto mb-4">
                  <Globe className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-lg font-bold mb-2">Global Expertise</h3>
                <p className="text-gray-600 text-sm">Local execution with international best practices</p>
              </div>

              <div className="text-center">
                <div className="w-16 h-16 gradient-bg rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-lg font-bold mb-2">Entrepreneur-Centric</h3>
                <p className="text-gray-600 text-sm">Hands-on approach focused on your business growth</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 gradient-bg text-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Get Started?</h2>
          <p className="text-xl mb-8 opacity-90 max-w-2xl mx-auto">
            Let our expert team help you navigate complex challenges and unlock new growth opportunities.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" className="bg-white text-blue-600 hover:bg-gray-100">
              <Link href="/contact">Contact Our Experts</Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="border-white text-white hover:bg-white hover:text-blue-600 bg-transparent"
            >
              <Link href="/case-studies">View Case Studies</Link>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
      <ScrollToTop />
    </main>
  )
}
