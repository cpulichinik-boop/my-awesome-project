import type { MetadataRoute } from "next"

export default function sitemap(): MetadataRoute.Sitemap {
  const base = "https://vestval.example.com"
  const routes = [
    "/",
    "/about",
    "/about/purpose",
    "/about/values",
    "/about/people",
    "/about/locations",
    "/about/connect",
    "/services",
    "/services/leasing",
    "/industries",
    "/it",
    "/insights",
    "/insights/it/ai",
    "/insights/it/workforce",
    "/insights/it/risk",
    "/insights/it/sustainability",
    "/insights/it/transformation-realized",
    "/careers",
    "/careers/about",
    "/careers/how-to-join",
    "/careers/jobs",
    "/careers/culture",
    "/careers/paths",
    "/case-studies",
    "/newsroom",
    "/contact",
    "/teams",
    "/teams/business-building-and-incubation",
    "/teams/business-operations",
    "/teams/consulting",
    "/teams/data-science-and-analytics",
    "/teams/design-strategy",
    "/teams/expertise-and-insights",
    "/teams/finance",
    "/teams/legal-and-risk-management",
    "/teams/marketing-and-communications",
    "/teams/people-and-hr",
    "/teams/product-management",
    "/teams/technology-and-engineering",
  ]
  const now = new Date().toISOString()

  return routes.map((path) => ({
    url: `${base}${path}`,
    lastModified: now,
    changeFrequency: "weekly",
    priority: path === "/" ? 1 : 0.6,
  }))
}
