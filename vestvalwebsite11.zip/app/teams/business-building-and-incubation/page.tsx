import Header from "@/components/Header"
import Footer from "@/components/Footer"
import { Breadcrumbs } from "@/components/Breadcrumbs"
import Link from "next/link"

export const metadata = {
  title: "Business Building & Incubation — Teams | Vestval",
  description:
    "Incubate and launch new ventures, products, and growth initiatives. From zero-to-one to scale-up, we build with operators.",
}

export default function Page() {
  return (
    <main>
      <Header />
      <section className="pt-8">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <Breadcrumbs items={[{ name: "Teams", href: "/teams" }, { name: "Business Building & Incubation" }]} />
          <h1 className="text-3xl md:text-4xl font-bold mt-6 mb-4">Business Building & Incubation</h1>

          <div className="grid lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-6">
              <section>
                <h2 className="text-2xl font-semibold mb-2">Remit</h2>
                <p className="text-gray-700">
                  We partner with founders and business leaders to validate opportunities, design business models,
                  architect MVPs, and build go-to-market systems. Our team brings product, growth, and venture
                  experience—bridging strategy and execution for durable value creation.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-semibold mb-2">What success looks like</h2>
                <ul className="list-disc pl-5 text-gray-700 space-y-2">
                  <li>Clear problem-solution fit with measurable unit economics.</li>
                  <li>Shippable MVP with scalable tech and data foundations.</li>
                  <li>Repeatable customer acquisition and revenue traction.</li>
                  <li>Governance, risk, and capital plans aligned to growth stages.</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-semibold mb-2">Methods and frameworks</h2>
                <ul className="list-disc pl-5 text-gray-700 space-y-2">
                  <li>Opportunity mapping, market sizing, and JTBD interviews.</li>
                  <li>Lean validation sprints and rapid prototyping.</li>
                  <li>Pricing/packaging tests and channel strategy experiments.</li>
                  <li>Operating model design and stage-gated funding roadmaps.</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-semibold mb-2">Sample deliverables</h2>
                <ul className="list-disc pl-5 text-gray-700 space-y-2">
                  <li>Business model and financial plan with sensitivity analysis.</li>
                  <li>MVP scope, architecture overview, and backlog.</li>
                  <li>GTM playbook with ICPs, messaging, and channels.</li>
                  <li>12–18 month build/scale roadmap with risks and mitigations.</li>
                </ul>
              </section>

              <section className="border-t pt-4">
                <h2 className="text-2xl font-semibold mb-2">Related</h2>
                <p className="text-gray-700">
                  See{" "}
                  <Link className="text-blue-600 hover:underline" href="/services/management-consulting">
                    Management Consulting
                  </Link>
                  ,{" "}
                  <Link className="text-blue-600 hover:underline" href="/services/it-digital-transformation">
                    IT & Digital Transformation
                  </Link>{" "}
                  and{" "}
                  <Link className="text-blue-600 hover:underline" href="/insights/it/ai">
                    AI Insights
                  </Link>
                  .
                </p>
              </section>
            </div>

            <aside className="space-y-4">
              <div className="border rounded-lg p-4">
                <h3 className="font-semibold mb-2">Work with us</h3>
                <p className="text-sm text-gray-700 mb-3">
                  Ready to test, build, and scale? Our incubation team partners end-to-end.
                </p>
                <Link className="text-blue-600 hover:underline font-medium" href="/contact">
                  Contact our experts →
                </Link>
              </div>
              <div className="border rounded-lg p-4">
                <h3 className="font-semibold mb-2">Case studies</h3>
                <p className="text-sm text-gray-700">Read how we helped leaders ship products faster.</p>
                <Link className="text-blue-600 hover:underline font-medium" href="/case-studies">
                  Explore case studies →
                </Link>
              </div>
            </aside>
          </div>
        </div>
      </section>
      <Footer />
    </main>
  )
}
