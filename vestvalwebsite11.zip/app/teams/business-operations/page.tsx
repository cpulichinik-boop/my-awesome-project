import Header from "@/components/Header"
import Footer from "@/components/Footer"
import { Breadcrumbs } from "@/components/Breadcrumbs"
import Link from "next/link"

export const metadata = {
  title: "Business Operations — Teams | Vestval",
  description:
    "Design and optimize core processes, KPIs, and operating rhythms that align execution to strategy and drive performance.",
}

export default function Page() {
  return (
    <main>
      <Header />
      <section className="pt-8">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <Breadcrumbs items={[{ name: "Teams", href: "/teams" }, { name: "Business Operations" }]} />
          <h1 className="text-3xl md:text-4xl font-bold mt-6 mb-4">Business Operations</h1>
          <div className="space-y-6 max-w-3xl">
            <p className="text-gray-700">
              We align processes, metrics, and governance across functions so leaders can scale with visibility and
              control. From OKRs to close-the-loop cadences, we build systems that compound.
            </p>
            <h2 className="text-2xl font-semibold">What we deliver</h2>
            <ul className="list-disc pl-5 text-gray-700 space-y-2">
              <li>Operating model design and cross-functional RACI</li>
              <li>OKR frameworks, KPI catalogs, and executive dashboards</li>
              <li>Business reviews, planning calendars, and budget rhythms</li>
              <li>Vendor and procurement governance with risk controls</li>
            </ul>
            <div className="border-t pt-4">
              <p className="text-gray-700">
                Related:{" "}
                <Link className="text-blue-600 hover:underline" href="/services/finance-capital-advisory">
                  Finance & CFO Services
                </Link>{" "}
                ·{" "}
                <Link className="text-blue-600 hover:underline" href="/insights/it/risk">
                  Risk & Compliance
                </Link>
              </p>
            </div>
          </div>
        </div>
      </section>
      <Footer />
    </main>
  )
}
