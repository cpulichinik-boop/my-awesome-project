import Header from "@/components/Header"
import Footer from "@/components/Footer"
import { Breadcrumbs } from "@/components/Breadcrumbs"
import Link from "next/link"

export const metadata = {
  title: "Data Science & Analytics — Teams | Vestval",
  description:
    "Decision intelligence at scale: from data foundations and BI to ML systems for forecasting, risk, and automation.",
}

export default function Page() {
  return (
    <main>
      <Header />
      <section className="pt-8">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <Breadcrumbs items={[{ name: "Teams", href: "/teams" }, { name: "Data Science & Analytics" }]} />
          <h1 className="text-3xl md:text-4xl font-bold mt-6 mb-4">Data Science & Analytics</h1>
          <div className="space-y-6 max-w-3xl">
            <p className="text-gray-700">
              We build analytics that operators use. From semantic models and governance to applied ML, our work
              improves decisions, speed, and control.
            </p>
            <h2 className="text-2xl font-semibold">Offerings</h2>
            <ul className="list-disc pl-5 text-gray-700 space-y-2">
              <li>Data strategy, architecture, and governance</li>
              <li>BI platforms, KPI catalogs, and self-serve analytics</li>
              <li>ML for demand, churn, fraud, and NLP insights</li>
            </ul>
            <div className="border-t pt-4">
              <p className="text-gray-700">
                Related:{" "}
                <Link className="text-blue-600 hover:underline" href="/insights/it/ai">
                  AI & GenAI Insights
                </Link>{" "}
                ·{" "}
                <Link className="text-blue-600 hover:underline" href="/services/it-digital-transformation">
                  IT & Digital Transformation
                </Link>
              </p>
            </div>
          </div>
        </div>
      </section>
      <Footer />
    </main>
  )
}
