import Header from "@/components/Header"
import Footer from "@/components/Footer"
import { Breadcrumbs } from "@/components/Breadcrumbs"
import Link from "next/link"

export const metadata = {
  title: "Finance — Teams | Vestval",
  description:
    "CFO services, capital strategy, and performance management to optimize cost of capital and enable growth.",
}

export default function Page() {
  return (
    <main>
      <Header />
      <section className="pt-8">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <Breadcrumbs items={[{ name: "Teams", href: "/teams" }, { name: "Finance" }]} />
          <h1 className="text-3xl md:text-4xl font-bold mt-6 mb-4">Finance</h1>
          <div className="space-y-6 max-w-3xl">
            <p className="text-gray-700">
              Our finance team partners on capital structure, FP&A, and investor readiness—grounded in operator
              discipline and transparency.
            </p>
            <h2 className="text-2xl font-semibold">Focus areas</h2>
            <ul className="list-disc pl-5 text-gray-700 space-y-2">
              <li>Debt structuring and capital raising</li>
              <li>Budgeting, forecasting, and scenario planning</li>
              <li>Performance reporting and governance</li>
            </ul>
            <div className="border-t pt-4">
              <p className="text-gray-700">
                Related:{" "}
                <Link className="text-blue-600 hover:underline" href="/services/finance-capital-advisory">
                  Capital Advisory & CFO Services
                </Link>{" "}
                ·{" "}
                <Link className="text-blue-600 hover:underline" href="/case-studies">
                  Case Studies
                </Link>
              </p>
            </div>
          </div>
        </div>
      </section>
      <Footer />
    </main>
  )
}
