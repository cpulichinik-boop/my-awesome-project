import Header from "@/components/Header"
import Footer from "@/components/Footer"
import { Breadcrumbs } from "@/components/Breadcrumbs"
import Link from "next/link"

export const metadata = {
  title: "Marketing & Communications — Teams | Vestval",
  description:
    "Build brand, demand, and trust: positioning, content, lifecycle programs, and executive communications that convert.",
}

export default function Page() {
  return (
    <main>
      <Header />
      <section className="pt-8">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <Breadcrumbs items={[{ name: "Teams", href: "/teams" }, { name: "Marketing & Communications" }]} />
          <h1 className="text-3xl md:text-4xl font-bold mt-6 mb-4">Marketing & Communications</h1>
          <div className="space-y-6 max-w-3xl">
            <p className="text-gray-700">
              We connect positioning to pipeline and reputation—aligning content, channels, and measurement to business
              goals.
            </p>
            <h2 className="text-2xl font-semibold">Programs</h2>
            <ul className="list-disc pl-5 text-gray-700 space-y-2">
              <li>ICP research, narrative and messaging</li>
              <li>Content and thought leadership engines</li>
              <li>Lifecycle, ABM, and PR programs with analytics</li>
            </ul>
            <div className="border-t pt-4">
              <p className="text-gray-700">
                Related:{" "}
                <Link className="text-blue-600 hover:underline" href="/newsroom">
                  Newsroom
                </Link>{" "}
                ·{" "}
                <Link className="text-blue-600 hover:underline" href="/case-studies">
                  Case Studies
                </Link>{" "}
                ·{" "}
                <Link className="text-blue-600 hover:underline" href="/press-releases">
                  Press Releases
                </Link>
              </p>
            </div>
          </div>
        </div>
      </section>
      <Footer />
    </main>
  )
}
