import Header from "@/components/Header"
import Footer from "@/components/Footer"
import { Breadcrumbs } from "@/components/Breadcrumbs"
import Link from "next/link"

export const metadata = {
  title: "Teams — Capabilities & Functions | Vestval",
  description:
    "Explore Vestval's functional teams, their remit, methods, and sample deliverables. Discover how we partner across technology, finance, and strategy.",
}

const teams = [
  { slug: "business-building-and-incubation", title: "Business Building & Incubation" },
  { slug: "business-operations", title: "Business Operations" },
  { slug: "consulting", title: "Consulting" },
  { slug: "data-science-and-analytics", title: "Data Science & Analytics" },
  { slug: "design-strategy", title: "Design Strategy" },
  { slug: "expertise-and-insights", title: "Expertise & Insights" },
  { slug: "finance", title: "Finance" },
  { slug: "legal-and-risk-management", title: "Legal & Risk Management" },
  { slug: "marketing-and-communications", title: "Marketing & Communications" },
  { slug: "people-and-hr", title: "People & HR" },
  { slug: "product-management", title: "Product Management" },
  { slug: "technology-and-engineering", title: "Technology & Engineering" },
]

export default function TeamsHub() {
  return (
    <main>
      <Header />
      <section className="pt-8">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <Breadcrumbs items={[{ name: "Teams" }]} />
          <h1 className="text-3xl md:text-4xl font-bold mt-6 mb-4">Teams at Vestval</h1>
          <p className="text-gray-600 mb-6 max-w-3xl">
            Our multidisciplinary teams bring together deep functional expertise and operator experience. Explore each
            function’s remit, what success looks like, methods, and sample deliverables. Cross-link into{" "}
            <Link className="text-blue-600 hover:underline" href="/services">
              Services
            </Link>
            ,{" "}
            <Link className="text-blue-600 hover:underline" href="/industries">
              Industries
            </Link>
            , and{" "}
            <Link className="text-blue-600 hover:underline" href="/insights">
              Insights
            </Link>{" "}
            for related content.
          </p>

          <ul className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {teams.map((t) => (
              <li key={t.slug} className="border rounded-lg p-5 hover:shadow-md transition">
                <h2 className="text-xl font-semibold mb-2">{t.title}</h2>
                <p className="text-sm text-gray-600 mb-3">
                  Mandate, frameworks, and outcomes delivered by this function across client engagements.
                </p>
                <Link className="text-blue-600 hover:underline font-medium" href={`/teams/${t.slug}`}>
                  Explore team →
                </Link>
              </li>
            ))}
          </ul>

          <div className="mt-10 border-t pt-6">
            <h2 className="text-2xl font-bold mb-3">How we work together</h2>
            <p className="text-gray-600 max-w-3xl">
              Teams swarm around business outcomes—linking strategy to execution. For example, Technology & Engineering
              partners with Product Management and Design Strategy to ship platforms that Finance and Legal can scale
              safely, while Data Science enables decision intelligence and Expertise & Insights curates research for
              operators. This integrated approach accelerates value creation.
            </p>
          </div>
        </div>
      </section>
      <Footer />
    </main>
  )
}
