import Header from "@/components/Header"
import Footer from "@/components/Footer"
import { Breadcrumbs } from "@/components/Breadcrumbs"
import Link from "next/link"

export const metadata = {
  title: "People & HR — Teams | Vestval",
  description:
    "Talent systems for growth: workforce planning, performance, learning, and culture that attract and develop leaders.",
}

export default function Page() {
  return (
    <main>
      <Header />
      <section className="pt-8">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <Breadcrumbs items={[{ name: "Teams", href: "/teams" }, { name: "People & HR" }]} />
          <h1 className="text-3xl md:text-4xl font-bold mt-6 mb-4">People & HR</h1>
          <div className="space-y-6 max-w-3xl">
            <p className="text-gray-700">
              We design people systems that scale—from hiring and onboarding to performance and leadership development.
            </p>
            <h2 className="text-2xl font-semibold">Core practices</h2>
            <ul className="list-disc pl-5 text-gray-700 space-y-2">
              <li>Org design, workforce planning, and role architectures</li>
              <li>Performance, rewards, and talent reviews</li>
              <li>Learning programs and leadership development</li>
            </ul>
            <div className="border-t pt-4">
              <p className="text-gray-700">
                Related:{" "}
                <Link className="text-blue-600 hover:underline" href="/insights/it/workforce">
                  Workforce Insights
                </Link>
              </p>
            </div>
          </div>
        </div>
      </section>
      <Footer />
    </main>
  )
}
