import Header from "@/components/Header"
import Footer from "@/components/Footer"
import { Breadcrumbs } from "@/components/Breadcrumbs"

export const metadata = {
  title: "Terms of Service - Vestval | Terms & Conditions",
  description: "Vestval's terms of service governing the use of our advisory services and website.",
}

export default function TermsOfServicePage() {
  return (
    <main>
      <Header />
      <section className="pt-8 pb-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-4xl">
          <Breadcrumbs items={[{ name: "Terms of Service" }]} />
          <h1 className="text-3xl md:text-4xl font-bold mt-6 mb-8">Terms of Service</h1>

          <div className="prose prose-gray max-w-none">
            <p className="text-lg text-gray-600 mb-8">Last updated: January 2025</p>

            <section className="mb-8">
              <h2 className="text-2xl font-bold mb-4">1. Acceptance of Terms</h2>
              <p className="mb-4">
                By accessing and using Vestval's services, you accept and agree to be bound by the terms and provision
                of this agreement. If you do not agree to abide by the above, please do not use this service.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold mb-4">2. Advisory Services</h2>
              <p className="mb-4">
                Vestval provides advisory services in IT & Digital Transformation, M&A, Capital Advisory, Management
                Consulting, and Leasing Advisory. Our services are provided on a consultative basis and do not
                constitute financial intermediation.
              </p>
              <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 mb-4">
                <p className="text-sm">
                  <strong>Important:</strong> Vestval operates as an advisory-only firm and does not function as a
                  Non-Banking Financial Company (NBFC) or financial intermediary.
                </p>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold mb-4">3. Use License</h2>
              <p className="mb-4">
                Permission is granted to temporarily access the materials on Vestval's website for personal,
                non-commercial transitory viewing only. This is the grant of a license, not a transfer of title, and
                under this license you may not:
              </p>
              <ul className="list-disc pl-6 mb-4">
                <li>Modify or copy the materials</li>
                <li>Use the materials for commercial purposes or public display</li>
                <li>Attempt to reverse engineer any software</li>
                <li>Remove any copyright or proprietary notations</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold mb-4">4. Disclaimer</h2>
              <p className="mb-4">
                The materials on Vestval's website are provided on an 'as is' basis. Vestval makes no warranties,
                expressed or implied, and hereby disclaims and negates all other warranties including without
                limitation, implied warranties or conditions of merchantability, fitness for a particular purpose, or
                non-infringement of intellectual property or other violation of rights.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold mb-4">5. Limitations</h2>
              <p className="mb-4">
                In no event shall Vestval or its suppliers be liable for any damages (including, without limitation,
                damages for loss of data or profit, or due to business interruption) arising out of the use or inability
                to use the materials on Vestval's website, even if Vestval or an authorized representative has been
                notified orally or in writing of the possibility of such damage.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold mb-4">6. Accuracy of Materials</h2>
              <p className="mb-4">
                The materials appearing on Vestval's website could include technical, typographical, or photographic
                errors. Vestval does not warrant that any of the materials on its website are accurate, complete, or
                current.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold mb-4">7. Governing Law</h2>
              <p className="mb-4">
                These terms and conditions are governed by and construed in accordance with the laws of India and you
                irrevocably submit to the exclusive jurisdiction of the courts in Mumbai, India.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold mb-4">8. Contact Information</h2>
              <p className="mb-4">If you have any questions about these Terms of Service, please contact us at:</p>
              <div className="bg-gray-50 p-4 rounded-lg">
                <p>
                  <strong>Email:</strong> legal@vestval.com
                </p>
                <p>
                  <strong>Address:</strong> Bandra Kurla Complex, Mumbai 400051, India
                </p>
              </div>
            </section>
          </div>
        </div>
      </section>
      <Footer />
    </main>
  )
}
