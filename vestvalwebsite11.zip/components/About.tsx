"use client"

import { useEffect, useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import AnimatedCounter from "./AnimatedCounter"

const GlobeIcon = () => (
  <svg className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9"
    />
  </svg>
)

const UsersIcon = () => (
  <svg className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-2.865"
    />
  </svg>
)

const TargetIcon = () => (
  <svg className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
    />
  </svg>
)

const AwardIcon = () => (
  <svg className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138z"
    />
  </svg>
)

export default function About() {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 },
    )

    const element = document.getElementById("about")
    if (element) observer.observe(element)

    return () => observer.disconnect()
  }, [])

  const values = [
    {
      icon: TargetIcon,
      title: "Our Mission",
      description:
        "To be the most trusted partner for businesses aspiring to achieve sustainable, strategic growth through expert advisory services grounded in integrity and innovation. We empower organizations to navigate complex challenges and unlock their full potential through technology and financial excellence.",
    },
    {
      icon: GlobeIcon,
      title: "Global Vision",
      description:
        "To build a world where businesses of every scale have access to the highest caliber of strategic advice, enabling them to thrive in an increasingly complex global market. Our vision extends beyond traditional consulting to create lasting partnerships that drive meaningful transformation.",
    },
    {
      icon: UsersIcon,
      title: "Leadership Excellence",
      description:
        "Our leadership team comprises seasoned professionals with decades of experience across finance, technology, and corporate strategy, united by a commitment to client success. We bring together diverse expertise from Fortune 500 companies, leading consulting firms, and successful entrepreneurial ventures.",
    },
    {
      icon: AwardIcon,
      title: "Advisory Approach",
      description:
        "Vestval operates as an advisory-only firm, free from regulatory complexities, allowing us to focus purely on delivering client value through customized strategies. This independence enables us to provide unbiased recommendations and maintain the highest standards of professional integrity.",
    },
  ]

  return (
    <section id="about" className="py-20 lg:py-32 bg-gray-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className={`transition-all duration-1000 ${isVisible ? "animate-fade-in-up" : "opacity-0"}`}>
          {/* Section header */}
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
              About{" "}
              <span className="bg-gradient-to-r from-blue-600 to-teal-500 bg-clip-text text-transparent">Vestval</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
              Vestval is a premier global advisory firm dedicated to empowering ambitious businesses with expert
              consulting and financial strategies. With a heritage rooted in innovation and integrity, we combine
              international insights with local expertise to deliver transformational results. Our multidisciplinary
              approach spans technology, finance, and strategic management, ensuring comprehensive solutions that drive
              sustainable growth and competitive advantage in today's dynamic business landscape.
            </p>
            <div className="mt-8">
              <Button
                asChild
                size="lg"
                className="bg-gradient-to-r from-blue-600 to-teal-500 text-white hover:opacity-90 transition-opacity"
              >
                <Link href="/about">
                  Learn More About Us
                  <svg className="ml-2 h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </Link>
              </Button>
            </div>
          </div>

          {/* Values grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
            {values.map((value, index) => (
              <Card
                key={index}
                className={`border-0 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 hover-lift ${
                  isVisible ? "animate-fade-in-up" : "opacity-0"
                }`}
                style={{ animationDelay: `${index * 200}ms` }}
              >
                <CardContent className="p-8">
                  <div className="flex items-start space-x-4">
                    <div className="flex-shrink-0">
                      <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-teal-500 rounded-lg flex items-center justify-center">
                        <value.icon />
                      </div>
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-gray-900 mb-3">{value.title}</h3>
                      <p className="text-gray-600 leading-relaxed">{value.description}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Stats section with animated counters */}
          <div className="bg-white rounded-2xl shadow-xl p-8 lg:p-12">
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
              <div className="text-center">
                <AnimatedCounter end={300} suffix="+" />
                <div className="text-gray-600 font-medium mt-2">Deals Completed</div>
              </div>
              <div className="text-center">
                <AnimatedCounter end={100} suffix="+" />
                <div className="text-gray-600 font-medium mt-2">Businesses Served</div>
              </div>
              <div className="text-center">
                <AnimatedCounter end={1} suffix="B+" prefix="$" />
                <div className="text-gray-600 font-medium mt-2">Value Delivered</div>
              </div>
              <div className="text-center">
                <AnimatedCounter end={30} suffix="+" />
                <div className="text-gray-600 font-medium mt-2">Investment Sectors</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
