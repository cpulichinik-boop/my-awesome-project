"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogClose,
} from "@/components/ui/dialog"

const CalendarIcon = ({ className }: { className?: string }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
    />
  </svg>
)

const ClockIcon = ({ className }: { className?: string }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
    />
  </svg>
)

const ArrowRightIcon = ({ className }: { className?: string }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
  </svg>
)

const TrendingUpIcon = ({ className }: { className?: string }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
  </svg>
)

const GlobeIcon = ({ className }: { className?: string }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-2.865"
    />
  </svg>
)

const UsersIcon = ({ className }: { className?: string }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-2.865"
    />
  </svg>
)

const BriefcaseIcon = ({ className }: { className?: string }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m8 0H8m8 0v6a2 2 0 01-2 2H10a2 2 0 01-2-2V6m8 0V4a2 2 0 00-2-2H10a2 2 0 00-2 2v2"
    />
  </svg>
)

const TargetIcon = ({ className }: { className?: string }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
    />
  </svg>
)

export default function Blog() {
  const [isVisible, setIsVisible] = useState(false)
  const [selectedCategory, setSelectedCategory] = useState("All")
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [activePost, setActivePost] = useState(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 },
    )

    const element = document.getElementById("blog")
    if (element) observer.observe(element)

    return () => observer.disconnect()
  }, [])

  const categories = [
    { name: "All", icon: GlobeIcon },
    { name: "Digital Transformation", icon: TrendingUpIcon },
    { name: "M&A Insights", icon: BriefcaseIcon },
    { name: "Capital Markets", icon: TargetIcon },
    { name: "Management", icon: UsersIcon },
  ]

  const blogPosts = [
    {
      id: 1,
      title: "The Future of Digital Transformation in Enterprise IT",
      excerpt:
        "Digital transformation is no longer a choice but a business imperative. Discover the latest trends in AI, cloud computing, and cybersecurity that are reshaping enterprise IT.",
      category: "Digital Transformation",
      author: "Dr. Vikram Shah",
      date: "2024-01-15",
      readTime: "8 min read",
      image: "/digital-transformation.png",
      featured: true,
    },
    {
      id: 2,
      title: "Navigating Cross-Border M&A: Strategies for Global Success",
      excerpt:
        "Cross-border mergers and acquisitions present unique challenges. Learn the essential strategies for successful international deals and post-merger integration.",
      category: "M&A Insights",
      author: "Anjali Mehta",
      date: "2024-01-12",
      readTime: "12 min read",
      image: "/business-handshake-global-merger.jpg",
      featured: true,
    },
    {
      id: 3,
      title: "Capital Advisory: Structuring Finance for Sustainable Growth",
      excerpt:
        "Effective capital advisory approaches that drive sustainable business growth through expert debt and equity structuring strategies.",
      category: "Capital Markets",
      author: "Rajesh Kumar",
      date: "2024-01-10",
      readTime: "6 min read",
      image: "/financial-charts-growth-strategy.jpg",
      featured: false,
    },
    {
      id: 4,
      title: "Leasing Advisory: Unlocking Financial Flexibility",
      excerpt:
        "How advisory-led leasing can optimize costs and provide financial flexibility for expanding businesses in today's dynamic market.",
      category: "Management",
      author: "Karan Sharma",
      date: "2024-01-08",
      readTime: "5 min read",
      image: "/business-equipment-leasing-office.jpg",
      featured: false,
    },
    {
      id: 5,
      title: "AI in Finance & Advisory: Transforming Decision-Making",
      excerpt:
        "Explore how artificial intelligence is revolutionizing financial advisory services and risk management in the modern business landscape.",
      category: "Digital Transformation",
      author: "Naythan Miller",
      date: "2024-01-05",
      readTime: "10 min read",
      image: "/artificial-intelligence-finance-data.jpg",
      featured: false,
    },
    {
      id: 6,
      title: "Management Consulting Trends: Driving Performance in 2024",
      excerpt:
        "The latest trends in management consulting that help businesses improve performance and enter new markets with confidence.",
      category: "Management",
      author: "Élise Beauvoir",
      date: "2024-01-03",
      readTime: "7 min read",
      image: "/business-strategy-consulting-meeting.jpg",
      featured: false,
    },
  ]

  const filteredPosts =
    selectedCategory === "All" ? blogPosts : blogPosts.filter((post) => post.category === selectedCategory)
  const featuredPosts = blogPosts.filter((post) => post.featured)
  const regularPosts = filteredPosts.filter((post) => !post.featured)

  const handlePostClick = (post) => {
    setActivePost(post)
    setIsDialogOpen(true)
  }

  const handleReadMore = (post) => {
    setActivePost(post)
    setIsDialogOpen(true)
  }

  return (
    <section id="blog" className="py-20 lg:py-32 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className={`transition-all duration-1000 ${isVisible ? "animate-fade-in-up" : "opacity-0"}`}>
          {/* Section header */}
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
              Industry <span className="gradient-text">Insights</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Stay ahead with expert insights, market analysis, and strategic guidance from Vestval's global advisory
              team. Discover the latest trends shaping the future of business.
            </p>
          </div>

          {/* Category filters */}
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            {categories.map((category, index) => (
              <Button
                key={index}
                variant={selectedCategory === category.name ? "default" : "outline"}
                onClick={() => setSelectedCategory(category.name)}
                className={`flex items-center space-x-2 ${
                  selectedCategory === category.name
                    ? "gradient-bg text-white"
                    : "bg-white text-gray-700 hover:bg-gray-50"
                }`}
              >
                <category.icon className="h-4 w-4" />
                <span>{category.name}</span>
              </Button>
            ))}
          </div>

          {/* Featured posts */}
          {selectedCategory === "All" && featuredPosts.length > 0 && (
            <div className="mb-16">
              <h3 className="text-2xl font-bold text-gray-900 mb-8">Featured Articles</h3>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {featuredPosts.map((post, index) => (
                  <Card
                    key={post.id}
                    className={`border-0 shadow-xl hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 overflow-hidden cursor-pointer ${
                      isVisible ? "animate-fade-in-up" : "opacity-0"
                    }`}
                    style={{ animationDelay: `${index * 200}ms` }}
                    onClick={() => handlePostClick(post)}
                  >
                    <div className="relative h-48 bg-gray-200">
                      <img
                        src={post.image || "/placeholder.svg"}
                        alt={post.title}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute top-4 left-4">
                        <Badge className="gradient-bg text-white border-0">{post.category}</Badge>
                      </div>
                    </div>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-xl font-bold text-gray-900 line-clamp-2 hover:text-primary transition-colors duration-300">
                        {post.title}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-600 mb-4 line-clamp-3 leading-relaxed">{post.excerpt}</p>
                      <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                        <div className="flex items-center space-x-4">
                          <div className="flex items-center space-x-1">
                            <CalendarIcon className="h-4 w-4" />
                            <span>{new Date(post.date).toLocaleDateString()}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <ClockIcon className="h-4 w-4" />
                            <span>{post.readTime}</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium text-gray-700">By {post.author}</span>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-primary hover:text-primary/80 p-0"
                          onClick={() => handleReadMore(post)}
                          aria-label={`Read more: ${post.title}`}
                        >
                          Read More
                          <ArrowRightIcon className="ml-1 h-4 w-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {/* Regular posts */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {regularPosts.map((post, index) => (
              <Card
                key={post.id}
                className={`border-0 shadow-lg hover:shadow-xl transition-all duration-500 transform hover:-translate-y-2 overflow-hidden group cursor-pointer ${
                  isVisible ? "animate-fade-in-up" : "opacity-0"
                }`}
                style={{ animationDelay: `${(index + featuredPosts.length) * 150}ms` }}
                onClick={() => handlePostClick(post)}
              >
                <div className="relative h-40 bg-gray-200">
                  <img
                    src={post.image || "/placeholder.svg"}
                    alt={post.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-3 left-3">
                    <Badge variant="secondary" className="text-xs bg-white/90 text-gray-700">
                      {post.category}
                    </Badge>
                  </div>
                </div>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg font-bold text-gray-900 line-clamp-2 group-hover:text-primary transition-colors duration-300">
                    {post.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 text-sm mb-4 line-clamp-3 leading-relaxed">{post.excerpt}</p>
                  <div className="flex items-center justify-between text-xs text-gray-500 mb-3">
                    <div className="flex items-center space-x-3">
                      <div className="flex items-center space-x-1">
                        <CalendarIcon className="h-3 w-3" />
                        <span>{new Date(post.date).toLocaleDateString()}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <ClockIcon className="h-3 w-3" />
                        <span>{post.readTime}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-medium text-gray-700">By {post.author}</span>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-primary hover:text-primary/80 p-0 text-xs"
                      onClick={() => handleReadMore(post)}
                      aria-label={`Read more: ${post.title}`}
                    >
                      Read More
                      <ArrowRightIcon className="ml-1 h-3 w-3" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Newsletter signup */}
          <div className="mt-16 bg-gray-50 rounded-2xl p-8 lg:p-12 text-center">
            <h3 className="text-2xl lg:text-3xl font-bold text-gray-900 mb-4">
              Stay Informed with <span className="gradient-text">Vestval Insights</span>
            </h3>
            <p className="text-gray-600 mb-8 max-w-2xl mx-auto">
              Get the latest industry insights, market analysis, and strategic guidance delivered directly to your
              inbox. Join thousands of business leaders who trust Vestval for expert advisory content.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center max-w-md mx-auto">
              <input
                type="email"
                placeholder="Enter your email address"
                className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent outline-none"
              />
              <Button className="gradient-bg text-white hover:opacity-90 transition-opacity px-8 py-3 font-semibold">
                Subscribe
              </Button>
            </div>
            <p className="text-xs text-gray-500 mt-4">
              No spam, unsubscribe at any time. Read our{" "}
              <Link href="/contact" className="text-primary hover:underline">
                Privacy Policy
              </Link>
              .
            </p>
          </div>
        </div>
      </div>

      {/* Dialog for post preview */}
      {activePost && (
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>{activePost?.title}</DialogTitle>
              <DialogDescription className="text-sm text-gray-500">
                {activePost ? new Date(activePost.date).toLocaleDateString() : ""} • {activePost?.author} •{" "}
                {activePost?.readTime}
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4">
              {activePost?.image ? (
                <img
                  src={activePost.image || "/placeholder.svg"}
                  alt={activePost.title}
                  className="w-full h-48 object-cover rounded-md"
                />
              ) : null}

              <p className="text-gray-700 leading-relaxed">{activePost?.excerpt}</p>

              <div className="flex items-center justify-between pt-2">
                <Link href="/contact" className="text-primary hover:underline">
                  Contact us about this topic
                </Link>
                <DialogClose className="px-4 py-2 rounded-md bg-gray-900 text-white">Close</DialogClose>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </section>
  )
}
