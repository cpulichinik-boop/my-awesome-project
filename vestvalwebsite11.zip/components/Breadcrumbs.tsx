"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb"
import Script from "next/script"

type Crumb = { name: string; href?: string }

export function Breadcrumbs({ items }: { items?: Crumb[] }) {
  const pathname = usePathname()

  const autoItems: Crumb[] =
    items ??
    pathname
      .split("/")
      .filter(Boolean)
      .map((seg, idx, arr) => {
        const href = "/" + arr.slice(0, idx + 1).join("/")
        return { name: seg.replace(/-/g, " ").replace(/\b\w/g, (c) => c.toUpperCase()), href }
      })

  const origin = typeof window !== "undefined" ? window.location.origin : ""
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      {
        "@type": "ListItem",
        position: 1,
        name: "Home",
        item: origin || "" ? `${origin}` : undefined,
      },
      ...autoItems.map((item, i) => ({
        "@type": "ListItem",
        position: i + 2,
        name: item.name,
        item: item.href ? `${origin}${item.href}` : undefined,
      })),
    ],
  }

  return (
    <>
      <Script id="ld-breadcrumb-auto" type="application/ld+json">
        {JSON.stringify(jsonLd)}
      </Script>
      <Breadcrumb>
        <BreadcrumbList>
          <BreadcrumbItem>
            <BreadcrumbLink asChild>
              <Link href="/">Home</Link>
            </BreadcrumbLink>
          </BreadcrumbItem>
          {autoItems.map((item, i) => {
            const isLast = i === autoItems.length - 1
            return (
              <span key={i} className="inline-flex items-center">
                <BreadcrumbSeparator />
                <BreadcrumbItem>
                  {isLast || !item.href ? (
                    <BreadcrumbPage>{item.name}</BreadcrumbPage>
                  ) : (
                    <BreadcrumbLink asChild>
                      <Link href={item.href!}>{item.name}</Link>
                    </BreadcrumbLink>
                  )}
                </BreadcrumbItem>
              </span>
            )
          })}
        </BreadcrumbList>
      </Breadcrumb>
    </>
  )
}
