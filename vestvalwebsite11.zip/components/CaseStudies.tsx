"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

const TrendingUpIcon = () => (
  <svg className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
  </svg>
)

const GlobeIcon = () => (
  <svg className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9"
    />
  </svg>
)

const DollarSignIcon = () => (
  <svg className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1"
    />
  </svg>
)

const UsersIcon = () => (
  <svg className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-2.865"
    />
  </svg>
)

export default function CaseStudies() {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 },
    )

    const element = document.getElementById("case-studies")
    if (element) observer.observe(element)

    return () => observer.disconnect()
  }, [])

  const caseStudies = [
    {
      title: "Cross-Border Technology Acquisition",
      industry: "Technology",
      challenge:
        "A leading software company needed to acquire a strategic technology firm across borders to expand their AI capabilities and enter new markets.",
      solution:
        "Comprehensive due diligence, valuation analysis, and integration planning delivered with advanced data intelligence tools and cross-jurisdictional expertise.",
      results: [
        { metric: "15%", description: "Operational synergy realized post-integration" },
        { metric: "6 months", description: "Faster than projected timeline" },
        { metric: "$50M", description: "Additional value identified" },
      ],
      icon: GlobeIcon,
      color: "from-blue-500 to-blue-600",
    },
    {
      title: "Manufacturing Leasing Optimization",
      industry: "Manufacturing",
      challenge:
        "A rapidly growing manufacturing company needed to optimize their equipment leasing strategy to support expansion while maintaining financial flexibility.",
      solution:
        "Custom leasing advisory and vendor management strategy enabling significant cost savings and enhanced operational agility.",
      results: [
        { metric: "20%", description: "Reduction in financing costs" },
        { metric: "40%", description: "Improved cash flow flexibility" },
        { metric: "3x", description: "Faster equipment deployment" },
      ],
      icon: TrendingUpIcon,
      color: "from-green-500 to-green-600",
    },
    {
      title: "Digital Transformation Initiative",
      industry: "Financial Services",
      challenge:
        "A traditional financial services firm required comprehensive digital transformation to compete with fintech disruptors and improve customer experience.",
      solution:
        "End-to-end digital strategy including cloud migration, AI implementation, and customer experience redesign with robust security frameworks.",
      results: [
        { metric: "60%", description: "Improvement in customer satisfaction" },
        { metric: "35%", description: "Reduction in operational costs" },
        { metric: "2.5x", description: "Increase in digital engagement" },
      ],
      icon: DollarSignIcon,
      color: "from-purple-500 to-purple-600",
    },
    {
      title: "Capital Structure Optimization",
      industry: "Healthcare",
      challenge:
        "A healthcare technology startup needed strategic capital advisory to structure their Series B funding and prepare for international expansion.",
      solution:
        "Comprehensive capital advisory including debt structuring, investor relations, and strategic financial planning with access to global investor networks.",
      results: [
        { metric: "$25M", description: "Series B funding secured" },
        { metric: "18 months", description: "Extended runway achieved" },
        { metric: "3 markets", description: "International expansion enabled" },
      ],
      icon: UsersIcon,
      color: "from-orange-500 to-orange-600",
    },
  ]

  return (
    <section id="case-studies" className="py-20 lg:py-32 bg-gray-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className={`transition-all duration-1000 ${isVisible ? "animate-fade-in-up" : "opacity-0"}`}>
          {/* Section header */}
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
              Success <span className="gradient-text">Stories</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Real results from real clients. Discover how Vestval's strategic advisory services have transformed
              businesses across industries and geographies.
            </p>
          </div>

          {/* Case studies grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {caseStudies.map((study, index) => (
              <Card
                key={index}
                className={`border-0 shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 ${
                  isVisible ? "animate-fade-in-up" : "opacity-0"
                }`}
                style={{ animationDelay: `${index * 200}ms` }}
              >
                <CardHeader className="pb-4">
                  <div className="flex items-start justify-between mb-4">
                    <div
                      className={`w-12 h-12 rounded-lg bg-gradient-to-r ${study.color} flex items-center justify-center`}
                    >
                      <study.icon />
                    </div>
                    <Badge variant="secondary" className="text-xs">
                      {study.industry}
                    </Badge>
                  </div>
                  <CardTitle className="text-xl font-bold text-gray-900 mb-2">{study.title}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Challenge</h4>
                    <p className="text-gray-600 text-sm leading-relaxed">{study.challenge}</p>
                  </div>

                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Solution</h4>
                    <p className="text-gray-600 text-sm leading-relaxed">{study.solution}</p>
                  </div>

                  <div>
                    <h4 className="font-semibold text-gray-900 mb-3">Results</h4>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      {study.results.map((result, resultIndex) => (
                        <div key={resultIndex} className="text-center p-3 bg-gray-50 rounded-lg">
                          <div className="text-lg font-bold gradient-text">{result.metric}</div>
                          <div className="text-xs text-gray-600 mt-1">{result.description}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* CTA section */}
          <div className="text-center mt-16">
            <div className="bg-white rounded-2xl shadow-xl p-8 lg:p-12">
              <h3 className="text-2xl lg:text-3xl font-bold text-gray-900 mb-4">Ready to Write Your Success Story?</h3>
              <p className="text-gray-600 mb-8 max-w-2xl mx-auto">
                Join the growing list of businesses that have transformed their operations and achieved remarkable
                growth with Vestval's strategic advisory services.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <a
                  href="/contact"
                  className="px-8 py-3 gradient-bg text-white rounded-lg font-semibold hover:opacity-90 transition-opacity text-center"
                >
                  Start Your Journey
                </a>
                <a
                  href="/case-studies"
                  className="px-8 py-3 border border-gray-300 text-gray-700 rounded-lg font-semibold hover:bg-gray-50 transition-colors text-center"
                >
                  View All Case Studies
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
