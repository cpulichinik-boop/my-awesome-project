"use client"

import { useEffect, useState } from "react"
import { Card, CardContent } from "@/components/ui/card"

const MapPinIcon = ({ className }: { className?: string }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"
    />
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
  </svg>
)

const ClockIcon = ({ className }: { className?: string }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
    />
  </svg>
)

const PhoneIcon = ({ className }: { className?: string }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"
    />
  </svg>
)

const MailIcon = ({ className }: { className?: string }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
    />
  </svg>
)

export default function GlobalNetwork() {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 },
    )

    const element = document.getElementById("global-network")
    if (element) observer.observe(element)

    return () => observer.disconnect()
  }, [])

  const offices = [
    {
      city: "Mumbai",
      country: "India",
      type: "Headquarters",
      address: "North Ave, near MAKER MAXITY, Bandra Kurla Complex, Bandra East, Mumbai, Maharashtra 400051",
      phone: "+91 22 6789 0123",
      timezone: "IST (UTC+5:30)",
      hours: "9:00 AM - 7:00 PM",
      color: "from-blue-500 to-blue-600",
    },
    {
      city: "Philadelphia",
      country: "USA",
      type: "North America Office",
      address: "190 N Independence Mall W, Philadelphia, PA 19106, USA",
      phone: "+1 215 555 0123",
      timezone: "EST (UTC-5)",
      hours: "9:00 AM - 6:00 PM",
      color: "from-green-500 to-green-600",
    },
    {
      city: "Manchester",
      country: "United Kingdom",
      type: "Europe Office",
      address: "CIS Tower, 6 Hanover St, Manchester M4 4BB, UK",
      phone: "+44 161 555 0123",
      timezone: "GMT (UTC+0)",
      hours: "9:00 AM - 6:00 PM",
      color: "from-purple-500 to-purple-600",
    },
  ]

  return (
    <section id="global-network" className="py-20 lg:py-32 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className={`transition-all duration-1000 ${isVisible ? "animate-fade-in-up" : "opacity-0"}`}>
          {/* Section header */}
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
              Global <span className="gradient-text">Network</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Vestval's global advisory network spans 30+ countries, blending deep local insights with international
              experience. With headquarters in India and key offices worldwide, our experts collaborate seamlessly to
              drive cross-border growth strategies.
            </p>
          </div>

          {/* World map visualization */}
          <div className="mb-16 relative">
            <div className="bg-gradient-to-r from-gray-50 to-gray-100 rounded-2xl p-8 lg:p-12 text-center">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
                <div>
                  <div className="text-3xl lg:text-4xl font-bold gradient-text mb-2">30+</div>
                  <div className="text-gray-600 font-medium">Countries Served</div>
                </div>
                <div>
                  <div className="text-3xl lg:text-4xl font-bold gradient-text mb-2">24/7</div>
                  <div className="text-gray-600 font-medium">Global Support</div>
                </div>
                <div>
                  <div className="text-3xl lg:text-4xl font-bold gradient-text mb-2">15+</div>
                  <div className="text-gray-600 font-medium">Time Zones</div>
                </div>
              </div>
              <p className="text-gray-600 max-w-2xl mx-auto">
                Our distributed team ensures round-the-clock support and local expertise wherever your business operates
                or plans to expand.
              </p>
            </div>
          </div>

          {/* Office locations */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {offices.map((office, index) => (
              <Card
                key={index}
                className={`border-0 shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 ${
                  isVisible ? "animate-fade-in-up" : "opacity-0"
                }`}
                style={{ animationDelay: `${index * 200}ms` }}
              >
                <CardContent className="p-8">
                  <div className="flex items-start justify-between mb-6">
                    <div>
                      <h3 className="text-xl font-bold text-gray-900 mb-1">{office.city}</h3>
                      <p className="text-gray-600 font-medium">{office.country}</p>
                      <span
                        className={`inline-block px-3 py-1 rounded-full text-xs font-medium text-white bg-gradient-to-r ${office.color} mt-2`}
                      >
                        {office.type}
                      </span>
                    </div>
                    <div
                      className={`w-12 h-12 rounded-lg bg-gradient-to-r ${office.color} flex items-center justify-center`}
                    >
                      <MapPinIcon className="h-6 w-6 text-white" />
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="flex items-start space-x-3">
                      <MapPinIcon className="h-4 w-4 text-gray-400 mt-1 flex-shrink-0" />
                      <p className="text-sm text-gray-600 leading-relaxed">{office.address}</p>
                    </div>

                    <div className="flex items-center space-x-3">
                      <PhoneIcon className="h-4 w-4 text-gray-400 flex-shrink-0" />
                      <p className="text-sm text-gray-600">{office.phone}</p>
                    </div>

                    <div className="flex items-center space-x-3">
                      <ClockIcon className="h-4 w-4 text-gray-400 flex-shrink-0" />
                      <div className="text-sm text-gray-600">
                        <p>{office.hours}</p>
                        <p className="text-xs text-gray-500">{office.timezone}</p>
                      </div>
                    </div>

                    <div className="flex items-center space-x-3">
                      <MailIcon className="h-4 w-4 text-gray-400 flex-shrink-0" />
                      <p className="text-sm text-gray-600">contact@vestval.com</p>
                    </div>
                  </div>

                  <div className="mt-6 pt-6 border-t border-gray-200">
                    <button
                      className={`w-full py-2 px-4 rounded-lg bg-gradient-to-r ${office.color} text-white font-medium hover:opacity-90 transition-opacity`}
                    >
                      Contact {office.city} Office
                    </button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Partnership section */}
          <div className="mt-16 bg-gray-50 rounded-2xl p-8 lg:p-12 text-center">
            <h3 className="text-2xl lg:text-3xl font-bold text-gray-900 mb-6">
              Strategic <span className="gradient-text">Partnerships</span>
            </h3>
            <p className="text-gray-600 mb-8 max-w-3xl mx-auto leading-relaxed">
              We collaborate with top-tier partners and industry leaders to address complex cross-border challenges and
              deliver comprehensive solutions that drive sustainable growth.
            </p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 opacity-90">
              <a
                href="/partners/technology"
                className="text-center group focus:outline-none focus:ring-2 focus:ring-blue-600 rounded-lg"
              >
                <div className="w-16 h-16 bg-white rounded-lg shadow-md flex items-center justify-center mx-auto mb-3 group-hover:scale-105 transition-transform">
                  <div className="w-8 h-8 bg-gray-300 rounded"></div>
                </div>
                <p className="text-sm text-gray-700">Technology Partners</p>
              </a>
              <a
                href="/partners/financial-institutions"
                className="text-center group focus:outline-none focus:ring-2 focus:ring-blue-600 rounded-lg"
              >
                <div className="w-16 h-16 bg-white rounded-lg shadow-md flex items-center justify-center mx-auto mb-3 group-hover:scale-105 transition-transform">
                  <div className="w-8 h-8 bg-gray-300 rounded"></div>
                </div>
                <p className="text-sm text-gray-700">Financial Institutions</p>
              </a>
              <a
                href="/partners/legal-advisors"
                className="text-center group focus:outline-none focus:ring-2 focus:ring-blue-600 rounded-lg"
              >
                <div className="w-16 h-16 bg-white rounded-lg shadow-md flex items-center justify-center mx-auto mb-3 group-hover:scale-105 transition-transform">
                  <div className="w-8 h-8 bg-gray-300 rounded"></div>
                </div>
                <p className="text-sm text-gray-700">Legal Advisors</p>
              </a>
              <a
                href="/teams"
                className="text-center group focus:outline-none focus:ring-2 focus:ring-blue-600 rounded-lg"
              >
                <div className="w-16 h-16 bg-white rounded-lg shadow-md flex items-center justify-center mx-auto mb-3 group-hover:scale-105 transition-transform">
                  <div className="w-8 h-8 bg-gray-300 rounded"></div>
                </div>
                <p className="text-sm text-gray-700">Industry Experts</p>
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
