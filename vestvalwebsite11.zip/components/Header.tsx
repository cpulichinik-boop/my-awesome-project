"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import Image from "next/image"
import Link from "next/link"
import { usePathname } from "next/navigation"

const MenuIcon = () => (
  <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
  </svg>
)

const XIcon = () => (
  <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
  </svg>
)

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const pathname = usePathname()

  const navItems = [
    { href: "/services", label: "Services" },
    { href: "/industries", label: "Industries" },
    { href: "/case-studies", label: "Case Studies" },
    { href: "/insights", label: "Insights" },
    { href: "/careers", label: "Careers" },
    { href: "/about", label: "About" },
    { href: "/contact", label: "Contact" },
  ]

  const handleContactClick = () => {
    window.location.href = "mailto:contact@vestval.com?subject=Inquiry from Vestval Website"
  }

  return (
    <>
      <header className="fixed top-0 left-0 right-0 z-50 bg-white/80 supports-[backdrop-filter]:bg-white/60 backdrop-blur border-b border-gray-200">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-14">
            <div className="flex-shrink-0">
              <Link href="/" aria-label="Vestval home" className="flex items-center space-x-3">
                <div className="relative h-10 w-auto">
                  <Image
                    src="/vestval-logo.jpg"
                    alt="Vestval Logo"
                    width={120}
                    height={40}
                    className="h-10 w-auto object-contain"
                    priority
                  />
                </div>
                <span className="text-xl font-bold text-gray-900">Vestval</span>
              </Link>
            </div>

            <nav className="hidden lg:flex items-center space-x-6">
              {navItems.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`font-medium transition-colors duration-200 ${
                    pathname === item.href ? "text-gray-900" : "text-gray-600 hover:text-gray-900"
                  }`}
                >
                  {item.label}
                </Link>
              ))}

              <Button asChild className="px-4 py-2">
                <Link href="/get-started">Get Started</Link>
              </Button>
            </nav>

            <div className="lg:hidden">
              <Button variant="ghost" size="sm" onClick={() => setIsMenuOpen(!isMenuOpen)} className="text-gray-700">
                {isMenuOpen ? <XIcon /> : <MenuIcon />}
              </Button>
            </div>
          </div>

          {isMenuOpen && (
            <div className="lg:hidden">
              <div className="px-2 pt-2 pb-3 space-y-1 bg-white/80 supports-[backdrop-filter]:bg-white/60 backdrop-blur border-t border-gray-200">
                {navItems.map((item) => (
                  <Link
                    key={item.href}
                    href={item.href}
                    className={`block px-3 py-2 font-medium transition-colors duration-200 ${
                      pathname === item.href ? "text-gray-900" : "text-gray-600 hover:text-gray-900"
                    }`}
                    onClick={() => setIsMenuOpen(false)}
                  >
                    {item.label}
                  </Link>
                ))}

                <div className="px-3 py-2">
                  <Button asChild className="w-full px-4 py-2">
                    <Link href="/get-started">Get Started</Link>
                  </Button>
                </div>
              </div>
            </div>
          )}
        </div>
      </header>

      <div aria-hidden className="h-16" />
    </>
  )
}
