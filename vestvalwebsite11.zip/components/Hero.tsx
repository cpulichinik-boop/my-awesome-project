"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { ArrowRight } from "lucide-react"

export default function Hero() {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    setIsVisible(true)
  }, [])

  const handleContactClick = () => {
    window.location.href = "mailto:contact@vestval.com?subject=Inquiry from Vestval Website"
  }

  return (
    <section className="relative pt-20 pb-16 bg-gray-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className={`transition-all duration-700 ${isVisible ? "animate-fade-in-up" : "opacity-0"}`}>
          <div className="text-center max-w-4xl mx-auto">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 mb-5 leading-tight text-balance">
              Strategic advisory for IT, finance, and management
            </h1>
            <p className="text-lg sm:text-xl text-gray-700 mb-8 max-w-3xl mx-auto leading-relaxed text-pretty">
              We help CFOs, CIOs, and leaders deliver measurable outcomes—faster transformations, stronger cash flow,
              and durable operating efficiency.
            </p>

            {/* Single primary CTA */}
            <div className="flex justify-center mb-8">
              <Button
                asChild
                size="lg"
                className="bg-gradient-to-r from-blue-600 to-teal-500 text-white px-8 py-4 text-lg font-semibold"
              >
                <Link href="/contact">
                  Talk to an expert
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Link>
              </Button>
            </div>

            {/* High-scent task routing to three pillars */}
            <div className="mt-2 grid grid-cols-1 sm:grid-cols-3 gap-3 text-left">
              <Link
                href="/services/it-digital-transformation"
                className="rounded-md border border-gray-200 bg-white px-4 py-3 hover:border-blue-300 hover:bg-blue-50 transition-colors"
              >
                <div className="text-sm font-semibold text-gray-900">IT & Digital Transformation</div>
                <div className="text-sm text-gray-600">Modernize platforms, automation, security</div>
              </Link>
              <Link
                href="/services/finance-capital-advisory"
                className="rounded-md border border-gray-200 bg-white px-4 py-3 hover:border-blue-300 hover:bg-blue-50 transition-colors"
              >
                <div className="text-sm font-semibold text-gray-900">Finance/CFO Advisory</div>
                <div className="text-sm text-gray-600">Cash, capital, FP&A, value creation</div>
              </Link>
              <Link
                href="/services/management-consulting"
                className="rounded-md border border-gray-200 bg-white px-4 py-3 hover:border-blue-300 hover:bg-blue-50 transition-colors"
              >
                <div className="text-sm font-semibold text-gray-900">Management Consulting</div>
                <div className="text-sm text-gray-600">Strategy, operations, governance</div>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
