"use client"

import { useState } from "react"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Search, MessageCircle, HelpCircle } from "lucide-react"

const faqData = [
  {
    id: "1",
    category: "General",
    question: "What makes Vestval different from other consulting firms?",
    answer:
      "Vestval operates as an advisory-only firm, free from regulatory complexities like NBFC constraints. This independence allows us to provide unbiased recommendations and maintain the highest standards of professional integrity. Our multidisciplinary approach combines technology, finance, and strategic management expertise to deliver comprehensive solutions.",
  },
  {
    id: "2",
    category: "Services",
    question: "Do you provide services to startups and small businesses?",
    answer:
      "Yes, we work with businesses of all sizes, from startups to large enterprises. Our advisory approach is scalable and customized to match your company's stage, budget, and growth objectives. We offer flexible engagement models including project-based consulting and ongoing advisory relationships.",
  },
  {
    id: "3",
    category: "Technology",
    question: "How do you approach digital transformation projects?",
    answer:
      "Our digital transformation methodology follows a structured approach: assessment of current state, strategy development, technology selection, implementation planning, and change management. We focus on ROI-driven solutions that align with your business objectives and ensure sustainable adoption across your organization.",
  },
  {
    id: "4",
    category: "Finance",
    question: "What is included in your Capital Advisory services?",
    answer:
      "Our Capital Advisory services include capital structure optimization, financial planning and analysis, investor relations support, debt structuring, fundraising assistance, and strategic financial planning. We also provide CFO-level expertise for companies that need senior financial leadership without full-time commitment.",
  },
  {
    id: "5",
    category: "Process",
    question: "What is your typical engagement timeline?",
    answer:
      "Engagement timelines vary based on project scope and complexity. Strategic assessments typically take 2-4 weeks, implementation projects range from 3-12 months, and ongoing advisory relationships can span multiple years. We provide detailed project timelines during our initial consultation.",
  },
  {
    id: "6",
    category: "Investment",
    question: "How do you structure your fees and pricing?",
    answer:
      "We offer flexible pricing models including fixed-fee projects, retainer-based advisory relationships, and success-based compensation structures. Our fees are competitive and aligned with the value we deliver. We provide transparent pricing during our initial consultation based on your specific requirements.",
  },
  {
    id: "7",
    category: "Global",
    question: "Do you work with international clients?",
    answer:
      "Yes, we serve clients globally with particular expertise in cross-border transactions, international market entry, and global expansion strategies. Our team has experience across 30+ countries and can navigate complex international regulatory and cultural considerations.",
  },
  {
    id: "8",
    category: "Technology",
    question: "Can you help with AI and machine learning implementation?",
    answer:
      "Absolutely. We provide comprehensive AI/ML advisory services including use case identification, technology selection, implementation strategy, and change management. Our approach focuses on practical applications that deliver measurable business value rather than technology for technology's sake.",
  },
  {
    id: "9",
    category: "Process",
    question: "How do you measure success in your engagements?",
    answer:
      "We establish clear success metrics at the beginning of each engagement, including financial KPIs, operational improvements, and strategic milestones. We provide regular progress reports and conduct post-implementation reviews to ensure sustained value delivery and continuous improvement.",
  },
  {
    id: "10",
    category: "Services",
    question: "Do you provide ongoing support after project completion?",
    answer:
      "Yes, we offer various post-implementation support options including ongoing advisory relationships, periodic health checks, and additional training. Our goal is to ensure long-term success and we're committed to supporting our clients' continued growth and evolution.",
  },
]

const categories = ["All", "General", "Services", "Technology", "Finance", "Process", "Investment", "Global"]

export default function InteractiveFAQ() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("All")
  const [openItems, setOpenItems] = useState<string[]>([])

  const filteredFAQs = faqData.filter((faq) => {
    const matchesSearch =
      faq.question.toLowerCase().includes(searchTerm.toLowerCase()) ||
      faq.answer.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = selectedCategory === "All" || faq.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  const handleAccordionChange = (value: string[]) => {
    setOpenItems(value)
  }

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-4">
            <HelpCircle className="h-8 w-8 text-blue-600 mr-3" />
            <h2 className="text-3xl md:text-4xl font-bold">Frequently Asked Questions</h2>
          </div>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Find answers to common questions about our services, processes, and approach
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          {/* Search and Filter */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Search className="h-5 w-5" />
                <span>Search & Filter</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search questions and answers..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>

              <div className="flex flex-wrap gap-2">
                {categories.map((category) => (
                  <Button
                    key={category}
                    variant={selectedCategory === category ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedCategory(category)}
                    className="text-sm"
                  >
                    {category}
                    {category !== "All" && (
                      <Badge variant="secondary" className="ml-2 text-xs">
                        {faqData.filter((faq) => faq.category === category).length}
                      </Badge>
                    )}
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Results count */}
          <div className="mb-6 text-sm text-gray-600">
            Showing {filteredFAQs.length} of {faqData.length} questions
            {searchTerm && ` for "${searchTerm}"`}
            {selectedCategory !== "All" && ` in ${selectedCategory}`}
          </div>

          {/* FAQ Accordion */}
          {filteredFAQs.length > 0 ? (
            <Accordion type="multiple" value={openItems} onValueChange={handleAccordionChange} className="space-y-4">
              {filteredFAQs.map((faq) => (
                <AccordionItem
                  key={faq.id}
                  value={faq.id}
                  className="bg-white rounded-lg border shadow-sm hover:shadow-md transition-shadow"
                >
                  <AccordionTrigger className="px-6 py-4 text-left hover:no-underline">
                    <div className="flex items-start space-x-3 w-full">
                      <Badge variant="outline" className="text-xs mt-1">
                        {faq.category}
                      </Badge>
                      <span className="font-medium text-gray-900 flex-1">{faq.question}</span>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="px-6 pb-4">
                    <div className="text-gray-700 leading-relaxed pl-16">{faq.answer}</div>
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          ) : (
            <Card>
              <CardContent className="text-center py-12">
                <MessageCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">No questions found</h3>
                <p className="text-gray-600 mb-4">Try adjusting your search terms or category filter</p>
                <Button
                  variant="outline"
                  onClick={() => {
                    setSearchTerm("")
                    setSelectedCategory("All")
                  }}
                >
                  Clear Filters
                </Button>
              </CardContent>
            </Card>
          )}

          {/* Contact CTA */}
          <Card className="mt-8 bg-gradient-to-r from-blue-600 to-teal-500 text-white">
            <CardContent className="text-center py-8">
              <h3 className="text-xl font-bold mb-2">Still have questions?</h3>
              <p className="mb-4 opacity-90">Our team is here to help. Get in touch for personalized answers.</p>
              <Button
                variant="secondary"
                className="bg-white text-blue-600 hover:bg-gray-100"
                onClick={() =>
                  (window.location.href = "mailto:contact@vestval.com?subject=FAQ Inquiry from Vestval Website")
                }
              >
                Contact Our Experts
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}
