"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CheckCircle, ArrowRight, Calculator, TrendingUp, Users, Zap } from "lucide-react"
import { Checkbox } from "@/components/ui/checkbox"

const services = {
  "it-transformation": {
    title: "IT & Digital Transformation",
    icon: <Zap className="h-6 w-6" />,
    description: "Modernize your technology stack and digital processes",
    features: [
      "Cloud Migration & Architecture",
      "AI/ML Implementation",
      "Cybersecurity Enhancement",
      "Digital Process Automation",
      "Mobile & Web Development",
    ],
    estimatedTimeline: "3-12 months",
    investmentRange: "$50K - $500K",
    roi: "30-120%",
  },
  "capital-advisory": {
    title: "Capital Advisory & CFO Services",
    icon: <TrendingUp className="h-6 w-6" />,
    description: "Strategic financial planning and capital optimization",
    features: [
      "Capital Structure Optimization",
      "Financial Planning & Analysis",
      "Investor Relations",
      "Risk Management",
      "Performance Metrics",
    ],
    estimatedTimeline: "2-6 months",
    investmentRange: "$25K - $200K",
    roi: "20-100%",
  },
  "management-consulting": {
    title: "Management Consulting",
    icon: <Users className="h-6 w-6" />,
    description: "Transform operations and drive strategic growth",
    features: [
      "Strategic Planning",
      "Operational Excellence",
      "Change Management",
      "Market Entry Strategy",
      "Performance Improvement",
    ],
    estimatedTimeline: "1-8 months",
    investmentRange: "$30K - $300K",
    roi: "15-80%",
  },
}

export default function InteractiveServiceSelector() {
  const [selectedService, setSelectedService] = useState<keyof typeof services>("it-transformation")
  const [companySize, setCompanySize] = useState<string>("medium")
  const [budget, setBudget] = useState<string>("100k-500k")
  const [disclaimerAcknowledged, setDisclaimerAcknowledged] = useState<boolean>(false)
  const [ackEstimates, setAckEstimates] = useState<boolean>(false)

  const getRecommendation = () => {
    const service = services[selectedService]
    let recommendation = `Based on your selection, ${service.title} is an excellent choice. `

    if (companySize === "startup") {
      recommendation += "As a startup, focus on scalable solutions that grow with your business. "
    } else if (companySize === "enterprise") {
      recommendation += "For enterprise scale, we recommend comprehensive transformation programs. "
    } else {
      recommendation += "For mid-market companies, we suggest phased implementation approaches. "
    }

    return recommendation + `Expected ROI: ${service.roi} within ${service.estimatedTimeline}.`
  }

  return (
    <section className="py-16 bg-gradient-to-br from-blue-50 to-teal-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-4">
            <Calculator className="h-8 w-8 text-blue-600 mr-3" />
            <h2 className="text-3xl md:text-4xl font-bold">Service Selector</h2>
          </div>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Find the perfect advisory service for your business needs and get personalized recommendations
          </p>
        </div>

        <div className="max-w-6xl mx-auto">
          <Tabs value={selectedService} onValueChange={(value) => setSelectedService(value as keyof typeof services)}>
            <TabsList className="grid w-full grid-cols-3 mb-8">
              {Object.entries(services).map(([key, service]) => (
                <TabsTrigger key={key} value={key} className="flex items-center space-x-2">
                  {service.icon}
                  <span className="hidden sm:inline">{service.title.split(" ")[0]}</span>
                </TabsTrigger>
              ))}
            </TabsList>

            {Object.entries(services).map(([key, service]) => (
              <TabsContent key={key} value={key}>
                <div className="grid lg:grid-cols-2 gap-8">
                  <Card className="hover-lift">
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-3">
                        <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-teal-500 rounded-lg flex items-center justify-center text-white">
                          {service.icon}
                        </div>
                        <div>
                          <h3 className="text-2xl">{service.title}</h3>
                          <p className="text-gray-600 font-normal">{service.description}</p>
                        </div>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div>
                          <h4 className="font-semibold mb-2">Key Features:</h4>
                          <ul className="space-y-2">
                            {service.features.map((feature, idx) => (
                              <li key={idx} className="flex items-center space-x-2">
                                <CheckCircle className="h-4 w-4 text-green-500" />
                                <span className="text-sm">{feature}</span>
                              </li>
                            ))}
                          </ul>
                        </div>

                        <div className="grid grid-cols-3 gap-4 pt-4 border-t">
                          <div className="text-center">
                            <div className="text-sm text-gray-500">Timeline</div>
                            <div className="font-semibold">{service.estimatedTimeline}</div>
                          </div>
                          <div className="text-center">
                            <div className="text-sm text-gray-500">Investment</div>
                            <div className="font-semibold">{service.investmentRange}</div>
                          </div>
                          <div className="text-center">
                            <div className="text-sm text-gray-500">Expected ROI</div>
                            <div className="font-semibold text-green-600">{service.roi}</div>
                          </div>
                        </div>
                        <div className="text-xs text-gray-500 mt-2">
                          Estimates are illustrative and not guarantees; actual outcomes vary by scope, baseline, and
                          execution.
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="bg-white">
                    <CardHeader>
                      <CardTitle>Customize Your Recommendation</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      <div>
                        <label className="block text-sm font-medium mb-2">Company Size</label>
                        <div className="grid grid-cols-3 gap-2">
                          {[
                            { value: "startup", label: "Startup" },
                            { value: "medium", label: "Mid-Market" },
                            { value: "enterprise", label: "Enterprise" },
                          ].map((size) => (
                            <Button
                              key={size.value}
                              variant={companySize === size.value ? "default" : "outline"}
                              size="sm"
                              onClick={() => setCompanySize(size.value)}
                              className="text-xs"
                            >
                              {size.label}
                            </Button>
                          ))}
                        </div>
                      </div>

                      <div>
                        <label className="block text-sm font-medium mb-2">Budget Range</label>
                        <div className="grid grid-cols-2 gap-2">
                          {[
                            { value: "50k-100k", label: "$50K-$100K" },
                            { value: "100k-500k", label: "$100K-$500K" },
                            { value: "500k-1m", label: "$500K-$1M" },
                            { value: "1m+", label: "$1M+" },
                          ].map((budgetRange) => (
                            <Button
                              key={budgetRange.value}
                              variant={budget === budgetRange.value ? "default" : "outline"}
                              size="sm"
                              onClick={() => setBudget(budgetRange.value)}
                              className="text-xs"
                            >
                              {budgetRange.label}
                            </Button>
                          ))}
                        </div>
                      </div>

                      <div className="bg-blue-50 p-4 rounded-lg">
                        <h4 className="font-semibold mb-2 flex items-center">
                          <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                          Personalized Recommendation
                        </h4>
                        {!ackEstimates ? (
                          <div className="space-y-3">
                            <p className="text-sm text-gray-700">
                              To view a tailored recommendation, please acknowledge the disclaimer below.
                            </p>
                            <label className="flex items-center gap-2 text-sm">
                              <Checkbox
                                id="ack"
                                checked={ackEstimates}
                                onCheckedChange={(v) => setAckEstimates(Boolean(v))}
                              />
                              <span>I understand these are illustrative estimates and not guarantees.</span>
                            </label>
                          </div>
                        ) : (
                          <p className="text-sm text-gray-700 mb-4">{getRecommendation()}</p>
                        )}
                        <p className="text-xs text-gray-600 mt-2">
                          Estimates are illustrative and depend on scope, baseline, and execution; not a guarantee of
                          future results.
                        </p>
                        <details className="mt-2">
                          <summary className="text-sm text-blue-700 cursor-pointer">How we estimate</summary>
                          <div className="text-xs text-gray-600 mt-1">
                            Ranges assume phased delivery, typical mid-market baselines, and standard risk controls;
                            programs and special cases may vary.
                          </div>
                        </details>
                        <Button
                          className="w-full bg-gradient-to-r from-blue-600 to-teal-500 mt-4"
                          disabled={!ackEstimates}
                        >
                          Request scoped proposal
                          <ArrowRight className="h-4 w-4 ml-2" />
                        </Button>
                      </div>

                      <div className="mt-6">
                        <Checkbox
                          checked={disclaimerAcknowledged}
                          onCheckedChange={(checked) => setDisclaimerAcknowledged(checked as boolean)}
                        >
                          I acknowledge the disclaimer
                        </Checkbox>
                      </div>

                      <div className="mt-6">
                        <Checkbox
                          checked={ackEstimates}
                          onCheckedChange={(checked) => setAckEstimates(checked as boolean)}
                        >
                          I acknowledge the estimates
                        </Checkbox>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
            ))}
          </Tabs>
        </div>
      </div>
    </section>
  )
}
