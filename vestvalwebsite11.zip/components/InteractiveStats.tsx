"use client"

import Link from "next/link"

interface StatItem {
  value: string
  label: string
}

const stats: StatItem[] = [
  { value: "500+", label: "Projects Completed" },
  { value: "98%", label: "Client Satisfaction" },
  { value: "50+", label: "Countries Served" },
  { value: "$1B+", label: "Value Created" },
]

export default function InteractiveStats() {
  return (
    <section className="py-10 bg-white border-t border-b border-gray-100">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 items-center">
          {stats.map((s, i) => (
            <div key={i} className="text-center">
              <div className="text-3xl md:text-4xl font-bold text-gray-900">{s.value}</div>
              <div className="text-sm md:text-base text-gray-600">{s.label}</div>
            </div>
          ))}
        </div>
        <div className="mt-6 text-center">
          <Link href="/case-studies" className="text-sm font-medium text-blue-700 hover:text-blue-800 underline">
            See our case studies
          </Link>
        </div>
      </div>
    </section>
  )
}
