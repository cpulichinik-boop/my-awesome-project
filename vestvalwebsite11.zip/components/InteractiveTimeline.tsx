"use client"

import type React from "react"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { CheckCircle, Circle, TrendingUp, Users, Globe, Award } from "lucide-react"

interface TimelineEvent {
  year: string
  title: string
  description: string
  icon: React.ReactNode
  achievements: string[]
}

const timelineEvents: TimelineEvent[] = [
  {
    year: "2010",
    title: "Foundation & Vision",
    description: "Vestval was founded with a mission to transform businesses through strategic advisory services.",
    icon: <Circle className="w-6 h-6" />,
    achievements: [
      "Established core consulting framework",
      "Built founding team of 5 experts",
      "Secured first 10 enterprise clients",
    ],
  },
  {
    year: "2013",
    title: "Global Expansion",
    description: "Extended our reach across continents, establishing key partnerships and regional offices.",
    icon: <Globe className="w-6 h-6" />,
    achievements: ["Opened offices in 3 continents", "Formed strategic partnerships", "Reached 50+ countries served"],
  },
  {
    year: "2016",
    title: "Digital Transformation",
    description: "Led the industry in digital transformation consulting, helping clients navigate the digital age.",
    icon: <TrendingUp className="w-6 h-6" />,
    achievements: [
      "Launched digital transformation practice",
      "Completed 100+ digital projects",
      "Achieved 95% client retention rate",
    ],
  },
  {
    year: "2019",
    title: "Team Excellence",
    description:
      "Expanded our expert team and established specialized practice areas for comprehensive service delivery.",
    icon: <Users className="w-6 h-6" />,
    achievements: ["Grew to 200+ consultants", "Established 6 practice areas", "Won 'Consulting Firm of the Year'"],
  },
  {
    year: "2022",
    title: "Industry Recognition",
    description: "Recognized as a leading global advisory firm with multiple industry awards and certifications.",
    icon: <Award className="w-6 h-6" />,
    achievements: [
      "Ranked Top 10 Global Consulting Firm",
      "Achieved ISO certifications",
      "Completed 500+ successful projects",
    ],
  },
  {
    year: "2024",
    title: "Future Forward",
    description: "Continuing to innovate and lead in AI-driven consulting and sustainable business transformation.",
    icon: <CheckCircle className="w-6 h-6" />,
    achievements: [
      "Launched AI consulting practice",
      "Achieved carbon-neutral operations",
      "Expanded to 50+ countries",
    ],
  },
]

export default function InteractiveTimeline() {
  const [selectedEvent, setSelectedEvent] = useState<number>(0)

  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4 gradient-text">Our Journey of Excellence</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Discover the milestones that shaped Vestval into the global advisory leader we are today
          </p>
        </div>

        <div className="max-w-6xl mx-auto">
          {/* Timeline Navigation */}
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            {timelineEvents.map((event, index) => (
              <Button
                key={index}
                variant={selectedEvent === index ? "default" : "outline"}
                onClick={() => setSelectedEvent(index)}
                className={`px-6 py-3 ${selectedEvent === index ? "gradient-bg text-white" : "hover:border-blue-500"}`}
              >
                {event.year}
              </Button>
            ))}
          </div>

          {/* Timeline Content */}
          <div className="relative">
            <Card className="p-8 hover-lift">
              <div className="flex items-start gap-6">
                <div className="flex-shrink-0">
                  <div className="w-16 h-16 rounded-full gradient-bg flex items-center justify-center text-white">
                    {timelineEvents[selectedEvent].icon}
                  </div>
                </div>

                <div className="flex-1">
                  <div className="flex items-center gap-4 mb-4">
                    <span className="text-3xl font-bold gradient-text">{timelineEvents[selectedEvent].year}</span>
                    <h3 className="text-2xl font-bold">{timelineEvents[selectedEvent].title}</h3>
                  </div>

                  <p className="text-lg text-muted-foreground mb-6">{timelineEvents[selectedEvent].description}</p>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {timelineEvents[selectedEvent].achievements.map((achievement, index) => (
                      <div key={index} className="flex items-center gap-3 p-4 bg-muted/50 rounded-lg">
                        <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                        <span className="text-sm font-medium">{achievement}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </Card>
          </div>

          {/* Progress Indicator */}
          <div className="flex justify-center mt-8">
            <div className="flex gap-2">
              {timelineEvents.map((_, index) => (
                <div
                  key={index}
                  className={`w-3 h-3 rounded-full transition-colors ${
                    index === selectedEvent ? "bg-blue-500" : "bg-gray-300"
                  }`}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
