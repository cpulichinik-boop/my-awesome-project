"use client"

export default function LoadingSpinner() {
  return (
    <div className="fixed inset-0 bg-white z-50 flex items-center justify-center">
      <div className="relative">
        <div className="w-16 h-16 border-4 border-gray-200 rounded-full animate-spin">
          <div className="absolute top-0 left-0 w-16 h-16 border-4 border-transparent border-t-primary rounded-full animate-spin"></div>
        </div>
        <div className="mt-4 text-center">
          <div className="text-lg font-semibold gradient-text">Vestval</div>
          <div className="text-sm text-gray-600">Loading...</div>
        </div>
      </div>
    </div>
  )
}
