"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Checkbox } from "@/components/ui/checkbox"
import { Badge } from "@/components/ui/badge"
import { Mail, CheckCircle, AlertCircle, TrendingUp, Users, Zap } from "lucide-react"

const interests = [
  { id: "it-transformation", label: "IT & Digital Transformation", icon: <Zap className="h-4 w-4" /> },
  { id: "capital-advisory", label: "Capital Advisory & CFO Services", icon: <TrendingUp className="h-4 w-4" /> },
  { id: "management-consulting", label: "Management Consulting", icon: <Users className="h-4 w-4" /> },
  { id: "industry-insights", label: "Industry Insights & Trends", icon: <Mail className="h-4 w-4" /> },
  { id: "case-studies", label: "Success Stories & Case Studies", icon: <CheckCircle className="h-4 w-4" /> },
  { id: "events", label: "Events & Webinars", icon: <AlertCircle className="h-4 w-4" /> },
]

export default function NewsletterSignup() {
  const [email, setEmail] = useState("")
  const [firstName, setFirstName] = useState("")
  const [company, setCompany] = useState("")
  const [selectedInterests, setSelectedInterests] = useState<string[]>([])
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [errors, setErrors] = useState<{ [key: string]: string }>({})

  const validateForm = () => {
    const newErrors: { [key: string]: string } = {}

    if (!firstName.trim()) {
      newErrors.firstName = "First name is required"
    }

    if (!email.trim()) {
      newErrors.email = "Email is required"
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      newErrors.email = "Please enter a valid email address"
    }

    if (!company.trim()) {
      newErrors.company = "Company name is required"
    }

    if (selectedInterests.length === 0) {
      newErrors.interests = "Please select at least one area of interest"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleInterestToggle = (interestId: string) => {
    setSelectedInterests((prev) =>
      prev.includes(interestId) ? prev.filter((id) => id !== interestId) : [...prev, interestId],
    )
    if (errors.interests) {
      setErrors((prev) => ({ ...prev, interests: "" }))
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateForm()) return

    setIsSubmitting(true)

    const interestLabels = selectedInterests.map((id) => interests.find((i) => i.id === id)?.label).join(", ")
    const subject = `Newsletter Subscription Request from ${firstName} - ${company}`
    const body = `Name: ${firstName}%0D%0ACompany: ${company}%0D%0AEmail: ${email}%0D%0A%0D%0AInterests:%0D%0A${interestLabels}%0D%0A%0D%0APlease add me to the Vestval newsletter for the selected topics.`

    // Open email client with pre-filled information
    window.location.href = `mailto:newsletter@vestval.com?subject=${subject}&body=${body}`

    // Show success state after a brief delay
    setTimeout(() => {
      setIsSubmitted(true)
      setIsSubmitting(false)
    }, 1000)
  }

  if (isSubmitted) {
    return (
      <section className="py-16 bg-gradient-to-br from-green-50 to-blue-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl mx-auto">
            <Card className="text-center">
              <CardContent className="py-12">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <CheckCircle className="h-8 w-8 text-green-600" />
                </div>
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Thank You for Your Interest!</h2>
                <p className="text-gray-600 mb-6">
                  Your subscription request has been sent to our team, {firstName}! We'll process your request and add
                  you to our newsletter for your selected interests.
                </p>
                <div className="flex flex-wrap justify-center gap-2 mb-6">
                  {selectedInterests.map((interestId) => {
                    const interest = interests.find((i) => i.id === interestId)
                    return interest ? (
                      <Badge key={interestId} variant="secondary" className="flex items-center space-x-1">
                        {interest.icon}
                        <span>{interest.label}</span>
                      </Badge>
                    ) : null
                  })}
                </div>
                <p className="text-sm text-gray-500">
                  You'll receive a confirmation email shortly, followed by your first insights digest.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    )
  }

  return (
    <section className="py-16 bg-gradient-to-br from-blue-50 to-teal-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl mx-auto">
          <Card>
            <CardHeader className="text-center">
              <div className="w-16 h-16 bg-gradient-to-r from-blue-600 to-teal-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <Mail className="h-8 w-8 text-white" />
              </div>
              <CardTitle className="text-2xl md:text-3xl">Stay Ahead with Vestval Insights</CardTitle>
              <p className="text-gray-600 mt-2">
                Get exclusive industry insights, case studies, and strategic advice delivered to your inbox
              </p>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="firstName" className="block text-sm font-medium text-gray-700 mb-1">
                      First Name *
                    </label>
                    <Input
                      id="firstName"
                      type="text"
                      value={firstName}
                      onChange={(e) => {
                        setFirstName(e.target.value)
                        if (errors.firstName) setErrors((prev) => ({ ...prev, firstName: "" }))
                      }}
                      className={errors.firstName ? "border-red-500" : ""}
                      placeholder="Enter your first name"
                    />
                    {errors.firstName && <p className="text-red-500 text-xs mt-1">{errors.firstName}</p>}
                  </div>

                  <div>
                    <label htmlFor="company" className="block text-sm font-medium text-gray-700 mb-1">
                      Company *
                    </label>
                    <Input
                      id="company"
                      type="text"
                      value={company}
                      onChange={(e) => {
                        setCompany(e.target.value)
                        if (errors.company) setErrors((prev) => ({ ...prev, company: "" }))
                      }}
                      className={errors.company ? "border-red-500" : ""}
                      placeholder="Your company name"
                    />
                    {errors.company && <p className="text-red-500 text-xs mt-1">{errors.company}</p>}
                  </div>
                </div>

                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                    Email Address *
                  </label>
                  <Input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => {
                      setEmail(e.target.value)
                      if (errors.email) setErrors((prev) => ({ ...prev, email: "" }))
                    }}
                    className={errors.email ? "border-red-500" : ""}
                    placeholder="your.email@company.com"
                  />
                  {errors.email && <p className="text-red-500 text-xs mt-1">{errors.email}</p>}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-3">
                    Areas of Interest * <span className="text-gray-500">(Select all that apply)</span>
                  </label>
                  <div className="grid md:grid-cols-2 gap-3">
                    {interests.map((interest) => (
                      <div key={interest.id} className="flex items-center space-x-2">
                        <Checkbox
                          id={interest.id}
                          checked={selectedInterests.includes(interest.id)}
                          onCheckedChange={() => handleInterestToggle(interest.id)}
                        />
                        <label
                          htmlFor={interest.id}
                          className="text-sm text-gray-700 cursor-pointer flex items-center space-x-2"
                        >
                          {interest.icon}
                          <span>{interest.label}</span>
                        </label>
                      </div>
                    ))}
                  </div>
                  {errors.interests && <p className="text-red-500 text-xs mt-1">{errors.interests}</p>}
                </div>

                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-medium text-gray-900 mb-2">What you'll receive:</h4>
                  <ul className="text-sm text-gray-600 space-y-1">
                    <li>• Weekly industry insights and market analysis</li>
                    <li>• Exclusive case studies and success stories</li>
                    <li>• Invitations to webinars and events</li>
                    <li>• Strategic frameworks and best practices</li>
                    <li>• Early access to research reports</li>
                  </ul>
                </div>

                <Button
                  type="submit"
                  className="w-full bg-gradient-to-r from-blue-600 to-teal-500 hover:opacity-90"
                  disabled={isSubmitting}
                >
                  {isSubmitting ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                      Processing...
                    </>
                  ) : (
                    <>
                      Subscribe to Vestval Insights
                      <Mail className="h-4 w-4 ml-2" />
                    </>
                  )}
                </Button>

                <p className="text-xs text-gray-500 text-center">
                  By subscribing, you agree to receive marketing emails from Vestval. You can unsubscribe at any time.
                  We respect your privacy and will never share your information.
                </p>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}
