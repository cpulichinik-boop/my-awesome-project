"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Check, X, Star, ArrowRight } from "lucide-react"

interface ServiceTier {
  name: string
  description: string
  price: string
  popular?: boolean
  features: {
    name: string
    included: boolean
    premium?: boolean
  }[]
  cta: string
  emailSubject: string
}

const serviceTiers: ServiceTier[] = [
  {
    name: "Discovery",
    description: "Deep-dive discovery and scoped roadmap",
    price: "Scoped",
    features: [
      { name: "Strategic Planning", included: true },
      { name: "Market Analysis", included: true },
      { name: "Competitive Intelligence", included: true },
      { name: "Growth Strategy", included: true },
      { name: "Digital Transformation", included: false },
      { name: "M&A Advisory", included: false },
      { name: "24/7 Support", included: false },
      { name: "Dedicated Team", included: false },
    ],
    cta: "Request scoped proposal",
    emailSubject: "Discovery Engagement Inquiry",
  },
  {
    name: "Program",
    description: "Phased delivery program with measurable outcomes",
    price: "Scoped",
    popular: true,
    features: [
      { name: "Strategic Planning", included: true },
      { name: "Market Analysis", included: true },
      { name: "Competitive Intelligence", included: true },
      { name: "Growth Strategy", included: true },
      { name: "Digital Transformation", included: true, premium: true },
      { name: "M&A Advisory", included: true, premium: true },
      { name: "24/7 Support", included: true, premium: true },
      { name: "Dedicated Team", included: false },
    ],
    cta: "Request scoped proposal",
    emailSubject: "Program Engagement Inquiry",
  },
  {
    name: "Partnership",
    description: "Long-term advisory partnership with embedded team",
    price: "Scoped",
    features: [
      { name: "Strategic Planning", included: true },
      { name: "Market Analysis", included: true },
      { name: "Competitive Intelligence", included: true },
      { name: "Growth Strategy", included: true },
      { name: "Digital Transformation", included: true, premium: true },
      { name: "M&A Advisory", included: true, premium: true },
      { name: "24/7 Support", included: true, premium: true },
      { name: "Dedicated Team", included: true, premium: true },
    ],
    cta: "Request scoped proposal",
    emailSubject: "Partnership Engagement Inquiry",
  },
]

export default function ServiceComparison() {
  const [hoveredTier, setHoveredTier] = useState<number | null>(null)

  const handleTierClick = (tier: ServiceTier) => {
    const body = `I'm interested in learning more about the ${tier.name} service tier.%0D%0A%0D%0AService: ${tier.name}%0D%0ADescription: ${tier.description}%0D%0APricing: ${tier.price}%0D%0A%0D%0APlease contact me to discuss how this service can help my business.`
    window.location.href = `mailto:sales@vestval.com?subject=${tier.emailSubject}&body=${body}`
  }

  return (
    <section className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4 gradient-text">Engagement Models</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Explore how we can work together: Discovery, Program, and Partnership—each scoped to your goals.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {serviceTiers.map((tier, index) => (
            <Card
              key={index}
              className={`relative p-8 transition-all duration-300 ${
                tier.popular ? "border-2 border-blue-500 shadow-xl scale-105" : "border hover:border-blue-300"
              } ${hoveredTier === index ? "shadow-2xl transform -translate-y-2" : ""}`}
              onMouseEnter={() => setHoveredTier(index)}
              onMouseLeave={() => setHoveredTier(null)}
            >
              {tier.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <Badge className="gradient-bg text-white px-4 py-1 flex items-center gap-1">
                    <Star className="w-4 h-4" />
                    Most Popular
                  </Badge>
                </div>
              )}

              <div className="text-center mb-8">
                <h3 className="text-2xl font-bold mb-2">{tier.name}</h3>
                <p className="text-muted-foreground mb-4">{tier.description}</p>
                <div className="text-3xl font-bold gradient-text">{tier.price}</div>
              </div>

              <div className="space-y-4 mb-8">
                {tier.features.map((feature, featureIndex) => (
                  <div key={featureIndex} className="flex items-center gap-3">
                    {feature.included ? (
                      <Check className={`w-5 h-5 ${feature.premium ? "text-yellow-500" : "text-green-500"}`} />
                    ) : (
                      <X className="w-5 h-5 text-gray-400" />
                    )}
                    <span
                      className={`${
                        feature.included ? "text-foreground" : "text-muted-foreground"
                      } ${feature.premium ? "font-semibold" : ""}`}
                    >
                      {feature.name}
                      {feature.premium && (
                        <Badge variant="outline" className="ml-2 text-xs">
                          Premium
                        </Badge>
                      )}
                    </span>
                  </div>
                ))}
              </div>

              <Button
                onClick={() => handleTierClick(tier)}
                className={`w-full ${
                  tier.popular
                    ? "gradient-bg text-white hover:opacity-90"
                    : "border-2 border-blue-500 text-blue-500 hover:gradient-bg hover:text-white"
                } transition-all duration-300 group`}
                size="lg"
              >
                {tier.cta}
                <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <p className="text-muted-foreground mb-4">Need a custom solution? We're here to help.</p>
          <Button
            variant="outline"
            size="lg"
            onClick={() =>
              (window.location.href = "mailto:contact@vestval.com?subject=Custom Solution Inquiry from Vestval Website")
            }
          >
            Contact Our Experts
          </Button>
        </div>
      </div>
    </section>
  )
}
