"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"

const SmartphoneIcon = () => (
  <svg className="h-8 w-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M12 18h.01M8 21h8a1 1 0 001-1V4a1 1 0 00-1-1H8a1 1 0 00-1 1v16a1 1 0 001 1z"
    />
  </svg>
)

const DollarSignIcon = () => (
  <svg className="h-8 w-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1"
    />
  </svg>
)

const TargetIcon = () => (
  <svg className="h-8 w-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
    />
  </svg>
)

const ArrowRightIcon = () => (
  <svg
    className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform duration-300"
    fill="none"
    viewBox="0 0 24 24"
    stroke="currentColor"
  >
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
  </svg>
)

export default function Services() {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 },
    )

    const element = document.getElementById("services")
    if (element) observer.observe(element)

    return () => observer.disconnect()
  }, [])

  const services = [
    {
      title: "IT & Digital Transformation",
      description:
        "Harness the power of technology to streamline operations, enhance customer experience, and drive innovation at scale with our comprehensive digital solutions.",
      icon: SmartphoneIcon,
      features: [
        "Mobile & Web Application Development with UX/UI excellence",
        "Artificial Intelligence & Automation Solutions",
        "Cloud Infrastructure & Security (scalable, compliant)",
        "Quality Assurance & Security Testing",
        "Digital Strategy & Technology Roadmapping",
      ],
      color: "from-blue-500 to-blue-600",
      href: "/services/it-digital-transformation",
    },
    {
      title: "Finance & Capital Advisory",
      description:
        "Expert CFO advisory services offering debt structuring, capital raising, and strategic financial planning to optimize your financial performance.",
      icon: DollarSignIcon,
      features: [
        "CFO Services & Strategic Financial Planning",
        "Debt Structuring and Capital Raising Advisory",
        "Financial Reporting Excellence & Compliance",
        "Access to Industry-Specific Financial Experts",
        "Global Financial Networks & Partnerships",
      ],
      color: "from-green-500 to-green-600",
      href: "/services/finance-capital-advisory",
    },
    {
      title: "Management Consulting",
      description:
        "Business growth strategy and operational excellence with market entry advisory and risk management for sustainable competitive advantage.",
      icon: TargetIcon,
      features: [
        "Business Growth Strategy & Operational Excellence",
        "Market Entry & Expansion Advisory",
        "Risk Management & Compliance Frameworks",
        "Governance & Performance Improvement",
        "Strategic Business Transformation",
      ],
      color: "from-purple-500 to-purple-600",
      href: "/services/management-consulting",
    },
  ]

  return (
    <section id="services" className="py-20 lg:py-32 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className={`transition-all duration-1000 ${isVisible ? "animate-fade-in-up" : "opacity-0"}`}>
          {/* Section header */}
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
              Our Core{" "}
              <span className="bg-gradient-to-r from-blue-600 to-teal-500 bg-clip-text text-transparent">Services</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Three pillars of excellence designed to accelerate growth, optimize operations, and maximize value across
              every aspect of your business transformation journey.
            </p>
          </div>

          {/* Services grid - Now featuring only 3 main services */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-16">
            {services.map((service, index) => (
              <Card
                key={index}
                className={`border-0 shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-3 group ${
                  isVisible ? "animate-fade-in-up" : "opacity-0"
                }`}
                style={{ animationDelay: `${index * 150}ms` }}
              >
                <CardHeader className="pb-4">
                  <div
                    className={`w-16 h-16 rounded-xl bg-gradient-to-r ${service.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300`}
                  >
                    <service.icon />
                  </div>
                  <CardTitle className="text-xl font-bold text-gray-900 group-hover:text-blue-600 transition-colors duration-300">
                    {service.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-6 leading-relaxed">{service.description}</p>
                  <ul className="space-y-2 mb-6">
                    {service.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-start text-sm text-gray-600">
                        <div className="w-1.5 h-1.5 bg-gradient-to-r from-blue-600 to-teal-500 rounded-full mr-3 flex-shrink-0 mt-2"></div>
                        {feature}
                      </li>
                    ))}
                  </ul>
                  <Button
                    asChild
                    variant="outline"
                    className="w-full group-hover:bg-gradient-to-r group-hover:from-blue-600 group-hover:to-teal-500 group-hover:text-white group-hover:border-transparent transition-all duration-300 bg-transparent"
                  >
                    <Link href={service.href}>
                      Learn More
                      <ArrowRightIcon />
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Additional services teaser - Links to full services page */}
          <div className="bg-gray-50 rounded-2xl p-8 lg:p-12 text-center">
            <h3 className="text-2xl lg:text-3xl font-bold text-gray-900 mb-4">Comprehensive Advisory Solutions</h3>
            <p className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto">
              Beyond our core services, we offer specialized advisory in Mergers & Acquisitions, Equipment Leasing
              Strategy, and sector-specific consulting across multiple industries.
            </p>
            <Button
              asChild
              size="lg"
              className="bg-gradient-to-r from-blue-600 to-teal-500 text-white hover:opacity-90 transition-opacity"
            >
              <Link href="/services">
                Explore All Services
                <ArrowRightIcon />
              </Link>
            </Button>
          </div>

          {/* Why choose us section */}
          <div className="mt-16 bg-white rounded-2xl p-8 lg:p-12 border border-gray-100">
            <h3 className="text-2xl lg:text-3xl font-bold text-gray-900 text-center mb-12">
              Why Choose{" "}
              <span className="bg-gradient-to-r from-blue-600 to-teal-500 bg-clip-text text-transparent">Vestval</span>?
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {[
                {
                  title: "CFO-Led Value Creation",
                  description: "Strategic financial leadership driving measurable results and sustainable growth",
                },
                {
                  title: "Technology-First Approach",
                  description: "Cutting-edge digital solutions integrated with proven business strategies",
                },
                {
                  title: "Global Expertise, Local Execution",
                  description: "International insights combined with deep local market knowledge and presence",
                },
                {
                  title: "Entrepreneur-Centric Focus",
                  description: "Hands-on approach focused on practical outcomes and long-term business success",
                },
              ].map((benefit, index) => (
                <div key={index} className="text-center">
                  <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-teal-500 rounded-full flex items-center justify-center mx-auto mb-4">
                    <div className="w-6 h-6 bg-white rounded-full"></div>
                  </div>
                  <h4 className="font-bold text-gray-900 mb-2">{benefit.title}</h4>
                  <p className="text-sm text-gray-600 leading-relaxed">{benefit.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
