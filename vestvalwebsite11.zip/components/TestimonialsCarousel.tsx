"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ChevronLeft, ChevronRight, Star, Quote } from "lucide-react"

const testimonials = [
  {
    id: 1,
    name: "Sarah Chen",
    title: "CEO, TechFlow Solutions",
    company: "Technology Startup",
    content:
      "Vestval's IT transformation guidance was instrumental in scaling our operations from 10 to 100+ employees. Their strategic approach to cloud migration and automation saved us over $200K annually while improving our system reliability by 99.9%.",
    rating: 5,
    image: "/professional-woman-ceo.png",
  },
  {
    id: 2,
    name: "Michael Rodriguez",
    title: "CFO, GreenEnergy Corp",
    company: "Renewable Energy",
    content:
      "The capital advisory services provided by Vestval helped us secure $15M in Series B funding. Their financial modeling and investor presentation expertise was exceptional, and they guided us through every step of the fundraising process.",
    rating: 5,
    image: "/professional-man-cfo.png",
  },
  {
    id: 3,
    name: "Dr. Priya Sharma",
    title: "Founder, HealthTech Innovations",
    company: "Healthcare Technology",
    content:
      "Vestval's management consulting team helped us navigate complex regulatory requirements while expanding into three new markets. Their strategic insights and execution support resulted in 300% revenue growth within 18 months.",
    rating: 5,
    image: "/professional-woman-doctor-founder.jpg",
  },
  {
    id: 4,
    name: "James Thompson",
    title: "Managing Director, RetailMax",
    company: "E-commerce",
    content:
      "Working with Vestval on our digital transformation was a game-changer. They modernized our entire e-commerce platform, implemented AI-driven analytics, and helped us achieve 150% increase in online sales within 6 months.",
    rating: 5,
    image: "/professional-man-managing-director.jpg",
  },
  {
    id: 5,
    name: "Lisa Wang",
    title: "President, Manufacturing Plus",
    company: "Manufacturing",
    content:
      "Vestval's leasing advisory services optimized our equipment financing strategy, reducing our capital expenditure by 40% while maintaining operational flexibility. Their expertise in vendor negotiations was invaluable.",
    rating: 5,
    image: "/professional-woman-president-manufacturing.jpg",
  },
]

export default function TestimonialsCarousel() {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isAutoPlaying, setIsAutoPlaying] = useState(true)

  useEffect(() => {
    if (!isAutoPlaying) return

    const interval = setInterval(() => {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % testimonials.length)
    }, 5000)

    return () => clearInterval(interval)
  }, [isAutoPlaying])

  const goToPrevious = () => {
    setCurrentIndex((prevIndex) => (prevIndex - 1 + testimonials.length) % testimonials.length)
    setIsAutoPlaying(false)
  }

  const goToNext = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % testimonials.length)
    setIsAutoPlaying(false)
  }

  const goToSlide = (index: number) => {
    setCurrentIndex(index)
    setIsAutoPlaying(false)
  }

  return (
    <section className="py-16 bg-gray-900 text-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Client Success Stories</h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Hear from leaders who have transformed their businesses with Vestval's advisory services
          </p>
        </div>

        <div className="max-w-4xl mx-auto relative">
          <div className="overflow-hidden">
            <div
              className="flex transition-transform duration-500 ease-in-out"
              style={{ transform: `translateX(-${currentIndex * 100}%)` }}
            >
              {testimonials.map((testimonial) => (
                <div key={testimonial.id} className="w-full flex-shrink-0">
                  <Card className="bg-gray-800 border-gray-700 mx-4">
                    <CardContent className="p-8">
                      <div className="flex items-start space-x-4">
                        <Quote className="h-8 w-8 text-blue-400 flex-shrink-0 mt-1" />
                        <div className="flex-1">
                          <p className="text-lg text-gray-300 mb-6 leading-relaxed">"{testimonial.content}"</p>

                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-4">
                              <img
                                src={testimonial.image || "/placeholder.svg"}
                                alt={testimonial.name}
                                className="w-12 h-12 rounded-full object-cover"
                              />
                              <div>
                                <div className="font-semibold text-white">{testimonial.name}</div>
                                <div className="text-sm text-gray-400">{testimonial.title}</div>
                                <div className="text-sm text-blue-400">{testimonial.company}</div>
                              </div>
                            </div>

                            <div className="flex items-center space-x-1">
                              {[...Array(testimonial.rating)].map((_, i) => (
                                <Star key={i} className="h-4 w-4 text-yellow-400 fill-current" />
                              ))}
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              ))}
            </div>
          </div>

          {/* Navigation buttons */}
          <Button
            variant="outline"
            size="icon"
            onClick={goToPrevious}
            className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 bg-gray-800 border-gray-600 text-white hover:bg-gray-700"
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>

          <Button
            variant="outline"
            size="icon"
            onClick={goToNext}
            className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 bg-gray-800 border-gray-600 text-white hover:bg-gray-700"
          >
            <ChevronRight className="h-4 w-4" />
          </Button>

          {/* Dots indicator */}
          <div className="flex justify-center space-x-2 mt-8">
            {testimonials.map((_, index) => (
              <button
                key={index}
                onClick={() => goToSlide(index)}
                className={`w-3 h-3 rounded-full transition-colors duration-200 ${
                  index === currentIndex ? "bg-blue-400" : "bg-gray-600 hover:bg-gray-500"
                }`}
              />
            ))}
          </div>

          {/* Auto-play indicator */}
          <div className="text-center mt-4">
            <button
              onClick={() => setIsAutoPlaying(!isAutoPlaying)}
              className="text-sm text-gray-400 hover:text-white transition-colors"
            >
              {isAutoPlaying ? "Pause Auto-play" : "Resume Auto-play"}
            </button>
          </div>
        </div>
      </div>
    </section>
  )
}
