"use client"

import { useEffect, useState } from "react"
import { Card } from "@/components/ui/card"

const certifications = [
  { name: "ISO 27001", description: "Information Security Management" },
  { name: "ISO 9001", description: "Quality Management Systems" },
  { name: "SOC 2 Type II", description: "Security & Availability" },
  { name: "GDPR Compliant", description: "Data Protection Standards" },
]

const awards = [
  { year: "2024", title: "Global Consulting Firm of the Year", organization: "Business Excellence Awards" },
  { year: "2023", title: "Digital Transformation Leader", organization: "Tech Innovation Summit" },
  { year: "2023", title: "Best Financial Advisory Services", organization: "Finance World Awards" },
  { year: "2022", title: "Top Management Consulting Firm", organization: "Industry Leadership Awards" },
]

const clientCategories = [
  "Fortune 500",
  "Global Tech",
  "Financial Institutions",
  "Manufacturing",
  "Healthcare",
  "Retail",
]

export default function TrustIndicators() {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 },
    )

    const element = document.getElementById("trust-indicators")
    if (element) observer.observe(element)

    return () => observer.disconnect()
  }, [])

  return (
    <section id="trust-indicators" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className={`transition-all duration-1000 ${isVisible ? "animate-fade-in-up" : "opacity-0"}`}>
          {/* Client Categories */}
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-2 text-muted-foreground">Trusted by Industry Leaders</h2>
            <p className="text-sm text-gray-500 mb-6">Representative categories</p>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 items-center">
              {clientCategories.map((name, index) => (
                <div key={index} className="flex items-center justify-center">
                  <span className="text-xs px-3 py-1 rounded-full bg-muted text-foreground">{name}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Certifications and Awards */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Certifications */}
            <Card className="p-8">
              <h3 className="text-2xl font-bold mb-6 gradient-text">Certifications & Compliance</h3>
              <div className="space-y-4">
                {certifications.map((cert, index) => (
                  <div key={index} className="flex items-center gap-4 p-4 bg-muted/50 rounded-lg">
                    <div className="w-12 h-12 gradient-bg rounded-lg flex items-center justify-center">
                      <div className="w-6 h-6 bg-white rounded-full"></div>
                    </div>
                    <div>
                      <div className="font-semibold">{cert.name}</div>
                      <div className="text-sm text-muted-foreground">{cert.description}</div>
                    </div>
                  </div>
                ))}
              </div>
              <p className="text-xs text-muted-foreground mt-4">
                Vestval provides advisory support toward these standards; certification is granted by accredited bodies
                to qualifying entities.
              </p>
            </Card>

            {/* Awards */}
            <Card className="p-8">
              <h3 className="text-2xl font-bold mb-6 gradient-text">Recognitions of our team members</h3>
              <div className="space-y-4">
                {awards.map((award, index) => (
                  <div key={index} className="border-l-4 border-blue-500 pl-4 py-2">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-sm font-semibold text-blue-600">{award.year}</span>
                      <span className="text-sm text-muted-foreground">•</span>
                      <span className="text-sm text-muted-foreground">{award.organization}</span>
                    </div>
                    <div className="font-semibold">{award.title}</div>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        </div>
      </div>
    </section>
  )
}
