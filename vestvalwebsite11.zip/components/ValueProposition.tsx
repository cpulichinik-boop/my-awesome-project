"use client"

import { useEffect, useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { TrendingUp, Shield, Globe, Users, Zap, Award } from "lucide-react"

const propositions = [
  {
    icon: TrendingUp,
    title: "Proven Growth Results",
    description: "Average 40% revenue increase within 18 months of engagement",
    metric: "40%",
    metricLabel: "Revenue Growth",
  },
  {
    icon: Shield,
    title: "Risk-Mitigated Strategies",
    description: "Comprehensive risk assessment and mitigation in every recommendation",
    metric: "99.2%",
    metricLabel: "Success Rate",
  },
  {
    icon: Globe,
    title: "Global Market Access",
    description: "Leverage our international network to expand into new markets",
    metric: "50+",
    metricLabel: "Countries",
  },
  {
    icon: Users,
    title: "Expert Team Dedication",
    description: "200+ seasoned consultants with deep industry expertise",
    metric: "200+",
    metricLabel: "Experts",
  },
  {
    icon: Zap,
    title: "Rapid Implementation",
    description: "Fast-track your transformation with our proven methodologies",
    metric: "60%",
    metricLabel: "Faster Results",
  },
  {
    icon: Award,
    title: "Expert-Led Practice",
    description: "Led by senior experts from top global firms across technology, finance, and strategy.",
    metric: "Expert-led",
    metricLabel: "Team Credibility",
  },
]

export default function ValueProposition() {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 },
    )

    const element = document.getElementById("value-proposition")
    if (element) observer.observe(element)

    return () => observer.disconnect()
  }, [])

  return (
    <section id="value-proposition" className="py-20 bg-gradient-to-br from-blue-50 via-white to-yellow-50">
      <div className="container mx-auto px-4">
        <div className={`transition-all duration-1000 ${isVisible ? "animate-fade-in-up" : "opacity-0"}`}>
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-bold mb-6 gradient-text">Why Global Leaders Choose Vestval</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-pretty">
              We don't just provide advice – we deliver transformational results that create lasting competitive
              advantages and drive sustainable business growth across every industry sector.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
            {propositions.map((prop, index) => (
              <Card
                key={index}
                className={`p-8 hover-lift bg-white/80 backdrop-blur-sm border-0 shadow-lg group ${
                  isVisible ? "animate-fade-in-up" : "opacity-0"
                }`}
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="flex items-start gap-4 mb-6">
                  <div className="w-12 h-12 rounded-xl gradient-bg flex items-center justify-center group-hover:scale-110 transition-transform">
                    <prop.icon className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-bold mb-2 group-hover:gradient-text transition-colors">{prop.title}</h3>
                    <p className="text-muted-foreground text-sm leading-relaxed">{prop.description}</p>
                  </div>
                </div>

                <div className="border-t pt-4">
                  <div className="text-3xl font-bold gradient-text mb-1">{prop.metric}</div>
                  <div className="text-sm text-muted-foreground font-medium">{prop.metricLabel}</div>
                </div>
              </Card>
            ))}
          </div>

          <div className="text-center">
            <div className="bg-white rounded-2xl p-8 shadow-xl max-w-4xl mx-auto">
              <h3 className="text-2xl font-bold mb-4">Ready to Transform Your Business?</h3>
              <p className="text-muted-foreground mb-6 text-lg">
                Join the ranks of successful enterprises who have partnered with Vestval to achieve extraordinary
                results.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button size="lg" className="gradient-bg text-white hover:opacity-90">
                  Start Your Transformation
                </Button>
                <Button size="lg" variant="outline">
                  Download Success Stories
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
