"use client"

import type * as React from "react"
import { useMemo, useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { cn } from "@/lib/utils"

type BudgetRange = "<25k" | "25k-50k" | "50k-100k" | "100k-250k" | "250k-500k" | "500k+"

const challengeOptions = [
  "Cost optimization",
  "Cloud & infrastructure",
  "Data & analytics",
  "AI adoption",
  "Operating model & org",
  "Security & compliance",
  "M&A and carve-outs",
  "Go-to-market acceleration",
] as const

const maturityChecklist = [
  "Clear KPIs for priority initiatives",
  "Documented processes and owners",
  "Automated reporting cadence",
  "Centralized data with governance",
  "Tested disaster recovery plan",
  "Defined architecture standards",
] as const

function clamp(num: number, min: number, max: number) {
  return Math.min(Math.max(num, min), max)
}

export default function GetStartedForm() {
  // Company details
  const [companyName, setCompanyName] = useState("")
  const [website, setWebsite] = useState("")
  const [contactName, setContactName] = useState("")
  const [email, setEmail] = useState("")
  const [phone, setPhone] = useState("")

  // Narrative
  const [summary, setSummary] = useState("")

  // Challenges and maturity
  const [challenges, setChallenges] = useState<string[]>([])
  const [maturity, setMaturity] = useState<string[]>([])

  // Timeline and budget
  const [timeline, setTimeline] = useState("ASAP")
  const [budgetRange, setBudgetRange] = useState<BudgetRange | "">("")

  // ROI calculator inputs
  const [estBenefit, setEstBenefit] = useState<string>("0") // annual gross benefit (USD)
  const [estCost, setEstCost] = useState<string>("0") // one-time + year-1 costs (USD)

  // File upload
  const [file, setFile] = useState<File | null>(null)

  // Honeypot
  const [websiteHp, setWebsiteHp] = useState("")

  const parsedBenefit = useMemo(() => Number(estBenefit.replace(/[^0-9.]/g, "")) || 0, [estBenefit])
  const parsedCost = useMemo(() => Number(estCost.replace(/[^0-9.]/g, "")) || 0, [estCost])

  // ROI = (benefit - cost) / cost, bounded to [-100%, 1000%]
  const roiPct = useMemo(() => {
    if (parsedCost <= 0) return 0
    const raw = ((parsedBenefit - parsedCost) / parsedCost) * 100
    return clamp(raw, -100, 1000)
  }, [parsedBenefit, parsedCost])

  const [submitting, setSubmitting] = useState(false)
  const [result, setResult] = useState<{ ok: boolean; message: string; caseId?: string } | null>(null)

  function toggleInArray(value: string, arr: string[], setArr: (v: string[]) => void) {
    if (arr.includes(value)) {
      setArr(arr.filter((v) => v !== value))
    } else {
      setArr([...arr, value])
    }
  }

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    setResult(null)

    // Basic client validation
    if (!companyName || !contactName || !email) {
      setResult({ ok: false, message: "Please complete required fields (Company, Contact name, Email)." })
      return
    }

    // Spam honeypot
    if (websiteHp.trim() !== "") {
      setResult({ ok: true, message: "Thanks! If this was not automated, please try again." })
      return
    }

    const fd = new FormData()
    fd.append("companyName", companyName)
    fd.append("website", website)
    fd.append("contactName", contactName)
    fd.append("email", email)
    fd.append("phone", phone)
    fd.append("summary", summary)
    fd.append("timeline", timeline)
    if (budgetRange) fd.append("budgetRange", budgetRange)

    fd.append("challenges", JSON.stringify(challenges))
    fd.append("maturity", JSON.stringify(maturity))

    fd.append("estBenefit", String(parsedBenefit))
    fd.append("estCost", String(parsedCost))
    fd.append("roiPctClient", String(roiPct))

    if (file) {
      fd.append("file", file, file.name)
    }

    setSubmitting(true)
    try {
      const res = await fetch("/api/get-started", {
        method: "POST",
        body: fd,
      })
      const data = await res.json()
      if (!res.ok) {
        setResult({ ok: false, message: data?.error || "Submission failed. Please try again." })
      } else {
        setResult({ ok: true, message: "Submitted! Check your email for confirmation.", caseId: data.caseId })
        // Optionally reset after success
        setCompanyName("")
        setWebsite("")
        setContactName("")
        setEmail("")
        setPhone("")
        setSummary("")
        setChallenges([])
        setMaturity([])
        setTimeline("ASAP")
        setBudgetRange("")
        setEstBenefit("0")
        setEstCost("0")
        setFile(null)
      }
    } catch (err: any) {
      setResult({ ok: false, message: err?.message || "Unexpected error" })
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <form onSubmit={onSubmit} className="space-y-8">
      {/* Company details */}
      <section aria-labelledby="company-details" className="space-y-4">
        <h2 id="company-details" className="text-xl font-semibold">
          {"Company details"}
        </h2>
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          <div>
            <Label htmlFor="companyName">Company name *</Label>
            <Input
              id="companyName"
              name="companyName"
              placeholder="Acme Corp"
              value={companyName}
              onChange={(e) => setCompanyName(e.target.value)}
              required
            />
          </div>
          <div>
            <Label htmlFor="website">Company website</Label>
            <Input
              id="website"
              name="website"
              placeholder="https://example.com"
              inputMode="url"
              value={website}
              onChange={(e) => setWebsite(e.target.value)}
            />
          </div>
          <div>
            <Label htmlFor="contactName">Contact name *</Label>
            <Input
              id="contactName"
              name="contactName"
              placeholder="Jane Doe"
              value={contactName}
              onChange={(e) => setContactName(e.target.value)}
              required
            />
          </div>
          <div>
            <Label htmlFor="email">Work email *</Label>
            <Input
              id="email"
              name="email"
              placeholder="jane@acme.com"
              inputMode="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <div className="md:col-span-2">
            <Label htmlFor="phone">Phone</Label>
            <Input
              id="phone"
              name="phone"
              placeholder="+1 555 123 4567"
              inputMode="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
            />
          </div>
          <div className="md:col-span-2">
            <Label htmlFor="summary">Context (goals, constraints, stakeholders)</Label>
            <Textarea
              id="summary"
              name="summary"
              placeholder="Briefly describe your objectives and current state."
              value={summary}
              onChange={(e) => setSummary(e.target.value)}
              rows={5}
            />
          </div>
        </div>
      </section>

      {/* Challenge selection */}
      <section aria-labelledby="challenges" className="space-y-4">
        <h2 id="challenges" className="text-xl font-semibold">
          {"Primary challenges"}
        </h2>
        <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
          {challengeOptions.map((opt) => (
            <label key={opt} className="flex cursor-pointer items-center gap-3 rounded-md border p-3">
              <Checkbox
                checked={challenges.includes(opt)}
                onCheckedChange={() => toggleInArray(opt, challenges, setChallenges)}
                aria-label={opt}
              />
              <span className="text-sm">{opt}</span>
            </label>
          ))}
        </div>
      </section>

      {/* Maturity checklist */}
      <section aria-labelledby="maturity" className="space-y-4">
        <h2 id="maturity" className="text-xl font-semibold">
          {"Maturity checklist"}
        </h2>
        <div className="grid grid-cols-1 gap-3">
          {maturityChecklist.map((item) => (
            <label key={item} className="flex cursor-pointer items-center gap-3 rounded-md border p-3">
              <Checkbox
                checked={maturity.includes(item)}
                onCheckedChange={() => toggleInArray(item, maturity, setMaturity)}
                aria-label={item}
              />
              <span className="text-sm">{item}</span>
            </label>
          ))}
        </div>
      </section>

      {/* Timeline and budget */}
      <section aria-labelledby="timeline-budget" className="space-y-4">
        <h2 id="timeline-budget" className="text-xl font-semibold">
          {"Timeline & budget"}
        </h2>
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          <div>
            <Label>{"Timeline"}</Label>
            <Select value={timeline} onValueChange={setTimeline}>
              <SelectTrigger aria-label="Timeline">
                <SelectValue placeholder="Select timeline" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ASAP">{"Immediately (ASAP)"}</SelectItem>
                <SelectItem value="1-3m">{"1–3 months"}</SelectItem>
                <SelectItem value="3-6m">{"3–6 months"}</SelectItem>
                <SelectItem value="6m+">{"6+ months"}</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>{"Budget range"}</Label>
            <Select value={budgetRange} onValueChange={(v) => setBudgetRange(v as BudgetRange)}>
              <SelectTrigger aria-label="Budget range">
                <SelectValue placeholder="Select range" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="<25k">{"< $25k"}</SelectItem>
                <SelectItem value="25k-50k">{"$25k – $50k"}</SelectItem>
                <SelectItem value="50k-100k">{"$50k – $100k"}</SelectItem>
                <SelectItem value="100k-250k">{"$100k – $250k"}</SelectItem>
                <SelectItem value="250k-500k">{"$250k – $500k"}</SelectItem>
                <SelectItem value="500k+">{">$500k"}</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </section>

      {/* ROI calculator */}
      <section aria-labelledby="roi" className="space-y-3 rounded-lg border p-4">
        <h2 id="roi" className="text-xl font-semibold">
          {"ROI calculator (illustrative)"}
        </h2>
        <p className="text-sm text-muted-foreground">
          {"Estimates are non-binding directional indicators only and not guarantees of performance."}
        </p>
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          <div>
            <Label htmlFor="estBenefit">{"Estimated annual benefit (USD)"}</Label>
            <Input
              id="estBenefit"
              inputMode="decimal"
              value={estBenefit}
              onChange={(e) => setEstBenefit(e.target.value)}
              placeholder="e.g., 250000"
            />
          </div>
          <div>
            <Label htmlFor="estCost">{"Estimated year-1 total cost (USD)"}</Label>
            <Input
              id="estCost"
              inputMode="decimal"
              value={estCost}
              onChange={(e) => setEstCost(e.target.value)}
              placeholder="e.g., 100000"
            />
          </div>
        </div>
        <div className="rounded-md bg-secondary p-3 text-sm">
          <p>
            <strong>{"Projected ROI: "}</strong>
            {Number.isFinite(roiPct) ? `${roiPct.toFixed(1)}%` : "—"}
          </p>
          <p className="mt-1 text-muted-foreground">
            {"Bounded output: ROI is clamped between -100% and 1000% for display."}
          </p>
        </div>
      </section>

      {/* File upload */}
      <section aria-labelledby="upload" className="space-y-2">
        <h2 id="upload" className="text-xl font-semibold">
          {"Attach a brief (optional)"}
        </h2>
        <p className="text-sm text-muted-foreground">{"PDF, DOCX, or PPTX. Max 10MB."}</p>
        <Input
          id="file"
          type="file"
          accept=".pdf,.doc,.docx,.ppt,.pptx"
          onChange={(e) => {
            const f = e.target.files?.[0]
            if (f && f.size > 10 * 1024 * 1024) {
              setResult({ ok: false, message: "File is too large. Please keep under 10MB." })
              e.currentTarget.value = ""
              setFile(null)
              return
            }
            setFile(f ?? null)
          }}
        />
      </section>

      {/* Honeypot */}
      <div className="hidden" aria-hidden>
        <Label htmlFor="websiteHp">{"Do not fill this out if you are human"}</Label>
        <Input
          id="websiteHp"
          name="websiteHp"
          value={websiteHp}
          onChange={(e) => setWebsiteHp(e.target.value)}
          tabIndex={-1}
          autoComplete="off"
        />
      </div>

      {/* Submit */}
      <div className={cn("flex items-center gap-3")}>
        <Button type="submit" disabled={submitting}>
          {submitting ? "Submitting…" : "Submit intake"}
        </Button>
        {result?.caseId ? (
          <span className="text-sm text-muted-foreground">
            {"Case ID: "}
            <strong>{result.caseId}</strong>
          </span>
        ) : null}
      </div>

      <div role="status" aria-live="polite" className="min-h-6">
        {result ? (
          <p className={cn("text-sm", result.ok ? "text-green-600" : "text-destructive")}>{result.message}</p>
        ) : null}
      </div>

      <p className="text-xs text-muted-foreground">
        {
          "By submitting, you consent to being contacted regarding this inquiry and acknowledge that ROI is an estimate only."
        }
      </p>
    </form>
  )
}
